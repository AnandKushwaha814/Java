import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;

import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

public class Admin_page1 implements ActionListener{
    public void Admin_page() {
        JFrame f1 = new JFrame("WELCOME TO THE ADMIN PAGE");
        JLabel l1 = new JLabel("WELCOME TO THE ADMIN PAGE");

        ImageIcon icon = (new ImageIcon(new ImageIcon("droom.jpg").getImage().getScaledInstance(1500, 600, Image.SCALE_SMOOTH)));

        JLabel label1 = new JLabel(icon);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 25, 20));
        JPanel buttonPanel1 = new JPanel();
        buttonPanel1.setLayout(new BoxLayout(buttonPanel1, BoxLayout.Y_AXIS));

        // JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 35, 20));
        JLabel lbl1 = new JLabel();
        JLabel lbl2 = new JLabel();
        JLabel lbl3 = new JLabel("MENU");
        JLabel lbl4 = new JLabel("-----------------------------------------------------");
        JButton btn1 = new JButton("Manage Doctor");
        JButton btn2 = new JButton("Manage Nurse");
        JButton btn3 = new JButton("Manage receptionist");
        JButton btn4 = new JButton("Manage Appointments");
        JButton btn5 = new JButton("Patient History");
        // JButton btn13 = new JButton("MENU");
        JButton btn6 = new JButton("Add New");
        JButton btn7 = new JButton("Update ");
        JButton btn8 = new JButton("Delete");
        JButton btn9 = new JButton("Save");
        JButton btn10 = new JButton("Search");
        JButton btn11 = new JButton("Logout");
        // JButton btn12 = new JButton("EXIT");
        
        JButton btn14 = new JButton();
        buttonPanel.add(btn1);
        buttonPanel.add(btn2);
        buttonPanel.add(btn3);
        buttonPanel.add(btn4);
        buttonPanel.add(btn5);
        buttonPanel1.add(btn6);
        buttonPanel1.add(btn7);
        buttonPanel1.add(btn8);
        buttonPanel1.add(btn9);
        buttonPanel1.add(btn10);
        buttonPanel1.add(btn11);
        // buttonPanel1.add(btn12);
        
        lbl3.setBounds(50, 20, 140, 50);
        lbl4.setBounds(0, 90, 210, 10);
        l1.setBounds(0, 0, 1540, 100);
        buttonPanel.setBounds(200, 100, 1540, 100);
        buttonPanel1.setBounds(200, 100, 1540, 100);
        lbl1.setBounds(200, 150, 1540, 100);
        lbl2.setBounds(0, 100, 200, 900);
        
        btn6.setBounds(0, 100,200, 60);
        btn7.setBounds(0, 170,200, 60);
        btn8.setBounds(0, 240,200, 60);
        btn9.setBounds(0, 310,200, 60);
        btn10.setBounds(0, 380,200,60);
        btn11.setBounds(0, 450,200, 60);
        // btn12.setBounds(0, 520,200, 60);
        // btn13.setBounds(10, 200,140, 50);

        label1.setBounds(200,140, 1400, 700);
        Font plainFont = new Font("Jumble", Font.BOLD, 50);
        // Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 25);
        Font plainFont3 = new Font("Jumble", Font.BOLD, 30);
        Border border1 = BorderFactory.createLineBorder(Color.PINK, 20);
        Border border2 = BorderFactory.createLineBorder(Color.BLUE, 0);
        l1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        l1.setFont(plainFont);
        lbl3.setFont(plainFont3);
        btn1.setFont(plainFont2);
        btn2.setFont(plainFont2);
        btn3.setFont(plainFont2);
        btn4.setFont(plainFont2);
        btn5.setFont(plainFont2);
        btn6.setFont(plainFont2);
        btn7.setFont(plainFont2);
        btn8.setFont(plainFont2);
        btn9.setFont(plainFont2);
        btn10.setFont(plainFont2);
        btn11.setFont(plainFont2);
        // btn12.setFont(plainFont2);

        l1.setOpaque(true);
        l1.setBackground(Color.BLACK);
        l1.setForeground(Color.WHITE);
        lbl1.setOpaque(true);
        lbl1.setBackground(Color.CYAN);
        lbl1.setForeground(Color.WHITE);
        lbl2.setOpaque(true);
        lbl2.setBackground(Color.BLUE);
        lbl2.setForeground(Color.WHITE);
        buttonPanel.setOpaque(true);
        buttonPanel.setBackground(Color.CYAN);
        buttonPanel.setForeground(Color.WHITE);
        btn1.setBackground(Color.CYAN);
        btn2.setBackground(Color.CYAN);
        btn3.setBackground(Color.CYAN);
        btn4.setBackground(Color.CYAN);
        btn5.setBackground(Color.CYAN);
       

        btn1.setForeground(Color.WHITE);
        btn2.setForeground(Color.WHITE);
        btn3.setForeground(Color.WHITE);
        btn4.setForeground(Color.WHITE);
        btn5.setForeground(Color.WHITE);

        lbl3.setForeground(Color.WHITE);
        lbl3.setBackground(Color.BLUE);
        lbl4.setForeground(Color.WHITE);
        lbl4.setBackground(Color.BLUE);
        lbl3.setBorder(border2);
        lbl4.setBorder(border2);


        l1.setBorder(border1);
        l1.setHorizontalAlignment(JLabel.CENTER);
        
        f1.add(l1);
        f1.add(lbl2);
        lbl2.add(btn6);
        lbl2.add(btn7);
        lbl2.add(btn8);
        lbl2.add(btn9);
        lbl2.add(btn10);
        lbl2.add(btn11);
        // lbl2.add(btn12);
        lbl2.add(lbl3);
        lbl2.add(lbl4);
        //  f1.add(lbl1);
        f1.add(label1);
        
        f1.add(buttonPanel);
        f1.setBounds(0, 0, 1540, 1000);
        f1.setLayout(null);
        f1.setVisible(true);

        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee) {
                Manage_Doctor();
            }
        });

    }

    public void Manage_Doctor(){
        JFrame frame=new JFrame("Add New Doctor...");
        JLabel lbl1=new JLabel("Manage Doctor Data");
        JLabel lbl2=new JLabel("Email-ID :  ");
        JLabel lbl3=new JLabel("Password : ");
        JLabel lbl4=new JLabel("Name : ");
        JLabel lbl5=new JLabel("Profile Image : ");
        JLabel lbl6=new JLabel("Phone N0 : ");
        JLabel lbl7=new JLabel("Address : ");
        JLabel lbl8=new JLabel("DOB : ");
        JLabel lbl9=new JLabel("Doctor Degree : ");
        JLabel lbl10=new JLabel("Expert In : ");
        JLabel lbl11=new JLabel("Status : ");
        JLabel lbl12=new JLabel("Added Date : ");
        JLabel lbl13=new JLabel("Username : ");
        JTextField txt1=new JTextField();
        JPasswordField txt2=new JPasswordField();
        JTextField txt3=new JTextField();
        JTextField txt4=new JTextField();
        JTextField txt5=new JTextField();
        JTextField txt6=new JTextField();
        JTextField txt7=new JTextField();
        JTextField txt8=new JTextField();
        JTextField txt9=new JTextField();
        JTextField txt10=new JTextField();
        JTextField txt11=new JTextField();




/*CREATE TABLE `doctor_table` (
  `doctor_id` int(11) NOT NULL,
  `doctor_email_address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_profile_image` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_phone_no` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `doctor_date_of_birth` date NOT NULL,
  `doctor_degree` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_expert_in` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_status` enum('Active','Inactive') COLLATE utf8_unicode_ci NOT NULL,
  `doctor_added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
 */

        // lbl1.setBounds(400, 5,550,35);
        lbl2.setBounds(20, 100,120,35);
        lbl13.setBounds(20, 100,120,35);
        lbl3.setBounds(500, 100,120,35);
        lbl4.setBounds(20, 170,120,35);
        lbl5.setBounds(750, 170,150,35);
        lbl6.setBounds(20, 230,150,35);
        lbl7.setBounds(500, 230,150,35);
        lbl8.setBounds(20, 290,150,35);
        lbl9.setBounds(500, 290,150,35);
        lbl10.setBounds(20, 350,150,35);
        lbl11.setBounds(500, 350,150,35);
        lbl12.setBounds(20, 410,150,35);
        lbl13.setBounds(500, 410,150,35);
        Font plainFont = new Font("Algerian", Font.BOLD, 35);
        Font plainFont1 = new Font("jumble", Font.BOLD, 20);
        
        lbl1.setFont(plainFont);
        lbl3.setFont(plainFont1);
        lbl4.setFont(plainFont1);
        lbl5.setFont(plainFont1);
        lbl6.setFont(plainFont1);
        lbl7.setFont(plainFont1);
        lbl8.setFont(plainFont1);
        lbl9.setFont(plainFont1);
        lbl10.setFont(plainFont1);
        lbl11.setFont(plainFont1);
        lbl12.setFont(plainFont1);
        lbl13.setFont(plainFont1);
        // lbl13.setFont(plainFont1);


        lbl1.setForeground(Color.WHITE);


        frame.add(lbl1);
        frame.add(lbl3);
        frame.add(lbl4);
        frame.add(lbl5);
        frame.add(lbl6);
        frame.add(lbl7);
        frame.add(lbl8);
        frame.add(lbl9);
        frame.add(lbl10);
        frame.add(lbl11);
        frame.add(lbl12);
        frame.add(lbl13);
        frame.getContentPane().setBackground(Color.decode("#94f1d5"));
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setBounds(200, 220, 1340, 700);

    }
    

    public static void main(String[] args) {
        Admin_page1 ob = new Admin_page1();
        ob.Admin_page();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'actionPerformed'");
    }
}

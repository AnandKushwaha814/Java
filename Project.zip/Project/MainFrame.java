import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame implements ActionListener {
    private JButton openNewFrameButton;

    public MainFrame() {
        setTitle("Main Frame");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        openNewFrameButton = new JButton("Open New Frame");
        openNewFrameButton.addActionListener(this);

        JPanel panel = new JPanel();
        panel.add(openNewFrameButton);

        add(panel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == openNewFrameButton) {
            NewFrame newFrame = new NewFrame();
            newFrame.setVisible(true);
        }
    }

    public static void main(String[] args) {
        new MainFrame();
    }
}

class NewFrame extends JFrame {
    public NewFrame() {
        setTitle("New Frame");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        JLabel label = new JLabel("This is the new frame.");

        panel.add(label);
        add(panel);
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class abc {
    JFrame frame2=new JFrame();
    abc(){
        JButton btn1 = new JButton("ADD NEW");
        JButton btn2 = new JButton("UPDATE");
        JButton btn3 = new JButton("DELETE");
        JButton btn4 = new JButton("SEARCH");
        JButton btn5 = new JButton("SAVE");
        JButton btn6 = new JButton("SHOW");
        JButton btn7 = new JButton("PATIENT HISTORY");
        JButton btn8 = new JButton("EXIT");
        JButton btn9 = new JButton("LOGOUT");
        JButton btn10 = new JButton("MENU");

        JButton btn11=new JButton("DOCTOR");
        JButton btn12=new JButton("NURSE");
        JButton btn13=new JButton("RECEPTIONIST");
        JButton btn14=new JButton("MEDICAL");
        JButton btn15=new JButton("");
        JButton btn16=new JButton("");
        JButton btn17=new JButton("");
        JButton btn18=new JButton("");
        JButton btn19=new JButton("");
        JButton btn20=new JButton("");
        JButton btn21=new JButton("");


        btn1.setBounds(100, 20, 160, 40);
        btn2.setBounds(260, 20, 160, 40);
        btn3.setBounds(320,20, 160, 40);
        btn4.setBounds(480, 20, 160, 40);
        btn5.setBounds(540, 20, 160, 40);
        btn6.setBounds(700, 20, 160, 40);
        btn7.setBounds(860, 20, 160, 40);
        btn8.setBounds(1020, 20, 160, 40);
        btn10.setBounds(20, 20, 60, 30);


     frame2.add(btn1);
        frame2.add(btn2);
        frame2.add(btn3);
        frame2.add(btn4);
        frame2.add(btn5);
        frame2.add(btn6);
        frame2.add(btn7);
        frame2.add(btn8);    


    frame2.getContentPane().setBackground(Color.decode("#fae607"));
    frame2.setBounds(0,130,1540,900);
    frame2.setLayout(null);
    frame2.setVisible(true);
    }

    public static void main(String[] a){
        abc i=new abc();
    }
    
}

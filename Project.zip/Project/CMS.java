import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CMS {

    // JFrame frame, Frame1;
    // JButton btn1;
    public void Welcome() {
        JFrame f1 = new JFrame();
        JButton b1 = new JButton("Enter");
        f1.setTitle("Welcome to the My Project");

        ImageIcon icon = new ImageIcon("gif.gif");
        JLabel label = new JLabel(icon);
        label.setPreferredSize(new Dimension(470, 302));
        label.setHorizontalAlignment(JLabel.CENTER);

        f1.add(label);
        f1.pack();
        b1.setBounds(200, 308, 75, 35);

        f1.add(b1);
        f1.setBounds(470, 250, 470, 382);

        f1.setLayout(null);
        f1.setVisible(true);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee) {
                // Sign_In();
                // ();
                Main_Page();
                f1.dispose();

            }
        });

    }


    public void Main_Page() {
        JFrame frame = new JFrame();
        // JFrame Frame1=new JFrame();
        JLabel lbl = new JLabel("Login...");
        JLabel lbl1 = new JLabel("Username : ");
        JLabel lbl2 = new JLabel("Password : ");
        JButton btn1 = new JButton("Login");
        JButton btn2 = new JButton("Registration Here");

        JTextField txt1 = new JTextField(35);
        JPasswordField txt2 = new JPasswordField(20);

        Font plainFont = new Font("Jumble", Font.BOLD, 25);
        Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
        Font plainFont3 = new Font("Jumble", Font.BOLD, 30);
        Border border1 = BorderFactory.createLineBorder(Color.BLACK, 10);
        Border border2 = BorderFactory.createLineBorder(Color.RED, 6);

        lbl.setBounds(120, 5, 300, 40);
        lbl1.setBounds(20, 70, 150, 30);
        lbl2.setBounds(20, 120, 150, 30);
        txt1.setBounds(200, 70, 200, 30);
        txt2.setBounds(200, 120, 200, 30);
        btn1.setBounds(150, 180, 120, 30);
        btn2.setBounds(290, 215, 180, 30);

        lbl.setFont(plainFont3);
        lbl1.setFont(plainFont2);
        lbl2.setFont(plainFont2);
        txt1.setFont(plainFont2);
        txt2.setFont(plainFont2);
        btn1.setFont(plainFont2);
        btn2.setFont(plainFont1);

        frame.add(lbl);
        frame.add(lbl1);
        frame.add(lbl2);
        frame.add(txt1);
        frame.add(txt2);
        frame.add(btn1);
        frame.add(btn2);

        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
                String username = txt1.getText();
                String password = new String(txt2.getPassword());
                Integer len = username.length();
                Integer len1 = username.length();
                if (len == 0 && len1 == 0) {
                    JOptionPane.showMessageDialog(btn1, "Every Field is required!!!");
                } else {
                    // JOptionPane.showMessageDialog(btn1,"Every Field is required!!!");

                    try {
                        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                                "Ankit@817raj#");

                        PreparedStatement statement = connection
                                .prepareStatement("Select * from userdataa where username=? and password=?");
                        statement.setString(1, username);
                        statement.setString(2, password);
                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(btn1, "Login successful!");
                            txt1.setText("");
                            txt2.setText("");

                        } else {
                            JOptionPane.showMessageDialog(btn1, "Invalid username or password");
                        }
                    } catch (Exception ee) {
                        ee.printStackTrace();
                    }
                }

            }

        });
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee1) {
                Registraion_page();
                frame.dispose();
            }
        });

        frame.getContentPane().setBackground(Color.decode("#fae607"));
        frame.setTitle("CLINIC MANAGEMENT SYSTEM");
        frame.setBounds(300, 200, 500, 300);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    public void Registraion_page(){
        JFrame Frame1=new JFrame();
        JLabel lbl=new JLabel("Registraion");
        JLabel lbl1=new JLabel("Email-Id      : ");
        JLabel lbl2=new JLabel("Name          : ");
        JLabel lbl3=new JLabel("Username  :");
        JLabel lbl4=new JLabel("Password  : ");
        JLabel lbl5=new JLabel("Phone No. : ");
        JButton btn1=new JButton("Registration");
        JButton btn2=new JButton("Login Here");
        JTextField txt1=new JTextField(35);
        JTextField txt2=new JTextField(35);
        JTextField txt3=new JTextField(35);
        JTextField txt5=new JTextField(35);
        // JTextField txt5=new JTextField(35);
        JPasswordField txt4=new JPasswordField(20);

        // Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
        // Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

        lbl.setBounds(160, 5, 300, 40);
        lbl1.setBounds(20, 70, 150, 30);
        lbl2.setBounds(20, 120, 150, 30);
        lbl3.setBounds(20, 170, 150, 30);
        lbl4.setBounds(20, 220, 150, 30);
        lbl5.setBounds(20, 270, 150, 30);
        txt1.setBounds(220, 70, 150, 30);
        txt2.setBounds(220, 120, 150, 30);
        txt3.setBounds(220, 170, 150, 30);
        txt4.setBounds(220, 220, 150, 30);
        txt5.setBounds(220, 270, 150, 30);
        btn1.setBounds(130, 350, 170, 30);
        btn2.setBounds(280, 420, 150, 30);

        lbl.setFont(plainFont2);
        lbl1.setFont(plainFont2);
        lbl2.setFont(plainFont2);
        lbl3.setFont(plainFont2);
        lbl4.setFont(plainFont2);
        lbl5.setFont(plainFont2);
        txt1.setFont(plainFont2);
        txt2.setFont(plainFont2);
        txt3.setFont(plainFont2);
        txt4.setFont(plainFont2);
        txt5.setFont(plainFont2);
        btn1.setFont(plainFont2);
        btn2.setFont(plainFont2);
        



        Frame1.add(lbl);
        Frame1.add(lbl1);
        Frame1.add(lbl2);
        Frame1.add(lbl3);
        Frame1.add(lbl4);
        Frame1.add(lbl5);
        Frame1.add(txt1);
        Frame1.add(txt2);
        Frame1.add(txt3);
        Frame1.add(txt4);
        Frame1.add(txt5);

        Frame1.add(btn1);
        Frame1.add(btn2);
        // Frame1.add(lbl);

        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee2){
                String emial=txt1.getText();
                String name=txt2.getText();
                String username=txt3.getText();
                String password=new String(txt4.getPassword());
                String phone=txt5.getText();
                Integer len=emial.length();
                Integer len1=name.length();
                Integer len2=username.length();
                Integer len3=password.length();
                Integer len4=phone.length();
                String msg = "" + name;
                if(len==0&&len1==0&&len2==0&&len3==0&&len4==0){
                    JOptionPane.showMessageDialog(btn2,"Every fields are required!!");
                }else{
                     try {
                        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                                "Ankit@817raj#");
                    
                                DatabaseMetaData metaData = connection.getMetaData();
                            ResultSet tables = metaData.getTables(null, null, "userdataa", null);
                            boolean tableExists = tables.next();
                            if (!tableExists) {
                                Statement statement = connection.createStatement();
                                statement.executeUpdate(
                                        "Create table userdataa(id INT AUTO_INCREMENT PRIMARY KEY,email varchar(25) not null,name varchar(25) not null,username varchar(50) not null,password varchar(30) not null,phone int(20) not null)");
                            }
                            String query1 = "INSERT INTO userdataa(email,name,username,password,phone) values('"
                                    + emial + "','" + name + "','"
                                    + username + "','" + password + "','" + phone + "')";

                            Statement sta = connection.createStatement();
                            int x = sta.executeUpdate(query1);

                            if (x == 0) {
                                JOptionPane.showMessageDialog(btn1, "This is alredy exist");
                            } else {
                                JOptionPane.showMessageDialog(btn1,"Congratulations "+msg+"Your Registraions sucessfully....");
                                txt1.setText("");
                                txt2.setText("");
                                txt3.setText("");
                                txt4.setText("");
                                txt5.setText("");
                                Frame1.dispose();
                                Main_Page();

                                // t6.setText("");
                                // t7.setText("");

                            }
                        
                    
                        }catch(Exception ee3){
                            ee3.printStackTrace();
                        }
                }
                
            }
        
                
            
        });


        Frame1.getContentPane().setBackground(Color.decode("#fae607"));     
        Frame1.setBounds(300, 250, 450, 500);
        Frame1.setLayout(null);
        Frame1.setVisible(true);
        

        }

    public static void main(String[] args) {
        CMS ob = new CMS();
        JFrame F = new JFrame();
        ImageIcon icon = new ImageIcon("Bg.jpg");
        JLabel label1 = new JLabel(icon);
        F.add(label1);
        F.pack();
        F.setSize(1540, 1000);
        F.setVisible(true);
        F.setLayout(null);
        ob.Welcome();

    }
}

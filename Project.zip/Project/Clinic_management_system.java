import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.regex.Pattern;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.table.*;
import java.util.*;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;
public class Clinic_management_system implements ActionListener {
    public void Welcome() {
        JFrame f1 = new JFrame();
        JButton b1 = new JButton("Open");
        f1.setTitle("Welcome to the My Project");
        
        ImageIcon icon = new ImageIcon("gif.gif");
        JLabel label = new JLabel(icon);
        label.setPreferredSize(new Dimension(470, 302));
        label.setHorizontalAlignment(JLabel.CENTER);

        f1.add(label);
        f1.pack();
        b1.setBounds(200, 308, 75, 35);

        f1.add(b1);
        f1.setBounds(470, 250, 470, 382);

        f1.setLayout(null);
        f1.setVisible(true);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee) {
                Main_Page();
                f1.dispose();
            }
        });
        
        b1.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    Main_Page();
                    f1.dispose();
                }
            }
        });
        
        
        

    }
// MAIN PAGE LOGIN

    public void Main_Page() {
        JFrame frame = new JFrame();
        // JFrame Frame1=new JFrame();
        JLabel lbl = new JLabel("Login...");
        JLabel lbl1 = new JLabel("Username : ");
        JLabel lbl2 = new JLabel("Password : ");
        JButton btn1 = new JButton("Login");
        JButton btn2 = new JButton("Registration Here");
        JButton btn3 = new JButton("Forgot Password");

        JTextField txt1 = new JTextField(35);
        JPasswordField txt2 = new JPasswordField(20);

        Font plainFont = new Font("Jumble", Font.BOLD, 14);
        Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
        Font plainFont3 = new Font("Jumble", Font.BOLD, 30);
        Border border1 = BorderFactory.createLineBorder(Color.BLACK, 10);
        Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
        Border border3 = BorderFactory.createLineBorder(Color.RED, 0);

        lbl.setBounds(120, 5, 300, 40);
        lbl1.setBounds(20, 70, 150, 30);
        lbl2.setBounds(20, 120, 150, 30);
        txt1.setBounds(200, 70, 200, 30);
        txt2.setBounds(200, 120, 200, 30);
        btn1.setBounds(150, 180, 120, 30);
        btn2.setBounds(290, 215, 180, 30);
        btn3.setBounds(240, 150, 180, 30);

        lbl.setFont(plainFont3);
        lbl1.setFont(plainFont2);
        lbl2.setFont(plainFont2);
        txt1.setFont(plainFont2);
        txt2.setFont(plainFont2);
        btn1.setFont(plainFont2);
        btn2.setFont(plainFont1);
        btn3.setFont(plainFont);
        btn3.setBackground(Color.decode("#df4c85"));
        btn3.setBorder(border3);

        frame.add(lbl);
        frame.add(lbl1);
        frame.add(lbl2);
        frame.add(txt1);
        frame.add(txt2);
        frame.add(btn1);
        frame.add(btn2);
        frame.add(btn3);

        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
                String username = txt1.getText();
                String password = new String(txt2.getPassword());
                Integer len = username.length();
                Integer len1 = username.length();
                
                if (len == 0 && len1 == 0) {
                    JOptionPane.showMessageDialog(btn1, "Every Field is required!!!");
                } 
               else {
                    try {
                        Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","c##anand","814"); 

                        PreparedStatement statement = connection
                                .prepareStatement("Select * from userdataa where username=? and password=?");
                        statement.setString(1, username);
                        statement.setString(2, password);
                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(btn1, "Login successful!");
                            txt1.setText("");
                            txt2.setText("");
                            frame.dispose();
                            Admin_page1();

                        } else {
                            JOptionPane.showMessageDialog(btn1, "Invalid username or password");
                        }
                    } catch (Exception ee) {
                        ee.printStackTrace();
                    }
                }

            }

        });
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee1) {
                Registraion_page();
                frame.dispose();
            }
        });
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee36){
                
            }
        });

        frame.getContentPane().setBackground(Color.decode("#df4c85"));
        frame.setTitle("CLINIC MANAGEMENT SYSTEM");
        frame.setBounds(500, 250, 500, 300);
        frame.setLayout(null);
        frame.setVisible(true);
    }
//Registration page for user

    public void Registraion_page() {
        JFrame Frame1 = new JFrame();
        JLabel lbl = new JLabel("Registraion");
        JLabel lbl1 = new JLabel("Email-Id      : ");
        JLabel lbl2 = new JLabel("Name          : ");
        JLabel lbl3 = new JLabel("Username  :");
        JLabel lbl4 = new JLabel("Password  : ");
        JLabel lbl5 = new JLabel("Phone No. : ");
        JButton btn1 = new JButton("Registration");
        JButton btn2 = new JButton("Login Here");
        JTextField txt1 = new JTextField(35);
        JTextField txt2 = new JTextField(35);
        JTextField txt3 = new JTextField(35);
        JTextField txt5 = new JTextField(35);
        // JTextField txt5=new JTextField(35);
        JPasswordField txt4 = new JPasswordField(20);

        // Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
        // Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

        lbl.setBounds(160, 5, 300, 40);
        lbl1.setBounds(20, 70, 150, 30);
        lbl2.setBounds(20, 120, 150, 30);
        lbl3.setBounds(20, 170, 150, 30);
        lbl4.setBounds(20, 220, 150, 30);
        lbl5.setBounds(20, 270, 150, 30);
        txt1.setBounds(220, 70, 150, 30);
        txt2.setBounds(220, 120, 150, 30);
        txt3.setBounds(220, 170, 150, 30);
        txt4.setBounds(220, 220, 150, 30);
        txt5.setBounds(220, 270, 150, 30);
        btn1.setBounds(130, 350, 170, 30);
        btn2.setBounds(280, 420, 150, 30);

        lbl.setFont(plainFont2);
        lbl1.setFont(plainFont2);
        lbl2.setFont(plainFont2);
        lbl3.setFont(plainFont2);
        lbl4.setFont(plainFont2);
        lbl5.setFont(plainFont2);
        txt1.setFont(plainFont2);
        txt2.setFont(plainFont2);
        txt3.setFont(plainFont2);
        txt4.setFont(plainFont2);
        txt5.setFont(plainFont2);
        btn1.setFont(plainFont2);
        btn2.setFont(plainFont2);

        Frame1.add(lbl);
        Frame1.add(lbl1);
        Frame1.add(lbl2);
        Frame1.add(lbl3);
        Frame1.add(lbl4);
        Frame1.add(lbl5);
        Frame1.add(txt1);
        Frame1.add(txt2);
        Frame1.add(txt3);
        Frame1.add(txt4);
        Frame1.add(txt5);

        Frame1.add(btn1);
        Frame1.add(btn2);
        // Frame1.add(lbl);

        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee2) {
                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                String emial = txt1.getText();
                String name = txt2.getText();
                String username = txt3.getText();
                String password = new String(txt4.getPassword());
                String phone = txt5.getText();
                Integer len = emial.length();
                Integer len1 = name.length();
                Integer len2 = username.length();
                Integer len3 = password.length();
                Integer len4 = phone.length();
                String msg = "" + name;
                
                if (len == 0 && len1 == 0 && len2 == 0 && len3 == 0 && len4 == 0) {
                    JOptionPane.showMessageDialog(btn2, "Every fields are required!!");
                }  
                else if (!Pattern.matches(emailPattern,emial)) {
                    JOptionPane.showMessageDialog(null,
                            "Invalid email address. Please enter a valid email.", "Validation Result",
                            JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                                "Ankit@817raj#");

                        DatabaseMetaData metaData = connection.getMetaData();
                        ResultSet tables = metaData.getTables(null, null, "userdataa", null);
                        boolean tableExists = tables.next();
                        if (!tableExists) {
                            Statement statement = connection.createStatement();
                            statement.executeUpdate(
                                    "Create table userdataa(id INT AUTO_INCREMENT PRIMARY KEY,email varchar(25) not null,name varchar(25) not null,username varchar(50) not null,password varchar(30) not null,phone int(20) not null)");
                        }
                        String query1 = "INSERT INTO userdataa(email,name,username,password,phone) values('"
                                + emial + "','" + name + "','"
                                + username + "','" + password + "','" + phone + "')";

                        Statement sta = connection.createStatement();
                        int x = sta.executeUpdate(query1);

                        if (x == 0) {
                            JOptionPane.showMessageDialog(btn1, "This is alredy exist");
                        } else {
                            JOptionPane.showMessageDialog(btn1,
                                    "Congratulations " + msg + "Your Registraions sucessfully....");
                            Main_Page();
                            txt1.setText("");
                            txt2.setText("");
                            txt3.setText("");
                            txt4.setText("");
                            txt5.setText("");
                            Frame1.dispose();
                        }

                    } catch (Exception ee3) {
                        ee3.printStackTrace();
                    }
                }

            }

        });
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee32) {
                Main_Page();

                Frame1.dispose();
            }
        });

        Frame1.getContentPane().setBackground(Color.decode("#89ccec"));
        Frame1.setBounds(500, 250, 450, 500);
        Frame1.setLayout(null);
        Frame1.setVisible(true);

    }

    JFrame frame1, frame2, frame3, frame4;

    public void Admin_page1() {
        JFrame frame1 = new JFrame("WELCOME TO THE CMS PAGE");
        JLabel l1 = new JLabel("CLINIC MANAGEMENT SYSTEM");

        ImageIcon icon = (new ImageIcon(
                new ImageIcon("droom.jpg").getImage().getScaledInstance(1540, 600, Image.SCALE_SMOOTH)));

        JLabel label1 = new JLabel(icon);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 35, 10));
        JPanel buttonPanel1 = new JPanel();
        buttonPanel1.setLayout(new BoxLayout(buttonPanel1, BoxLayout.Y_AXIS));
        JLabel lbl1 = new JLabel();
        JLabel lbl2 = new JLabel();

        JButton btn1 = new JButton("DOCTOR");
        JButton btn2 = new JButton("NURSE");
        JButton btn3 = new JButton("PAIENTS");
        JButton btn4 = new JButton("CHANGE PASSWPRD");
        JButton btn5 = new JButton("FEEDBACK");
        JButton btn6 = new JButton("EXIT");
        JButton btn7 = new JButton("Logout");
        JButton btn8 = new JButton("ADMIN");

        buttonPanel.add(btn8);
        buttonPanel.add(btn1);
        buttonPanel.add(btn2);
        buttonPanel.add(btn3);
        buttonPanel.add(btn4);
        buttonPanel.add(btn5);
        buttonPanel.add(btn6);
        buttonPanel.add(btn7);

        // lbl3.setBounds(50, 20, 140, 50);
        // lbl4.setBounds(0, 90, 210, 10);
        l1.setBounds(0, 0, 1540, 100);
        buttonPanel.setBounds(0, 100, 1540, 100);
        buttonPanel1.setBounds(200, 100, 1540, 100);
        lbl1.setBounds(200, 150, 1540, 100);

        label1.setBounds(0, 140, 1540, 700);
        Font plainFont = new Font("Jumble", Font.BOLD, 50);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 25);
        Font plainFont3 = new Font("Jumble", Font.BOLD, 30);
        Border border1 = BorderFactory.createLineBorder(Color.CYAN, 20);
        Border border2 = BorderFactory.createLineBorder(Color.BLUE, 0);
        l1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        l1.setFont(plainFont);
        // lbl3.setFont(plainFont3);
        btn1.setFont(plainFont2);
        btn2.setFont(plainFont2);
        btn3.setFont(plainFont2);
        btn4.setFont(plainFont2);
        btn5.setFont(plainFont2);
        btn6.setFont(plainFont2);
        btn7.setFont(plainFont2);
        btn8.setFont(plainFont2);

        l1.setOpaque(true);
        l1.setBackground(Color.BLACK);
        l1.setForeground(Color.WHITE);
        buttonPanel.setOpaque(true);
        buttonPanel.setBackground(Color.CYAN);
        buttonPanel.setForeground(Color.WHITE);
        btn1.setBackground(Color.CYAN);
        btn2.setBackground(Color.CYAN);
        btn3.setBackground(Color.CYAN);
        btn4.setBackground(Color.CYAN);
        btn5.setBackground(Color.CYAN);
        btn6.setBackground(Color.CYAN);
        btn7.setBackground(Color.CYAN);
        btn8.setBackground(Color.CYAN);

        btn1.setForeground(Color.WHITE);
        btn2.setForeground(Color.WHITE);
        btn3.setForeground(Color.WHITE);
        btn4.setForeground(Color.WHITE);
        btn5.setForeground(Color.WHITE);
        btn6.setForeground(Color.WHITE);
        btn7.setForeground(Color.WHITE);
        btn8.setForeground(Color.WHITE);

        btn1.setBorder(border1);
        btn2.setBorder(border1);
        btn3.setBorder(border1);
        btn4.setBorder(border1);
        btn5.setBorder(border1);
        btn6.setBorder(border1);
        btn7.setBorder(border1);
        btn8.setBorder(border1);
        ;

        l1.setBorder(border1);
        l1.setHorizontalAlignment(JLabel.CENTER);

        frame1.add(l1);
        frame1.add(lbl2);
        // lbl2.add(lbl3);
        // lbl2.add(lbl4);
        frame1.add(label1);

        frame1.add(buttonPanel);
        frame1.setBounds(0, 0, 1540, 1000);
        frame1.setLayout(null);
        frame1.setVisible(true);

        btn6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee5) {
                JOptionPane.showConfirmDialog(null, "Do you want Exit!!!");
                frame1.dispose();
            }
        });

        btn7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee5) {
                JOptionPane.showConfirmDialog(null, "Do you want Logout...");
                frame1.dispose();
            }
        });
        btn8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee5) {
                Admin_page_signin();

            }
        });
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee20) {
                doctor_page_signin();

            }
        });
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee20) {
                nurse_page_signin();

            }
        });
        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee20) {
                patient_page();

            }
        });
        btn5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee36){
                JFrame fFrame= new JFrame("Feedback form......");
                JLabel lblFeedback = new JLabel("Please provide your feedback:");
        JTextArea txtFeedback = new JTextArea(5, 20);
        JButton btnSubmit = new JButton("Submit");
        GroupLayout layout = new GroupLayout(fFrame.getContentPane());
        fFrame.getContentPane().setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Set horizontal group
        GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
        hGroup.addGroup(layout.createParallelGroup()
                .addComponent(lblFeedback)
                .addComponent(txtFeedback)
                .addComponent(btnSubmit, GroupLayout.Alignment.TRAILING));
        layout.setHorizontalGroup(hGroup);

        // Set vertical group
        GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
        vGroup.addComponent(lblFeedback)
                .addComponent(txtFeedback)
                .addComponent(btnSubmit);
        layout.setVerticalGroup(vGroup);

        btnSubmit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String feedback = txtFeedback.getText();
                System.out.println("Feedback received: " + feedback);               
                JOptionPane.showMessageDialog(null, "Thank you for your feedback!","Thank You",JOptionPane.INFORMATION_MESSAGE);
                txtFeedback.setText("");
                fFrame.dispose();
                
            }
        });

                fFrame.setBounds(700, 220, 600, 400);
                fFrame.setVisible(true);
                fFrame.setResizable(false);
                fFrame.setLayout(null);

            }
        });

    }

    public void doctor_page_signin() {

        JFrame dlframe = new JFrame("Doctor Login page");
        JLabel lbldl1 = new JLabel("Login Page");
        JLabel lbldl2 = new JLabel("Username : ");
        JLabel lbldl3 = new JLabel("Password : ");
        JTextField txtdl1 = new JTextField(35);
        JPasswordField txtdl2 = new JPasswordField(20);
        JButton btndl1 = new JButton("Login");
       
        lbldl1.setBounds(140, 5, 150, 30);
        lbldl2.setBounds(10, 70, 150, 30);
        lbldl3.setBounds(10, 120, 150, 30);
        txtdl1.setBounds(150, 70, 200, 30);
        txtdl2.setBounds(150, 120, 200, 30);
        btndl1.setBounds(120, 180, 150, 30);
        Font plainFont = new Font("Jumble", Font.BOLD, 25);
        Font plainFont1 = new Font("Jumble", Font.BOLD, 20);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 13);
        lbldl1.setFont(plainFont);
        lbldl2.setFont(plainFont1);
        lbldl3.setFont(plainFont1);
        txtdl2.setFont(plainFont1);
        txtdl1.setFont(plainFont1);
        btndl1.setFont(plainFont);
        dlframe.add(lbldl1);
        dlframe.add(lbldl2);
        dlframe.add(lbldl3);
        dlframe.add(txtdl1);
        dlframe.add(txtdl2);
        dlframe.add(btndl1);
       btndl1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
                String username = txtdl1.getText();
                String password = new String(txtdl2.getPassword());
                Integer len = username.length();
                Integer len1 = username.length();
                if (len == 0 || len1 == 0) {
                    JOptionPane.showMessageDialog(btndl1, "Every Field is required!!!");
                } else {
                      try {
                        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                                "Ankit@817raj#");

                        PreparedStatement statement = connection
                                .prepareStatement("Select * from doctordata where username=? and password=?");
                        statement.setString(1, username);
                        statement.setString(2, password);
                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(btndl1, "Login successful!");
                            txtdl1.setText("");
                            txtdl2.setText("");
                            // Admin_manage();
                            dlframe.dispose();
                            JFrame dframe = new JFrame("Doctor Page");
                            JButton btnd15 = new JButton("");
                            JButton btnd1 = new JButton("MENU");
                            JButton btnd2 = new JButton("VIEW PROFILE");
                            JButton btnd3 = new JButton("UPDATE DEATILS");
                            JButton btnd4 = new JButton("TODAY APPOINTMENT");
                            JButton btnd6 = new JButton("REPORT");

                            JButton btnd5 = new JButton("BACK");

                            JButton btnd8 = new JButton("LOGOUT");

                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                            btnd1.setBounds(20, 20, 120, 40);
                            btnd2.setBounds(230, 20, 200, 40);
                            btnd3.setBounds(470, 20, 200, 40);
                            btnd4.setBounds(710, 20, 250, 40);
                            btnd6.setBounds(1000, 20, 150, 40);
                            btnd5.setBounds(1200, 20, 150, 40);

                            btnd8.setBounds(1380, 20, 100, 40);

                            btnd15.setBounds(0, 80, 1540, 5);

                            btnd1.setFont(plainFont1);
                            btnd2.setFont(plainFont1);
                            btnd3.setFont(plainFont1);
                            btnd4.setFont(plainFont1);
                            btnd5.setFont(plainFont1);

                            btnd6.setFont(plainFont1);

                            btnd8.setFont(plainFont1);

                            btnd1.setBackground(Color.GREEN);
                            btnd15.setBackground(Color.WHITE);

                            btnd1.setBorder(border3);
                            btnd1.setFont(plainFont2);

                            dframe.add(btnd1);
                            dframe.add(btnd2);
                            dframe.add(btnd3);
                            dframe.add(btnd4);
                            dframe.add(btnd5);
                            dframe.add(btnd6);

                            dframe.add(btnd8);
                            dframe.add(btnd1);

                            dframe.add(btnd15);

                            btnd2.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee18) {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM doctordata ";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        ResultSet resultSet = fetchStatement.executeQuery();

                                        if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame pvframe = new JFrame("View Profile");

                                            JLabel lbldss1 = new JLabel("Email-ID :  ");
                                            JLabel lbldss2 = new JLabel("Username : ");
                                            JLabel lbldss3 = new JLabel("Name : ");
                                            JLabel lbldss4 = new JLabel("Password: ");
                                            JLabel lbldss5 = new JLabel("Phone N0 : ");
                                            JLabel lbldss6 = new JLabel("Address : ");
                                            JLabel lbldss7 = new JLabel("DOB : ");
                                            JLabel lbldss8 = new JLabel("Doctor Degree : ");
                                            JLabel lbldss9 = new JLabel("Specializations : ");
                                            JLabel lbldss10 = new JLabel("Fees : ");
                                            JLabel lbldss11 = new JLabel("Joined Date : ");
                                            JTextField txtdss1 = new JTextField(email);
                                            JPasswordField txtdss4 = new JPasswordField(dpassword);
                                            JTextField txtdss3 = new JTextField(dname);
                                            JTextField txtdss2 = new JTextField(user_name);
                                            JTextField txtdss5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtdss6 = new JComboBox<>(adressarray);
                                            JDateChooser txtdss7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtdss8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtdss9 = new JComboBox<>(dspecialzationarray);
                                            JTextField txtdss10 = new JTextField(dfees);
                                            JDateChooser txtdss11 = new JDateChooser(djoin_date);
                                            txtdss1.setEditable(false);
                                            txtdss2.setEditable(false);
                                            txtdss3.setEditable(false);
                                            txtdss4.setEditable(false);
                                            txtdss5.setEditable(false);
                                            txtdss6.setEditable(false);
                                            // txtdss7.setEnable(false);
                                            txtdss8.setEditable(false);
                                            txtdss9.setEditable(false);
                                            txtdss10.setEditable(false);
                                            // txtdss11.setEnable(false);
                                            // txtdss12.setEditable(false);
                                            // txtdss1.setEditable(false);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btnds1 = new JButton("BACK");

                                            lbldss1.setBounds(20, 10, 200, 35);
                                            lbldss2.setBounds(440, 10, 200, 35);
                                            lbldss3.setBounds(20, 60, 200, 35);
                                            lbldss4.setBounds(440, 60, 200, 35);
                                            lbldss5.setBounds(20, 110, 200, 35);
                                            lbldss6.setBounds(440, 110, 200, 35);
                                            lbldss7.setBounds(20, 160, 200, 35);
                                            lbldss8.setBounds(440, 160, 200, 35);
                                            lbldss9.setBounds(20, 210, 200, 35);
                                            lbldss10.setBounds(440, 210, 200, 35);
                                            lbldss11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtdss1.setBounds(200, 10, 200, 35);
                                            txtdss2.setBounds(680, 10, 200, 35);
                                            txtdss3.setBounds(200, 60, 200, 35);
                                            txtdss4.setBounds(680, 60, 200, 35);
                                            txtdss5.setBounds(200, 110, 200, 35);
                                            txtdss6.setBounds(680, 110, 200, 35);
                                            txtdss7.setBounds(200, 160, 200, 35);
                                            txtdss8.setBounds(680, 160, 200, 35);
                                            txtdss9.setBounds(200, 210, 200, 35);
                                            txtdss10.setBounds(680, 210, 200, 35);
                                            txtdss11.setBounds(200, 260, 200, 35);
                                            // dxtdu12.setBounds(680, 260, 120, 35);
                                            btnds1.setBounds(300, 350, 150, 50);
                                            txtdss11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lbldss1.setFont(plainFont2);
                                            lbldss2.setFont(plainFont2);
                                            lbldss3.setFont(plainFont2);
                                            lbldss4.setFont(plainFont2);
                                            lbldss5.setFont(plainFont2);
                                            lbldss6.setFont(plainFont2);
                                            lbldss7.setFont(plainFont2);
                                            lbldss8.setFont(plainFont2);
                                            lbldss9.setFont(plainFont2);
                                            lbldss10.setFont(plainFont2);
                                            lbldss11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btnds1.setFont(plainFont2);

                                            pvframe.add(lbldss1);
                                            pvframe.add(lbldss2);
                                            pvframe.add(lbldss3);
                                            pvframe.add(lbldss4);
                                            pvframe.add(lbldss5);
                                            pvframe.add(lbldss6);
                                            pvframe.add(lbldss7);
                                            pvframe.add(lbldss8);
                                            pvframe.add(lbldss9);
                                            pvframe.add(lbldss10);
                                            pvframe.add(lbldss11);
                                            // frame6.add(lbldu12);
                                            pvframe.add(txtdss1);
                                            pvframe.add(txtdss2);
                                            pvframe.add(txtdss3);
                                            pvframe.add(txtdss4);
                                            pvframe.add(txtdss5);
                                            pvframe.add(txtdss6);
                                            pvframe.add(txtdss7);
                                            pvframe.add(txtdss8);
                                            pvframe.add(txtdss9);
                                            pvframe.add(txtdss10);
                                            pvframe.add(txtdss11);
                                            // frame6.add(txtsdu12);

                                            pvframe.add(btnds1);
                                            btnds1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee16) {
                                                    pvframe.dispose();
                                                }
                                            });

                                            pvframe.getContentPane().setBackground(Color.CYAN);

                                            pvframe.setBounds(355, 300, 1200, 500);
                                            pvframe.setLayout(null);
                                            pvframe.setVisible(true);

                                        } else {
                                            // // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            });
                            btnd3.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee19) {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM doctordata";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        ResultSet resultSet = fetchStatement.executeQuery();

                                        if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame udframe = new JFrame("Update Nurse details");

                                            JLabel lblnud1 = new JLabel("Email-ID :  ");
                                            JLabel lblnud2 = new JLabel("Username : ");
                                            JLabel lblnud3 = new JLabel("Name : ");
                                            JLabel lblnud4 = new JLabel("Password: ");
                                            JLabel lblnud5 = new JLabel("Phone N0 : ");
                                            JLabel lblnud6 = new JLabel("Address : ");
                                            JLabel lblnud7 = new JLabel("DOB : ");
                                            JLabel lblnud8 = new JLabel("Doctor Degree : ");
                                            JLabel lblnud9 = new JLabel("Specializations : ");
                                            JLabel lblnud10 = new JLabel("Fees : ");
                                            JLabel lblnud11 = new JLabel("Joined Date : ");
                                            // JLabel lbldu12 = new JLabel("Id No : ");
                                            JTextField txtnud1 = new JTextField(email);
                                            JPasswordField txtnud4 = new JPasswordField(dpassword);
                                            JTextField txtnud3 = new JTextField(dname);
                                            JTextField txtnud2 = new JTextField(user_name);
                                            JTextField txtnud5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtnud6 = new JComboBox<>(adressarray);

                                            // JTextField txtd7 = new JTextField();
                                            JDateChooser txtnud7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtnud8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtnud9 = new JComboBox<>(dspecialzationarray);

                                            JTextField txtnud10 = new JTextField(dfees);
                                            JDateChooser txtnud11 = new JDateChooser(djoin_date);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btnnud1 = new JButton("Submit");

                                            lblnud1.setBounds(20, 10, 200, 35);
                                            lblnud2.setBounds(440, 10, 200, 35);
                                            lblnud3.setBounds(20, 60, 200, 35);
                                            lblnud4.setBounds(440, 60, 200, 35);
                                            lblnud5.setBounds(20, 110, 200, 35);
                                            lblnud6.setBounds(440, 110, 200, 35);
                                            lblnud7.setBounds(20, 160, 200, 35);
                                            lblnud8.setBounds(440, 160, 200, 35);
                                            lblnud9.setBounds(20, 210, 200, 35);
                                            lblnud10.setBounds(440, 210, 200, 35);
                                            lblnud11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtnud1.setBounds(200, 10, 200, 35);
                                            txtnud2.setBounds(680, 10, 200, 35);
                                            txtnud3.setBounds(200, 60, 200, 35);
                                            txtnud4.setBounds(680, 60, 200, 35);
                                            txtnud5.setBounds(200, 110, 200, 35);
                                            txtnud6.setBounds(680, 110, 200, 35);
                                            txtnud7.setBounds(200, 160, 200, 35);
                                            txtnud8.setBounds(680, 160, 200, 35);
                                            txtnud9.setBounds(200, 210, 200, 35);
                                            txtnud10.setBounds(680, 210, 200, 35);
                                            txtnud11.setBounds(200, 260, 200, 35);
                                            // txtdu12.setBounds(680, 260, 120, 35);
                                            btnnud1.setBounds(300, 350, 150, 50);
                                            txtnud11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lblnud1.setFont(plainFont2);
                                            lblnud2.setFont(plainFont2);
                                            lblnud3.setFont(plainFont2);
                                            lblnud4.setFont(plainFont2);
                                            lblnud5.setFont(plainFont2);
                                            lblnud6.setFont(plainFont2);
                                            lblnud7.setFont(plainFont2);
                                            lblnud8.setFont(plainFont2);
                                            lblnud9.setFont(plainFont2);
                                            lblnud10.setFont(plainFont2);
                                            lblnud11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btnnud1.setFont(plainFont2);
                                            udframe.add(lblnud1);
                                            udframe.add(lblnud2);
                                            udframe.add(lblnud3);
                                            udframe.add(lblnud4);
                                            udframe.add(lblnud5);
                                            udframe.add(lblnud6);
                                            udframe.add(lblnud7);
                                            udframe.add(lblnud8);
                                            udframe.add(lblnud9);
                                            udframe.add(lblnud10);
                                            udframe.add(lblnud11);
                                            // frame6.add(nbldu12);
                                            udframe.add(txtnud1);
                                            udframe.add(txtnud2);
                                            udframe.add(txtnud3);
                                            udframe.add(txtnud4);
                                            udframe.add(txtnud5);
                                            udframe.add(txtnud6);
                                            udframe.add(txtnud7);
                                            udframe.add(txtnud8);
                                            udframe.add(txtnud9);
                                            udframe.add(txtnud10);
                                            udframe.add(txtnud11);
                                            // frame6.add(txtdu12);

                                            udframe.add(btnnud1);
                                            btnnud1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee13) {
                                                    Date newdob = txtnud11.getDate();
                                                    String newDobDate = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob);
                                                    Date newdob1 = txtnud7.getDate();
                                                    String newDob1Date = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob1);

                                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                                    String formattedDob = dateFormat.format(newdob);
                                                    String formattedDob1 = dateFormat.format(newdob1);

                                                    String newemail_id = txtnud1.getText();
                                                    String newusername = txtnud2.getText();
                                                    String msg = "" + username;
                                                    String newname = txtnud3.getText();
                                                    String newphoneno = txtnud5.getText();
                                                    String newpassword = new String(txtnud4.getPassword());
                                                    String newaddress = (String) txtnud6.getSelectedItem();
                                                    String newdegree = (String) txtnud8.getSelectedItem();
                                                    String newspecializations = (String) txtnud9.getSelectedItem();
                                                    String newfees = txtnud10.getText();
                                                    // String Idno = txtdu12.getText();

                                                    String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                                    int len = newemail_id.length();
                                                    int len1 = newname.length();
                                                    int len2 = newpassword.length();
                                                    int len3 = newfees.length();
                                                    int len4 = newusername.length();
                                                    int len5 = newphoneno.length();
                                                    // int len6 = Idno.length();
                                                    if (newdob == null) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please Choose Your joined date",
                                                                "Empty fileds", JOptionPane.ERROR_MESSAGE);
                                                    }else if(len5
                                                    !=10){
                                                        JOptionPane.showMessageDialog(null, "Please enter valid mobile no",
                                                                "Empty Fields",
                                                                JOptionPane.ERROR_MESSAGE);


                                                    } 
                                                    else if (newdob1 == null) {
                                                        JOptionPane.showMessageDialog(null, "Please choose your Dob.",
                                                                "Empty Fields",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    }

                                                    else if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0
                                                            || len4 == 0) {
                                                        JOptionPane.showMessageDialog(null, "Every Filed is required",
                                                                "Empty fileds",
                                                                JOptionPane.ERROR_MESSAGE);

                                                    } else if (!Pattern.matches(emailPattern, newemail_id)) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Invalid email address. Please enter a valid email.",
                                                                "Validation Result",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    } else if (len5 != 10) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please enter the valid mobile no",
                                                                "less than 10", JOptionPane.ERROR_MESSAGE);

                                                    } else {
                                                        try {
                                                            Connection connection = DriverManager.getConnection(
                                                                    "jdbc:mysql://localhost:3306/CMS", "root",
                                                                    "Ankit@817raj#");

                                                            String updateQuery = "UPDATE doctordata SET email = ?, username = ?, name = ?, password = ?, phoneno = ?, address = ?, dob = ?, degree = ?, specilizations = ?, fees = ?, jdate = ? WHERE username = ?";

                                                            PreparedStatement updateStatement = connection
                                                                    .prepareStatement(updateQuery);
                                                            // updateStatement.setString(1, username);
                                                            updateStatement.setString(1, newemail_id);
                                                            updateStatement.setString(2, newusername);
                                                            updateStatement.setString(3, newname);
                                                            updateStatement.setString(4, newpassword);
                                                            updateStatement.setString(5, newphoneno);
                                                            updateStatement.setString(6, newaddress);
                                                            updateStatement.setString(7, newDobDate);
                                                            updateStatement.setString(8, newdegree);
                                                            updateStatement.setString(9, newspecializations);
                                                            updateStatement.setString(10, newfees);
                                                            updateStatement.setString(11, newDob1Date);
                                                            // updateStatement.setString(12, newIdNo);
                                                            updateStatement.setString(12, username);

                                                            int rowsAffected = updateStatement.executeUpdate();

                                                            if (rowsAffected > 0) {
                                                                JOptionPane.showMessageDialog(null,
                                                                        "Update successfully",
                                                                        "Update data", JOptionPane.ERROR_MESSAGE);
                                                                udframe.dispose();
                                                            } else {

                                                            }

                                                        } catch (Exception ee3) {
                                                            ee3.printStackTrace();
                                                        }

                                                    }

                                                }
                                            });

                                            udframe.getContentPane().setBackground(Color.CYAN);

                                            udframe.setBounds(225, 265, 1330, 600);
                                            udframe.setLayout(null);
                                            udframe.setVisible(true);

                                        } else {
                                            // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }
                            });

                            btnd4.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee21) {
                                    JFrame pdframe = new JFrame("Patient Data");
                                    JTable table = new JTable();
                                    DefaultTableModel model = new DefaultTableModel() {
                                        @Override
                                        public boolean isCellEditable(int row, int column) {
                                            return false;
                                        }
                                    };

                                    model.addColumn("ID");
                                    model.addColumn("Name");
                                    model.addColumn("Father/Mother Name");
                                    model.addColumn("Age");
                                    model.addColumn("Date");
                                    model.addColumn("Gender");
                                    model.addColumn("Occupation");
                                    model.addColumn("Marital Status");
                                    model.addColumn("Contact No");
                                    model.addColumn("Address");

                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                "Ankit@817raj#");
                                        Statement statement = connection.createStatement();

                                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                        String todayDate = dateFormat.format(new Date());

                                        ResultSet resultSet = statement.executeQuery(
                                                "SELECT * FROM patient_info WHERE DATE_FORMAT(dob, '%Y-%m-%d') = '"
                                                        + todayDate + "'");

                                        while (resultSet.next()) {
                                            model.addRow(new Object[] {
                                                    resultSet.getInt("id"),
                                                    resultSet.getString("name"),
                                                    resultSet.getString("fname"),
                                                    resultSet.getString("age"),
                                                    resultSet.getString("dob"),
                                                    resultSet.getString("gender"),
                                                    resultSet.getString("occupation"),
                                                    resultSet.getString("marital_status"),
                                                    resultSet.getString("contact_no"),
                                                    resultSet.getString("address"),
                                            });
                                        }
                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                    table.setModel(model);

                                    JTableHeader header = table.getTableHeader();
                                    header.setFont(new Font("Jumble", Font.BOLD, 18));
                                    header.setForeground(Color.RED);

                                    TableCellRenderer renderer = table.getDefaultRenderer(Object.class);
                                    table.setDefaultRenderer(Object.class,
                                            (JTable table1, Object value, boolean isSelected, boolean hasFocus, int row,
                                                    int column) -> {
                                                Component component = renderer.getTableCellRendererComponent(table1,
                                                        value, isSelected,
                                                        hasFocus, row, column);
                                                component.setFont(new Font("Jumble", Font.BOLD, 14));
                                                component.setForeground(Color.BLUE);
                                                return component;
                                            });

                                    // Add ListSelectionListener to the table
                                    table.getSelectionModel().addListSelectionListener(e -> {
                                        if (!e.getValueIsAdjusting()) {
                                            int selectedRow = table.getSelectedRow();
                                            if (selectedRow >= 0) {
                                                try {
                                                    // Get data of the selected row
                                                    int id = (int) model.getValueAt(selectedRow, 0);
                                                    String name = (String) model.getValueAt(selectedRow, 1);
                                                    String fname = (String) model.getValueAt(selectedRow, 2);
                                                    String age = (String) model.getValueAt(selectedRow, 3);
                                                    String dob = (String) model.getValueAt(selectedRow, 4);
                                                    String gender = (String) model.getValueAt(selectedRow, 5);
                                                    String occupation = (String) model.getValueAt(selectedRow, 6);
                                                    String maritalStatus = (String) model.getValueAt(selectedRow, 7);
                                                    String contactNo = (String) model.getValueAt(selectedRow, 8);
                                                    String address = (String) model.getValueAt(selectedRow, 9);

                                                    // Close the current frame
                                                    pdframe.dispose();

                                                    // Create a new JFrame when a row is selected
                                                    JFrame detailFrame = new JFrame("Details");
                                                    // detailFrame.setBounds(220, 260, 1320, 600);
                                                    // detailFrame.getContentPane().setBackground(Color.decode("#f8faf9"));
                                                    // detailFrame.setLayout(null);
                                                    // detailFrame.setVisible(true);

                                                    try {
                                                        Connection connection = DriverManager.getConnection(
                                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                                "Ankit@817raj#");

                                                        String fetchQuery = "SELECT name  FROM doctordata where username=?";

                                                        PreparedStatement fetchStatement = connection
                                                                .prepareStatement(fetchQuery);
                                                        fetchStatement.setString(1, username);
                                                        // ResultSet resultSet = fetchStatement.executeQuery();
                                                        ResultSet resultSet = fetchStatement.executeQuery();
                                                        if (resultSet.next()) {
                                                            String dname = resultSet.getString("name");
                                                            JLabel dnlbl1 = new JLabel("Doctor Name: ");
                                                            JTextField dntxt1 = new JTextField(dname);
                                                            dnlbl1.setBounds(600, 70, 250, 30);
                                                            dntxt1.setBounds(900, 70, 250, 30);
                                                            detailFrame.add(dnlbl1);
                                                            detailFrame.add(dntxt1);
                                                            dntxt1.setEditable(false);
                                                            Font f3 = new Font("Jumble", Font.BOLD, 25);
                                                            dntxt1.setFont(f3);
                                                            dnlbl1.setFont(f3);
                                                            txtdl1.setForeground(Color.BLUE);
                                                            dnlbl1.setForeground(Color.BLUE);

                                                        }

                                                    } catch (Exception ee28) {
                                                        ee28.printStackTrace();
                                                    }

                                                    // Add labels to display data
                                                    JLabel lblId = new JLabel("ID: " + id);
                                                    JLabel lblName = new JLabel("Name: " + name);
                                                    JLabel lblFname = new JLabel("Father/Mother Name: " + fname);
                                                    JLabel lblAge = new JLabel("Age: " + age);
                                                    JLabel lblDob = new JLabel("Date: " + dob);
                                                    JLabel lblGender = new JLabel("Gender: " + gender);
                                                    JLabel lblOccupation = new JLabel("Occupation: " + occupation);
                                                    JLabel lblMaritalStatus = new JLabel(
                                                            "Marital Status: " + maritalStatus);
                                                    JLabel lblContactNo = new JLabel("Contact No: " + contactNo);
                                                    JLabel lblAddress = new JLabel("Address: " + address);
                                                    JTextField dntxt1;

                                                    // Set bounds for labels
                                                    lblId.setBounds(20, 20, 300, 30);
                                                    lblName.setBounds(20, 70, 300, 30);
                                                    lblFname.setBounds(20, 120, 300, 30);
                                                    lblAge.setBounds(20, 170, 300, 30);
                                                    lblDob.setBounds(20, 220, 300, 30);
                                                    lblGender.setBounds(20, 270, 300, 30);
                                                    lblOccupation.setBounds(20, 320, 300, 30);
                                                    lblMaritalStatus.setBounds(20, 370, 300, 30);
                                                    lblContactNo.setBounds(20, 420, 300, 30);
                                                    lblAddress.setBounds(20, 470, 300, 30);
                                                    Font f2 = new Font("Jumble", Font.BOLD, 20);
                                                    lblId.setFont(f2);
                                                    lblName.setFont(f2);
                                                    lblFname.setFont(f2);
                                                    lblAge.setFont(f2);
                                                    lblDob.setFont(f2);
                                                    lblGender.setFont(f2);
                                                    lblOccupation.setFont(f2);
                                                    lblMaritalStatus.setFont(f2);
                                                    lblContactNo.setFont(f2);
                                                    lblAddress.setFont(f2);

                                                    JLabel pplbl1 = new JLabel("Choose Your Issue : ");
                                                    JLabel pplbl2 = new JLabel("Any Other Isssue: ");
                                                    JLabel pplbl3 = new JLabel("Tablate Name: ");
                                                    JLabel pplbl4 = new JLabel("Reg. No: ");
                                                    JButton ppbtn = new JButton("SUBMIT");
                                                    String item[] = { "Fever", "Mental Health", "HIV", "AIDS",
                                                            "Diabetes", "Cold" };
                                                    JComboBox<String> pptxt1 = new JComboBox<>(item);
                                                    JTextField pptxt2 = new JTextField();
                                                    JTextField pptxt3 = new JTextField(50);
                                                    JTextField pptxt4 = new JTextField(5);
                                                    pplbl1.setBounds(600, 120, 350, 30);
                                                    pplbl2.setBounds(600, 170, 350, 30);
                                                    pplbl3.setBounds(600, 220, 350, 30);
                                                    pplbl4.setBounds(600, 270, 350, 30);
                                                    pptxt1.setBounds(1010, 120, 180, 30);
                                                    pptxt2.setBounds(1010, 170, 180, 30);
                                                    pptxt3.setBounds(1010, 220, 180, 30);
                                                    pptxt4.setBounds(1010, 270, 180, 30);
                                                    ppbtn.setBounds(800, 350, 180, 30);
                                                    pptxt1.setFont(f2);
                                                    pptxt2.setFont(f2);
                                                    pptxt3.setFont(f2);
                                                    pplbl1.setFont(f2);
                                                    pplbl2.setFont(f2);
                                                    pplbl3.setFont(f2);
                                                    pptxt4.setFont(f2);
                                                    pplbl4.setFont(f2);
                                                    ppbtn.setFont(f2);

                                                    // Add labels to the detailFrame
                                                    detailFrame.add(lblId);
                                                    detailFrame.add(lblName);
                                                    detailFrame.add(lblFname);
                                                    detailFrame.add(lblAge);
                                                    detailFrame.add(lblDob);
                                                    detailFrame.add(lblGender);
                                                    detailFrame.add(lblOccupation);
                                                    detailFrame.add(lblMaritalStatus);
                                                    detailFrame.add(lblContactNo);
                                                    detailFrame.add(lblAddress);
                                                    detailFrame.add(pplbl1);
                                                    detailFrame.add(pplbl3);
                                                    detailFrame.add(pptxt1);
                                                    detailFrame.add(pptxt3);
                                                    detailFrame.add(pplbl2);
                                                    detailFrame.add(pptxt2);
                                                    detailFrame.add(pplbl4);
                                                    detailFrame.add(pptxt4);
                                                    detailFrame.add(ppbtn);
                                                    ppbtn.addActionListener(new ActionListener() {
                                                        public void actionPerformed(ActionEvent ee28) {

                                                            // Define variables to store the data
                                                            // String patient_id=lblId.getText();
                                                            // int patient_id = 1;
                                                            String patientName = lblName.getText().replace("Name: ",
                                                                    "");
                                                            String fmName = lblFname.getText()
                                                                    .replace("Father/Mother Name: ", "");
                                                            String age = lblAge.getText().replace("Age: ", "");
                                                            String date = lblDob.getText().replace("Date: ", "");
                                                            String gender = lblGender.getText().replace("Gender: ", "");
                                                            String occupation = lblOccupation.getText()
                                                                    .replace("Occupation: ", "");
                                                            String maritalStatus = lblMaritalStatus.getText()
                                                                    .replace("Marital Status: ", "");
                                                            String contactNo = lblContactNo.getText()
                                                                    .replace("Contact No: ", "");
                                                            String address = lblAddress.getText().replace("Address: ",
                                                                    "");
                                                            // String doctorName = dntxt1.getText(); // Retrieve from
                                                            // JTextField dntxt1
                                                            String issue = pptxt1.getSelectedItem().toString(); // Retrieve
                                                                                                                // from
                                                                                                                // JComboBox
                                                                                                                // pptxt1
                                                            String otherIssue = pptxt2.getText(); // Retrieve from
                                                                                                  // JTextField pptxt2
                                                            String tabletName = pptxt3.getText(); // Retrieve from
                                                                                                  // JTextField pptxt3
                                                            String regNo = pptxt4.getText(); // Retrieve from JTextField
                                                                                             // pptxt4

                                                            try {
                                                                Connection connection = DriverManager.getConnection(
                                                                        "jdbc:mysql://localhost:3306/CMS", "root",
                                                                        "Ankit@817raj#");

                                                                // Define the SQL query to create a table
                                                                DatabaseMetaData metaData = connection.getMetaData();
                                                                ResultSet tables = metaData.getTables(null, null,
                                                                        "patient_detail", null);
                                                                boolean tableExists = tables.next();
                                                                if (!tableExists) {
                                                                   

                                                                    String createTableQuery = "CREATE TABLE patient_detail ("
                                                                            + "patient_id INT PRIMARY KEY  auto_increment,"
                                                                            + "patient_name VARCHAR(255),"
                                                                            + "f_m_name VARCHAR(255),"
                                                                            + "age INT(10),"
                                                                            + "date DATE,"
                                                                            + "gender VARCHAR(10),"
                                                                            + "occupation VARCHAR(255),"
                                                                            + "marital_status VARCHAR(20),"
                                                                            + "contact_no VARCHAR(15),"
                                                                            + "address VARCHAR(255),"

                                                                            + "issue VARCHAR(255),"
                                                                            + "other_issue VARCHAR(255),"
                                                                            + "tablet_name VARCHAR(255),"
                                                                            + "reg_no VARCHAR(10)) UNIQUE";

                                                                    Statement statement = connection.createStatement();

                                                                    // Execute the query to create the table
                                                                    statement.executeUpdate(createTableQuery);

                                                                    // Close the statement
                                                                    statement.close();
                                                                }

                                                                // Now, let's insert data into the table
                                                                String insertDataQuery = "INSERT INTO patient_detail ( patient_name, f_m_name, age, date, gender, "
                                                                        + "occupation, marital_status, contact_no, address, issue, other_issue, tablet_name, reg_no) "
                                                                        + "VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                                                                PreparedStatement insertStatement = connection
                                                                        .prepareStatement(insertDataQuery);

                                                                // Set the values based on the data from your
                                                                // detailFrame
                                                                // insertStatement.setInt(1, patient_id);
                                                                insertStatement.setString(1, patientName);
                                                                insertStatement.setString(2, fmName);
                                                                insertStatement.setInt(3, Integer.parseInt(age)); // Convert
                                                                                                                  // age
                                                                                                                  // to
                                                                                                                  // int
                                                                insertStatement.setString(4, date);
                                                                insertStatement.setString(5, gender);
                                                                insertStatement.setString(6, occupation);
                                                                insertStatement.setString(7, maritalStatus);
                                                                insertStatement.setString(8, contactNo);
                                                                insertStatement.setString(9, address);
                                                                // insertStatement.setString(11, doctorName);
                                                                insertStatement.setString(10, issue);
                                                                insertStatement.setString(11, otherIssue);
                                                                insertStatement.setString(12, tabletName);
                                                                insertStatement.setString(13, regNo);

                                                                // Execute the insert statement
                                                                insertStatement.executeUpdate();

                                                                // Close the insert statement and connection
                                                                insertStatement.close();
                                                                connection.close();

                                                                // Inform the user that data has been inserted
                                                                JOptionPane.showMessageDialog(null,
                                                                        "Data inserted successfully!");
                                                                detailFrame.dispose();

                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                        }
                                                    });

                                                    detailFrame.setBounds(220, 260, 1320, 600);
                                                    detailFrame.getContentPane().setBackground(Color.decode("#f8faf9"));
                                                    detailFrame.setLayout(null);
                                                    detailFrame.setVisible(true);

                                                } catch (Exception ex) {
                                                    ex.printStackTrace();
                                                }
                                            }
                                        }
                                    });

                                    JScrollPane scrollPane = new JScrollPane(table);
                                    pdframe.add(scrollPane);
                                    pdframe.getContentPane().setBackground(Color.decode("#29bf86"));
                                    pdframe.setBounds(220, 260, 1320, 600);
                                    pdframe.setVisible(true);
                                }

                            });
                            btnd6.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee26) {
                                    // Create a new JFrame for displaying patient details
                                    JFrame detailFrame = new JFrame("Patient Details");
                                    detailFrame.setBounds(100, 300, 1400, 900);
                                    detailFrame.getContentPane().setBackground(Color.decode("#b9c2c2"));
                                    detailFrame.setLayout(null);

                                    // Create input components
                                    JLabel lblId = new JLabel("Enter Your IdNo.:");
                                    JTextField txtId = new JTextField();
                                    JButton btnFetch = new JButton("OK");

                                    lblId.setBounds(250, 5, 250, 30);
                                    txtId.setBounds(550, 5, 160, 30);
                                    lblId.setForeground(Color.WHITE);
                                    txtId.setForeground(Color.BLUE);
                                    btnFetch.setForeground(Color.RED);

                                    btnFetch.setBounds(800, 5, 100, 30);
                                    // btnframe.getContentPane().setBackground(Color.decode("#29bf86"));

                                    // Define labels for displaying patient details
                                    JLabel notelbl1 = new JLabel("Note 1: You must be meet after one week.");
                                    JLabel notelbl2 = new JLabel("Note 2: All the best, get well soon..");

                                    JLabel lblPatientId = new JLabel("Patient ID:");
                                    JLabel lblPatientName = new JLabel("Patient Name:");
                                    JLabel lblFmName = new JLabel("Father/Mother Name:");
                                    JLabel lblAge = new JLabel("Age:");
                                    JLabel lbldate = new JLabel("Date:");
                                    JLabel lblgender = new JLabel("Gender:");
                                    JLabel Occupation = new JLabel("Occupation");
                                    JLabel Status = new JLabel("Satus:");
                                    JLabel contactNo = new JLabel("Contact No");
                                    JLabel Address = new JLabel("Address:");
                                    JLabel Issue = new JLabel("Issue");
                                    JLabel OIssue = new JLabel("Other issue");
                                    JLabel Medicine = new JLabel("Medicine Name :");
                                    JLabel RegNo = new JLabel("Reg. No:");
                                    // String dname = resultSet.getString("name");
                                    JLabel dnlbl1 = new JLabel("Doctor Name: ");

                                    // Add more labels for other details...

                                    // Set bounds for the detail labels
                                    notelbl1.setBounds(20, 400, 1000, 20);
                                    notelbl2.setBounds(20, 450, 1000, 20);

                                    RegNo.setBounds(20, 20, 120, 30);
                                    lblPatientId.setBounds(20, 70, 300, 30);
                                    lblPatientName.setBounds(20, 120, 300, 30);
                                    lblFmName.setBounds(20, 170, 300, 30);
                                    lblAge.setBounds(20, 220, 300, 30);
                                    lbldate.setBounds(20, 270, 300, 30);
                                    lbldate.setBounds(20, 320, 300, 30);
                                    lblgender.setBounds(550, 70, 300, 30);
                                    Occupation.setBounds(550, 120, 300, 30);
                                    Status.setBounds(550, 170, 300, 30);
                                    contactNo.setBounds(550, 220, 300, 30);
                                    Address.setBounds(550, 270, 300, 30);
                                    Issue.setBounds(550, 320, 300, 30);
                                    OIssue.setBounds(20, 370, 300, 20);
                                    Medicine.setBounds(550, 370, 300, 30);
                                    dnlbl1.setBounds(800, 70, 250, 30);
                                    // RegNo.setBounds(20,);

                                    // Set bounds for other detail labels...

                                    // Add detail labels to the detailFrame
                                    detailFrame.add(lblPatientId);
                                    detailFrame.add(lblPatientName);
                                    detailFrame.add(lblFmName);
                                    detailFrame.add(lblAge);
                                    detailFrame.add(lbldate);
                                    detailFrame.add(lblgender);
                                    detailFrame.add(Occupation);
                                    detailFrame.add(Status);
                                    detailFrame.add(contactNo);
                                    detailFrame.add(Address);
                                    detailFrame.add(Issue);
                                    detailFrame.add(OIssue);
                                    detailFrame.add(Medicine);
                                    detailFrame.add(RegNo);
                                    // detailFrame.add(lbldate);
                                    // detailFrame.add(lbldate);

                                    // Add other detail labels...
                                    Font jumbleFont = new Font("Jumble", Font.BOLD, 18);

                                    lblPatientId.setFont(jumbleFont);
                                    lblPatientName.setFont(jumbleFont);
                                    lblFmName.setFont(jumbleFont);
                                    lblAge.setFont(jumbleFont);
                                    lbldate.setFont(jumbleFont);
                                    lblgender.setFont(jumbleFont);
                                    Occupation.setFont(jumbleFont);
                                    Status.setFont(jumbleFont);
                                    contactNo.setFont(jumbleFont);
                                    Address.setFont(jumbleFont);
                                    Issue.setFont(jumbleFont);
                                    OIssue.setFont(jumbleFont);
                                    Medicine.setFont(jumbleFont);
                                    RegNo.setFont(jumbleFont);
                                    lblId.setFont(jumbleFont);
                                    txtId.setFont(jumbleFont);
                                    btnFetch.setFont(jumbleFont);

                                    // Set visibility of detail labels to false initially
                                    lblPatientId.setVisible(false);
                                    lblPatientName.setVisible(false);
                                    lblFmName.setVisible(false);
                                    lblAge.setVisible(false);
                                    lblgender.setVisible(false);
                                    Occupation.setVisible(false);
                                    Issue.setVisible(false);
                                    OIssue.setVisible(false);
                                    Status.setVisible(false);
                                    contactNo.setVisible(false);
                                    Address.setVisible(false);
                                    Medicine.setVisible(false);
                                    lbldate.setVisible(false);
                                    RegNo.setVisible(false);
                                    dnlbl1.setVisible(false);
                                    notelbl1.setVisible(false);
                                    notelbl2.setVisible(false);

                                    // Set visibility for other detail labels...

                                    // Add components to the detailFrame
                                    detailFrame.add(lblId);
                                    detailFrame.add(txtId);
                                    detailFrame.add(btnFetch);
                                    // detailFrame.add(dnlbl1);
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                "Ankit@817raj#");

                                        String fetchQuery = "SELECT name  FROM doctordata where username=?";

                                        PreparedStatement fetchStatement = connection
                                                .prepareStatement(fetchQuery);
                                        fetchStatement.setString(1, username);
                                        // ResultSet resultSet = fetchStatement.executeQuery();
                                        ResultSet resultSet = fetchStatement.executeQuery();
                                        if (resultSet.next()) {
                                            String dname = resultSet.getString("name");
                                            // JLabel dnlbl1 = new JLabel("Doctor Name: ");
                                            JTextField dntxt1 = new JTextField(dname);

                                            dntxt1.setBounds(1100, 70, 200, 30);
                                            detailFrame.add(dnlbl1);
                                            detailFrame.add(dntxt1);
                                            dntxt1.setEditable(false);
                                            Font f3 = new Font("Jumble", Font.BOLD, 25);
                                            dntxt1.setFont(f3);
                                            dnlbl1.setFont(f3);
                                            txtdl1.setForeground(Color.BLUE);
                                            dnlbl1.setForeground(Color.BLUE);
                                            // detailFrame.add(txtdl1);
                                            dnlbl1.setVisible(true);

                                        }

                                    } catch (Exception ee28) {
                                        ee28.printStackTrace();
                                    }

                                    // Action listener for the Fetch Data button
                                    btnFetch.addActionListener(new ActionListener() {
                                        public void actionPerformed(ActionEvent ee28) {
                                            try {
                                                Connection connection = DriverManager.getConnection(
                                                        "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                                String pid = txtId.getText();
                                                String updateQuery = "SELECT * FROM patient_detail WHERE patient_id = ?";
                                                PreparedStatement updateStatement = connection
                                                        .prepareStatement(updateQuery);
                                                updateStatement.setString(1, pid);

                                                ResultSet resultSet = updateStatement.executeQuery();

                                                if (resultSet.next()) {
                                                    // Fetch patient details from the result set
                                                    int patient_id = resultSet.getInt("patient_id");
                                                    String patient_name = resultSet.getString("patient_name");
                                                    String fm_name = resultSet.getString("f_m_name");
                                                    int age = resultSet.getInt("age");
                                                    Date date = resultSet.getDate("date");
                                                    String Gender = resultSet.getString("gender");
                                                    String occupation = resultSet.getString("occupation");
                                                    String Staus = resultSet.getString("marital_status");
                                                    String ContactNo = resultSet.getString("contact_no");
                                                    String address = resultSet.getString("address");
                                                    String issue = resultSet.getString("issue");
                                                    String Other = resultSet.getString("other_issue");
                                                    String medicine = resultSet.getString("tablet_name");
                                                    String reg_no = resultSet.getString("reg_no");

                                                    // Set the text of detail labels with the fetched data
                                                    lblPatientId.setText("Patient ID : " + patient_id);
                                                    lblPatientName.setText("Patient Name : " + patient_name);
                                                    lblFmName.setText("Father/Mother Name : " + fm_name);
                                                    lblAge.setText("Age : " + age);
                                                    lblgender.setText("Gender : " + Gender);
                                                    Occupation.setText("Occupation : " + occupation);
                                                    lbldate.setText("Date: " + date.toString());
                                                    Status.setText("Material Status :" + Staus);
                                                    contactNo.setText("Phone No : " + ContactNo);
                                                    Address.setText("Address : " + address);
                                                    Issue.setText("Issue: " + issue);
                                                    OIssue.setText("Other Issue : " + Other);
                                                    Medicine.setText("Mediiene : " + medicine);
                                                    RegNo.setText("Reg. No : " + reg_no);

                                                    // Set the visibility of detail labels to true
                                                    lblId.setVisible(false);
                                                    btnFetch.setVisible(false);
                                                    txtId.setVisible(false);

                                                    lblPatientId.setVisible(true);
                                                    lblPatientName.setVisible(true);
                                                    lblFmName.setVisible(true);
                                                    lblAge.setVisible(true);
                                                    lblgender.setVisible(true);
                                                    Occupation.setVisible(true);
                                                    lbldate.setVisible(true);
                                                    Status.setVisible(true);
                                                    RegNo.setVisible(true);
                                                    contactNo.setVisible(true);
                                                    Address.setVisible(true);
                                                    Issue.setVisible(true);
                                                    OIssue.setVisible(true);
                                                    Medicine.setVisible(true);
                                                    RegNo.setVisible(true);
                                                    notelbl1.setVisible(true);
                                                    notelbl2.setVisible(true);
                                                    // Issue.setVisible(false);

                                                } else {
                                                    JOptionPane.showMessageDialog(null,
                                                            "No record found for the provided ID.");
                                                }

                                                updateStatement.close();
                                                connection.close();

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });

                                    // Make the detailFrame visible
                                    detailFrame.setVisible(true);
                                }
                            });
                            btnd8.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee34){
                                    dframe.dispose();

                                }
                                
                            });
                             btnd5.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee34){
                                    dframe.dispose();
                                    Admin_page1();

                                }
                                
                            });


                            dframe.getContentPane().setBackground(Color.RED);
                            dframe.setBounds(0, 130, 1540, 900);
                            dframe.setLayout(null);
                            dframe.setVisible(true);
                            // nlframe.dispose();

                        } else {
                            JOptionPane.showMessageDialog(btndl1, "Invalid username or password");
                        }
                    } catch (Exception ee) {
                        ee.printStackTrace();
                    }
                }

            }

        });

        //

        //
        dlframe.getContentPane().setBackground(Color.decode("#fae607"));
        dlframe.setBounds(300, 250, 450, 300);
        dlframe.setLayout(null);
        dlframe.setVisible(true);

    }

    public void nurse_page_signin() {

        JFrame nlframe = new JFrame("Nurse Login page");
        JLabel lblnl1 = new JLabel("Login Page");
        JLabel lblnl2 = new JLabel("Username : ");
        JLabel lblnl3 = new JLabel("Password : ");
        JTextField txtnl1 = new JTextField(35);
        JPasswordField txtnl2 = new JPasswordField(20);
        JButton btnnl1 = new JButton("Login");
        // JButton btn2 = new JButton("Forgot password");
        // JButton btn3 = new JButton("SignUp");
        lblnl1.setBounds(140, 5, 150, 30);
        lblnl2.setBounds(10, 70, 150, 30);
        lblnl3.setBounds(10, 120, 150, 30);
        txtnl1.setBounds(150, 70, 200, 30);
        txtnl2.setBounds(150, 120, 200, 30);
        btnnl1.setBounds(120, 180, 150, 30);
        // btndl3.setBounds(300, 220, 80, 30);
        // btndl2.setBounds(200, 153, 150, 30);

        Font plainFont = new Font("Jumble", Font.BOLD, 25);
        Font plainFont1 = new Font("Jumble", Font.BOLD, 20);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 13);
        // Font plainFont3 = new Font("Jumble", Font.BOLD, 16);
        lblnl1.setFont(plainFont);

        lblnl2.setFont(plainFont1);
        lblnl3.setFont(plainFont1);
        txtnl2.setFont(plainFont1);
        txtnl1.setFont(plainFont1);
        btnnl1.setFont(plainFont);
        // btn2.setFont(plainFont2);
        // btn3.setFont(plainFont2);

        nlframe.add(lblnl1);
        nlframe.add(lblnl2);
        nlframe.add(lblnl3);
        nlframe.add(txtnl1);
        nlframe.add(txtnl2);
        nlframe.add(btnnl1);
        // dlframe.add(btndl2);
        // dlframe.add(btndl3);
        btnnl1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
                String username = txtnl1.getText();
                String password = new String(txtnl2.getPassword());
                Integer len = username.length();
                Integer len1 = username.length();
                if (len == 0 || len1 == 0) {
                    JOptionPane.showMessageDialog(btnnl1, "Every Field is required!!!");
                } else {
                    // JOptionPane.showMessageDialog(btn1,"Every Field is required!!!");

                    try {
                        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                                "Ankit@817raj#");

                        PreparedStatement statement = connection
                                .prepareStatement("Select * from nursedata where username=? and password=?");
                        statement.setString(1, username);
                        statement.setString(2, password);
                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(btnnl1, "Login successful!");
                            txtnl1.setText("");
                            txtnl2.setText("");
                            JFrame nframe = new JFrame("Nurse Page");
                            JButton btnn15 = new JButton("");
                            JButton btnn1 = new JButton("MENU");
                            JButton btnn2 = new JButton("VIEW PROFILE");
                            JButton btnn3 = new JButton("UPDATE DEATILS");
                            JButton btnn4 = new JButton("TODAY APPOINTMENT");
                            JButton btnn6 = new JButton("REPORT");

                            JButton btnn5 = new JButton("BACK");
                            JButton btnn8 = new JButton("LOGOUT");

                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                            btnn1.setBounds(20, 20, 120, 40);
                            btnn2.setBounds(230, 20, 200, 40);
                            btnn3.setBounds(470, 20, 200, 40);
                            btnn4.setBounds(710, 20, 250, 40);
                            btnn5.setBounds(1200, 20, 150, 40);
                            btnn6.setBounds(1000, 20, 150, 40);
                           

                            btnn8.setBounds(1380, 20, 100, 40);

                            btnn15.setBounds(0, 80, 1540, 5);

                            btnn1.setFont(plainFont1);
                            btnn2.setFont(plainFont1);
                            btnn3.setFont(plainFont1);
                            btnn4.setFont(plainFont1);
                            btnn5.setFont(plainFont1);
                            btnn6.setFont(plainFont1);

                            btnn8.setFont(plainFont1);

                            btnn1.setBackground(Color.GREEN);
                            btnn15.setBackground(Color.WHITE);

                            btnn1.setBorder(border3);
                            btnn1.setFont(plainFont2);

                            nframe.add(btnn1);
                            nframe.add(btnn2);
                            nframe.add(btnn3);
                            nframe.add(btnn4);
                            nframe.add(btnn5);
                            nframe.add(btnn6);

                            nframe.add(btnn8);
                            nframe.add(btnn1);

                            nframe.add(btnn15);

                            btnn2.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee18) {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM nursedata ";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);

                                        // fetchStatement.setString(3, username);
                                        // fetchStatement.setString(4, password);

                                        ResultSet resultSet = fetchStatement.executeQuery();

                                        if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame pvframe = new JFrame("View Profile");

                                            JLabel lblnss1 = new JLabel("Email-ID :  ");
                                            JLabel lblnss2 = new JLabel("Username : ");
                                            JLabel lblnss3 = new JLabel("Name : ");
                                            JLabel lblnss4 = new JLabel("Password: ");
                                            JLabel lblnss5 = new JLabel("Phone N0 : ");
                                            JLabel lblnss6 = new JLabel("Address : ");
                                            JLabel lblnss7 = new JLabel("DOB : ");
                                            JLabel lblnss8 = new JLabel("Doctor Degree : ");
                                            JLabel lblnss9 = new JLabel("Specializations : ");
                                            JLabel lblnss10 = new JLabel("Fees : ");
                                            JLabel lblnss11 = new JLabel("Joined Date : ");
                                            // JLabel lbldu12 = new JLabel("Id No : ");
                                            JTextField txtnss1 = new JTextField(email);
                                            JPasswordField txtnss4 = new JPasswordField(dpassword);
                                            JTextField txtnss3 = new JTextField(dname);
                                            JTextField txtnss2 = new JTextField(user_name);
                                            JTextField txtnss5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtnss6 = new JComboBox<>(adressarray);

                                            // JTextField txtd7 = new JTextField();
                                            JDateChooser txtnss7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtnss8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtnss9 = new JComboBox<>(dspecialzationarray);

                                            JTextField txtnss10 = new JTextField(dfees);
                                            JDateChooser txtnss11 = new JDateChooser(djoin_date);
                                            txtnss1.setEditable(false);
                                            txtnss2.setEditable(false);
                                            txtnss3.setEditable(false);
                                            txtnss4.setEditable(false);
                                            txtnss5.setEditable(false);
                                            txtnss6.setEditable(false);
                                            // txtdss7.setEnable(false);
                                            txtnss8.setEditable(false);
                                            txtnss9.setEditable(false);
                                            txtnss10.setEditable(false);
                                            // txtdss11.setEnable(false);
                                            // txtdss12.setEditable(false);
                                            // txtdss1.setEditable(false);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btnds1 = new JButton("BACK");

                                            lblnss1.setBounds(20, 10, 200, 35);
                                            lblnss2.setBounds(440, 10, 200, 35);
                                            lblnss3.setBounds(20, 60, 200, 35);
                                            lblnss4.setBounds(440, 60, 200, 35);
                                            lblnss5.setBounds(20, 110, 200, 35);
                                            lblnss6.setBounds(440, 110, 200, 35);
                                            lblnss7.setBounds(20, 160, 200, 35);
                                            lblnss8.setBounds(440, 160, 200, 35);
                                            lblnss9.setBounds(20, 210, 200, 35);
                                            lblnss10.setBounds(440, 210, 200, 35);
                                            lblnss11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtnss1.setBounds(200, 10, 200, 35);
                                            txtnss2.setBounds(680, 10, 200, 35);
                                            txtnss3.setBounds(200, 60, 200, 35);
                                            txtnss4.setBounds(680, 60, 200, 35);
                                            txtnss5.setBounds(200, 110, 200, 35);
                                            txtnss6.setBounds(680, 110, 200, 35);
                                            txtnss7.setBounds(200, 160, 200, 35);
                                            txtnss8.setBounds(680, 160, 200, 35);
                                            txtnss9.setBounds(200, 210, 200, 35);
                                            txtnss10.setBounds(680, 210, 200, 35);
                                            txtnss11.setBounds(200, 260, 200, 35);
                                            // txtdu12.setBounds(680, 260, 120, 35);
                                            btnds1.setBounds(300, 350, 150, 50);
                                            txtnss11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lblnss1.setFont(plainFont2);
                                            lblnss2.setFont(plainFont2);
                                            lblnss3.setFont(plainFont2);
                                            lblnss4.setFont(plainFont2);
                                            lblnss5.setFont(plainFont2);
                                            lblnss6.setFont(plainFont2);
                                            lblnss7.setFont(plainFont2);
                                            lblnss8.setFont(plainFont2);
                                            lblnss9.setFont(plainFont2);
                                            lblnss10.setFont(plainFont2);
                                            lblnss11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btnds1.setFont(plainFont2);

                                            pvframe.add(lblnss1);
                                            pvframe.add(lblnss2);
                                            pvframe.add(lblnss3);
                                            pvframe.add(lblnss4);
                                            pvframe.add(lblnss5);
                                            pvframe.add(lblnss6);
                                            pvframe.add(lblnss7);
                                            pvframe.add(lblnss8);
                                            pvframe.add(lblnss9);
                                            pvframe.add(lblnss10);
                                            pvframe.add(lblnss11);
                                            // frame6.add(lbldu12);
                                            pvframe.add(txtnss1);
                                            pvframe.add(txtnss2);
                                            pvframe.add(txtnss3);
                                            pvframe.add(txtnss4);
                                            pvframe.add(txtnss5);
                                            pvframe.add(txtnss6);
                                            pvframe.add(txtnss7);
                                            pvframe.add(txtnss8);
                                            pvframe.add(txtnss9);
                                            pvframe.add(txtnss10);
                                            pvframe.add(txtnss11);
                                            // frame6.add(txtsdu12);

                                            pvframe.add(btnds1);
                                            btnds1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee16) {
                                                    pvframe.dispose();
                                                }
                                            });

                                            pvframe.getContentPane().setBackground(Color.CYAN);

                                            pvframe.setBounds(355, 300, 1200, 500);
                                            pvframe.setLayout(null);
                                            pvframe.setVisible(true);

                                        } else {
                                            // // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            });
                            btnn3.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee19) {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM nursedata";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        // fetchStatement.setString(1, email_id);
                                        // fetchStatement.setString(2, name);
                                        // fetchStatement.setString(3, username);
                                        // fetchStatement.setString(4, password);

                                        ResultSet resultSet = fetchStatement.executeQuery();

                                        if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame unframe = new JFrame("Update Nurse details");

                                            JLabel lblnun1 = new JLabel("Email-ID :  ");
                                            JLabel lblnun2 = new JLabel("Username : ");
                                            JLabel lblnun3 = new JLabel("Name : ");
                                            JLabel lblnun4 = new JLabel("Password: ");
                                            JLabel lblnun5 = new JLabel("Phone N0 : ");
                                            JLabel lblnun6 = new JLabel("Address : ");
                                            JLabel lblnun7 = new JLabel("DOB : ");
                                            JLabel lblnun8 = new JLabel("Doctor Degree : ");
                                            JLabel lblnun9 = new JLabel("Specializations : ");
                                            JLabel lblnun10 = new JLabel("Fees : ");
                                            JLabel lblnun11 = new JLabel("Joined Date : ");
                                            // JLabel lbldu12 = new JLabel("Id No : ");
                                            JTextField txtnun1 = new JTextField(email);
                                            JPasswordField txtnun4 = new JPasswordField(dpassword);
                                            JTextField txtnun3 = new JTextField(dname);
                                            JTextField txtnun2 = new JTextField(user_name);
                                            JTextField txtnun5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtnun6 = new JComboBox<>(adressarray);

                                            // JTextField txtd7 = new JTextField();
                                            JDateChooser txtnun7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtnun8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtnun9 = new JComboBox<>(dspecialzationarray);

                                            JTextField txtnun10 = new JTextField(dfees);
                                            JDateChooser txtnun11 = new JDateChooser(djoin_date);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btnnun1 = new JButton("Submit");

                                            lblnun1.setBounds(20, 10, 200, 35);
                                            lblnun2.setBounds(440, 10, 200, 35);
                                            lblnun3.setBounds(20, 60, 200, 35);
                                            lblnun4.setBounds(440, 60, 200, 35);
                                            lblnun5.setBounds(20, 110, 200, 35);
                                            lblnun6.setBounds(440, 110, 200, 35);
                                            lblnun7.setBounds(20, 160, 200, 35);
                                            lblnun8.setBounds(440, 160, 200, 35);
                                            lblnun9.setBounds(20, 210, 200, 35);
                                            lblnun10.setBounds(440, 210, 200, 35);
                                            lblnun11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtnun1.setBounds(200, 10, 200, 35);
                                            txtnun2.setBounds(680, 10, 200, 35);
                                            txtnun3.setBounds(200, 60, 200, 35);
                                            txtnun4.setBounds(680, 60, 200, 35);
                                            txtnun5.setBounds(200, 110, 200, 35);
                                            txtnun6.setBounds(680, 110, 200, 35);
                                            txtnun7.setBounds(200, 160, 200, 35);
                                            txtnun8.setBounds(680, 160, 200, 35);
                                            txtnun9.setBounds(200, 210, 200, 35);
                                            txtnun10.setBounds(680, 210, 200, 35);
                                            txtnun11.setBounds(200, 260, 200, 35);
                                            // txtdu12.setBounds(680, 260, 120, 35);
                                            btnnun1.setBounds(300, 350, 150, 50);
                                            txtnun11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lblnun1.setFont(plainFont2);
                                            lblnun2.setFont(plainFont2);
                                            lblnun3.setFont(plainFont2);
                                            lblnun4.setFont(plainFont2);
                                            lblnun5.setFont(plainFont2);
                                            lblnun6.setFont(plainFont2);
                                            lblnun7.setFont(plainFont2);
                                            lblnun8.setFont(plainFont2);
                                            lblnun9.setFont(plainFont2);
                                            lblnun10.setFont(plainFont2);
                                            lblnun11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btnnun1.setFont(plainFont2);

                                            unframe.add(lblnun1);
                                            unframe.add(lblnun2);
                                            unframe.add(lblnun3);
                                            unframe.add(lblnun4);
                                            unframe.add(lblnun5);
                                            unframe.add(lblnun6);
                                            unframe.add(lblnun7);
                                            unframe.add(lblnun8);
                                            unframe.add(lblnun9);
                                            unframe.add(lblnun10);
                                            unframe.add(lblnun11);
                                            // frame6.add(nbldu12);
                                            unframe.add(txtnun1);
                                            unframe.add(txtnun2);
                                            unframe.add(txtnun3);
                                            unframe.add(txtnun4);
                                            unframe.add(txtnun5);
                                            unframe.add(txtnun6);
                                            unframe.add(txtnun7);
                                            unframe.add(txtnun8);
                                            unframe.add(txtnun9);
                                            unframe.add(txtnun10);
                                            unframe.add(txtnun11);
                                            // frame6.add(txtdu12);

                                            unframe.add(btnnun1);
                                            btnnun1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee13) {
                                                    Date newdob = txtnun11.getDate();
                                                    String newDobDate = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob);
                                                    Date newdob1 = txtnun7.getDate();
                                                    String newDob1Date = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob1);

                                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                                    String formattedDob = dateFormat.format(newdob);
                                                    String formattedDob1 = dateFormat.format(newdob1);

                                                    String newemail_id = txtnun1.getText();
                                                    String newusername = txtnun2.getText();
                                                    String msg = "" + username;
                                                    String newname = txtnun3.getText();
                                                    String newphoneno = txtnun5.getText();
                                                    String newpassword = new String(txtnun4.getPassword());
                                                    String newaddress = (String) txtnun6.getSelectedItem();
                                                    String newdegree = (String) txtnun8.getSelectedItem();
                                                    String newspecializations = (String) txtnun9.getSelectedItem();
                                                    String newfees = txtnun10.getText();
                                                    // String Idno = txtdu12.getText();

                                                    String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                                    int len = newemail_id.length();
                                                    int len1 = newname.length();
                                                    int len2 = newpassword.length();
                                                    int len3 = newfees.length();
                                                    int len4 = newusername.length();
                                                    int len5 = newphoneno.length();
                                                    // int len6 = Idno.length();
                                                    if (newdob == null) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please Choose Your joined date",
                                                                "Empty fileds", JOptionPane.ERROR_MESSAGE);
                                                    } else if (newdob1 == null) {
                                                        JOptionPane.showMessageDialog(null, "Please choose your Dob.",
                                                                "Empty Fields",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    }

                                                    else if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0
                                                            || len4 == 0) {
                                                        JOptionPane.showMessageDialog(null, "Every Filed is required",
                                                                "Empty fileds",
                                                                JOptionPane.ERROR_MESSAGE);

                                                    } else if (!Pattern.matches(emailPattern, newemail_id)) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Invalid email address. Please enter a valid email.",
                                                                "Validation Result",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    } else if (len5 != 10) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please enter the valid mobile no",
                                                                "less than 10", JOptionPane.ERROR_MESSAGE);

                                                    } else {
                                                        try {
                                                            Connection connection = DriverManager.getConnection(
                                                                    "jdbc:mysql://localhost:3306/CMS", "root",
                                                                    "Ankit@817raj#");

                                                            String updateQuery = "UPDATE nursedata SET email = ?, username = ?, name = ?, password = ?, phoneno = ?, address = ?, dob = ?, degree = ?, specilizations = ?, fees = ?, jdate = ? WHERE username = ?";

                                                            PreparedStatement updateStatement = connection
                                                                    .prepareStatement(updateQuery);
                                                            // updateStatement.setString(1, username);
                                                            updateStatement.setString(1, newemail_id);
                                                            updateStatement.setString(2, newusername);
                                                            updateStatement.setString(3, newname);
                                                            updateStatement.setString(4, newpassword);
                                                            updateStatement.setString(5, newphoneno);
                                                            updateStatement.setString(6, newaddress);
                                                            updateStatement.setString(7, newDobDate);
                                                            updateStatement.setString(8, newdegree);
                                                            updateStatement.setString(9, newspecializations);
                                                            updateStatement.setString(10, newfees);
                                                            updateStatement.setString(11, newDob1Date);
                                                            // updateStatement.setString(12, newIdNo);
                                                            updateStatement.setString(12, username);

                                                            int rowsAffected = updateStatement.executeUpdate();

                                                            if (rowsAffected > 0) {
                                                                JOptionPane.showMessageDialog(null,
                                                                        "Update successfully",
                                                                        "Update data", JOptionPane.ERROR_MESSAGE);
                                                                unframe.dispose();
                                                            } else {

                                                            }

                                                        } catch (Exception ee3) {
                                                            ee3.printStackTrace();
                                                        }

                                                    }

                                                }
                                            });

                                            unframe.getContentPane().setBackground(Color.CYAN);

                                            unframe.setBounds(225, 265, 1330, 600);
                                            unframe.setLayout(null);
                                            unframe.setVisible(true);

                                        } else {
                                            // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }
                            });
                            btnn4.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee35) {
                                    JFrame pdframe = new JFrame("Patient Data");
                                    JTable table = new JTable();
                                    DefaultTableModel model = new DefaultTableModel() {
                                        @Override
                                        public boolean isCellEditable(int row, int column) {
                                            return false;
                                        }
                                    };

                                    model.addColumn("ID");
                                    model.addColumn("Name");
                                    model.addColumn("Father/Mother Name");
                                    model.addColumn("Age");
                                    model.addColumn("Date");
                                    model.addColumn("Gender");
                                    model.addColumn("Occupation");
                                    model.addColumn("Marital Status");
                                    model.addColumn("Contact No");
                                    model.addColumn("Address");

                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                "Ankit@817raj#");
                                        Statement statement = connection.createStatement();

                                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                        String todayDate = dateFormat.format(new Date());

                                        ResultSet resultSet = statement.executeQuery(
                                                "SELECT * FROM patient_info WHERE DATE_FORMAT(dob, '%Y-%m-%d') = '"
                                                        + todayDate + "'");

                                        while (resultSet.next()) {
                                            model.addRow(new Object[] {
                                                    resultSet.getInt("id"),
                                                    resultSet.getString("name"),
                                                    resultSet.getString("fname"),
                                                    resultSet.getString("age"),
                                                    resultSet.getString("dob"),
                                                    resultSet.getString("gender"),
                                                    resultSet.getString("occupation"),
                                                    resultSet.getString("marital_status"),
                                                    resultSet.getString("contact_no"),
                                                    resultSet.getString("address"),
                                            });
                                        }
                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                    table.setModel(model);

                                    JTableHeader header = table.getTableHeader();
                                    header.setFont(new Font("Jumble", Font.BOLD, 18));
                                    header.setForeground(Color.RED);

                                    TableCellRenderer renderer = table.getDefaultRenderer(Object.class);
                                    table.setDefaultRenderer(Object.class,
                                            (JTable table1, Object value, boolean isSelected, boolean hasFocus, int row,
                                                    int column) -> {
                                                Component component = renderer.getTableCellRendererComponent(table1,
                                                        value, isSelected,
                                                        hasFocus, row, column);
                                                component.setFont(new Font("Jumble", Font.BOLD, 14));
                                                component.setForeground(Color.BLUE);
                                                return component;
                                            });

                                    // Add ListSelectionListener to the table
                                    table.getSelectionModel().addListSelectionListener(e -> {
                                        if (!e.getValueIsAdjusting()) {
                                            int selectedRow = table.getSelectedRow();
                                            if (selectedRow >= 0) {
                                                try {
                                                    // Get data of the selected row
                                                    int id = (int) model.getValueAt(selectedRow, 0);
                                                    String name = (String) model.getValueAt(selectedRow, 1);
                                                    String fname = (String) model.getValueAt(selectedRow, 2);
                                                    String age = (String) model.getValueAt(selectedRow, 3);
                                                    String dob = (String) model.getValueAt(selectedRow, 4);
                                                    String gender = (String) model.getValueAt(selectedRow, 5);
                                                    String occupation = (String) model.getValueAt(selectedRow, 6);
                                                    String maritalStatus = (String) model.getValueAt(selectedRow, 7);
                                                    String contactNo = (String) model.getValueAt(selectedRow, 8);
                                                    String address = (String) model.getValueAt(selectedRow, 9);

                                                    // Close the current frame
                                                    pdframe.dispose();

                                                    // Create a new JFrame when a row is selected
                                                    JFrame detailFrame = new JFrame("Details");
                                                    // detailFrame.setBounds(220, 260, 1320, 600);
                                                    // detailFrame.getContentPane().setBackground(Color.decode("#f8faf9"));
                                                    // detailFrame.setLayout(null);
                                                    // detailFrame.setVisible(true);

                                                    try {
                                                        Connection connection = DriverManager.getConnection(
                                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                                "Ankit@817raj#");

                                                        String fetchQuery = "SELECT name  FROM nursedata where username=?";

                                                        PreparedStatement fetchStatement = connection
                                                                .prepareStatement(fetchQuery);
                                                        fetchStatement.setString(1, username);
                                                        // ResultSet resultSet = fetchStatement.executeQuery();
                                                        ResultSet resultSet = fetchStatement.executeQuery();
                                                        if (resultSet.next()) {
                                                            String dname = resultSet.getString("name");
                                                            JLabel dnlbl1 = new JLabel("Nurse Name: ");
                                                            JTextField dntxt1 = new JTextField(dname);
                                                            dnlbl1.setBounds(600, 70, 250, 30);
                                                            dntxt1.setBounds(900, 70, 250, 30);
                                                            detailFrame.add(dnlbl1);
                                                            detailFrame.add(dntxt1);
                                                            dntxt1.setEditable(false);
                                                            Font f3 = new Font("Jumble", Font.BOLD, 25);
                                                            dntxt1.setFont(f3);
                                                            dnlbl1.setFont(f3);
                                                            // txtdl1.setForeground(Color.BLUE);
                                                            dnlbl1.setForeground(Color.BLUE);

                                                        }

                                                    } catch (Exception ee28) {
                                                        ee28.printStackTrace();
                                                    }

                                                    // Add labels to display data
                                                    JLabel lblId = new JLabel("ID: " + id);
                                                    JLabel lblName = new JLabel("Name: " + name);
                                                    JLabel lblFname = new JLabel("Father/Mother Name: " + fname);
                                                    JLabel lblAge = new JLabel("Age: " + age);
                                                    JLabel lblDob = new JLabel("Date: " + dob);
                                                    JLabel lblGender = new JLabel("Gender: " + gender);
                                                    JLabel lblOccupation = new JLabel("Occupation: " + occupation);
                                                    JLabel lblMaritalStatus = new JLabel(
                                                            "Marital Status: " + maritalStatus);
                                                    JLabel lblContactNo = new JLabel("Contact No: " + contactNo);
                                                    JLabel lblAddress = new JLabel("Address: " + address);
                                                    JTextField dntxt1;

                                                    // Set bounds for labels
                                                    lblId.setBounds(20, 20, 300, 30);
                                                    lblName.setBounds(20, 70, 300, 30);
                                                    lblFname.setBounds(20, 120, 300, 30);
                                                    lblAge.setBounds(20, 170, 300, 30);
                                                    lblDob.setBounds(20, 220, 300, 30);
                                                    lblGender.setBounds(20, 270, 300, 30);
                                                    lblOccupation.setBounds(20, 320, 300, 30);
                                                    lblMaritalStatus.setBounds(20, 370, 300, 30);
                                                    lblContactNo.setBounds(20, 420, 300, 30);
                                                    lblAddress.setBounds(20, 470, 300, 30);
                                                    Font f2 = new Font("Jumble", Font.BOLD, 20);
                                                    lblId.setFont(f2);
                                                    lblName.setFont(f2);
                                                    lblFname.setFont(f2);
                                                    lblAge.setFont(f2);
                                                    lblDob.setFont(f2);
                                                    lblGender.setFont(f2);
                                                    lblOccupation.setFont(f2);
                                                    lblMaritalStatus.setFont(f2);
                                                    lblContactNo.setFont(f2);
                                                    lblAddress.setFont(f2);

                                                    JLabel pplbl1 = new JLabel("Choose Your Issue : ");
                                                    JLabel pplbl2 = new JLabel("Any Other Isssue: ");
                                                    JLabel pplbl3 = new JLabel("Tablate Name: ");
                                                    JLabel pplbl4 = new JLabel("Reg. No: ");
                                                    JButton ppbtn = new JButton("SUBMIT");
                                                    String item[] = { "Fever", "Mental Health", "HIV", "AIDS",
                                                            "Diabetes", "Cold" };
                                                    JComboBox<String> pptxt1 = new JComboBox<>(item);
                                                    JTextField pptxt2 = new JTextField();
                                                    JTextField pptxt3 = new JTextField(50);
                                                    JTextField pptxt4 = new JTextField(5);
                                                    pplbl1.setBounds(600, 120, 350, 30);
                                                    pplbl2.setBounds(600, 170, 350, 30);
                                                    pplbl3.setBounds(600, 220, 350, 30);
                                                    pplbl4.setBounds(600, 270, 350, 30);
                                                    pptxt1.setBounds(1010, 120, 180, 30);
                                                    pptxt2.setBounds(1010, 170, 180, 30);
                                                    pptxt3.setBounds(1010, 220, 180, 30);
                                                    pptxt4.setBounds(1010, 270, 180, 30);
                                                    ppbtn.setBounds(800, 350, 180, 30);
                                                    pptxt1.setFont(f2);
                                                    pptxt2.setFont(f2);
                                                    pptxt3.setFont(f2);
                                                    pplbl1.setFont(f2);
                                                    pplbl2.setFont(f2);
                                                    pplbl3.setFont(f2);
                                                    pptxt4.setFont(f2);
                                                    pplbl4.setFont(f2);
                                                    ppbtn.setFont(f2);

                                                    // Add labels to the detailFrame
                                                    detailFrame.add(lblId);
                                                    detailFrame.add(lblName);
                                                    detailFrame.add(lblFname);
                                                    detailFrame.add(lblAge);
                                                    detailFrame.add(lblDob);
                                                    detailFrame.add(lblGender);
                                                    detailFrame.add(lblOccupation);
                                                    detailFrame.add(lblMaritalStatus);
                                                    detailFrame.add(lblContactNo);
                                                    detailFrame.add(lblAddress);
                                                    detailFrame.add(pplbl1);
                                                    detailFrame.add(pplbl3);
                                                    detailFrame.add(pptxt1);
                                                    detailFrame.add(pptxt3);
                                                    detailFrame.add(pplbl2);
                                                    detailFrame.add(pptxt2);
                                                    detailFrame.add(pplbl4);
                                                    detailFrame.add(pptxt4);
                                                    detailFrame.add(ppbtn);
                                                    ppbtn.addActionListener(new ActionListener() {
                                                        public void actionPerformed(ActionEvent ee28) {

                                                            // Define variables to store the data
                                                            // String patient_id=lblId.getText();
                                                            // int patient_id = 1;
                                                            String patientName = lblName.getText().replace("Name: ",
                                                                    "");
                                                            String fmName = lblFname.getText()
                                                                    .replace("Father/Mother Name: ", "");
                                                            String age = lblAge.getText().replace("Age: ", "");
                                                            String date = lblDob.getText().replace("Date: ", "");
                                                            String gender = lblGender.getText().replace("Gender: ", "");
                                                            String occupation = lblOccupation.getText()
                                                                    .replace("Occupation: ", "");
                                                            String maritalStatus = lblMaritalStatus.getText()
                                                                    .replace("Marital Status: ", "");
                                                            String contactNo = lblContactNo.getText()
                                                                    .replace("Contact No: ", "");
                                                            String address = lblAddress.getText().replace("Address: ",
                                                                    "");
                                                            // String doctorName = dntxt1.getText(); // Retrieve from
                                                            // JTextField dntxt1
                                                            String issue = pptxt1.getSelectedItem().toString(); // Retrieve
                                                                                                                // from
                                                                                                                // JComboBox
                                                                                                                // pptxt1
                                                            String otherIssue = pptxt2.getText(); 
                                                                                                  // JTextField pptxt2
                                                            String tabletName = pptxt3.getText(); // Retrieve from
                                                                                                  // JTextField pptxt3
                                                            String regNo = pptxt4.getText(); // Retrieve from JTextField
                                                                                             // pptxt4

                                                            try {
                                                                Connection connection = DriverManager.getConnection(
                                                                        "jdbc:mysql://localhost:3306/CMS", "root",
                                                                        "Ankit@817raj#");

                                                                // Define the SQL query to create a table
                                                                DatabaseMetaData metaData = connection.getMetaData();
                                                                ResultSet tables = metaData.getTables(null, null,
                                                                        "patient_detail", null);
                                                                boolean tableExists = tables.next();
                                                                if (!tableExists) {
                                                                    // Statement statement =
                                                                 
                                                                    String createTableQuery = "CREATE TABLE patient_detail ("
                                                                            + "patient_id INT PRIMARY KEY auto_increment,"
                                                                            + "patient_name VARCHAR(255),"
                                                                            + "f_m_name VARCHAR(255),"
                                                                            + "age INT(10),"
                                                                            + "date DATE,"
                                                                            + "gender VARCHAR(10),"
                                                                            + "occupation VARCHAR(255),"
                                                                            + "marital_status VARCHAR(20),"
                                                                            + "contact_no VARCHAR(15),"
                                                                            + "address VARCHAR(255),"

                                                                            + "issue VARCHAR(255),"
                                                                            + "other_issue VARCHAR(255),"
                                                                            + "tablet_name VARCHAR(255),"
                                                                            + "reg_no VARCHAR(10) UNIQUE)";

                                                                    Statement statement = connection.createStatement();

                                                                    // Execute the query to create the table
                                                                    statement.executeUpdate(createTableQuery);

                                                                    // Close the statement
                                                                    statement.close();
                                                                }

                                                                // Now, let's insert data into the table
                                                                String insertDataQuery = "INSERT INTO patient_detail (patient_name, f_m_name, age, date, gender, "
                                                                        + "occupation, marital_status, contact_no, address, issue, other_issue, tablet_name, reg_no) "
                                                                        + "VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                                                                PreparedStatement insertStatement = connection
                                                                        .prepareStatement(insertDataQuery);

                                                                // Set the values based on the data from your
                                                                // detailFrame
                                                                // insertStatement.setInt(1, patient_id);
                                                                insertStatement.setString(1, patientName);
                                                                insertStatement.setString(2, fmName);
                                                                insertStatement.setInt(3, Integer.parseInt(age)); // Convert
                                                                                                                  // age
                                                                                                                  // to
                                                                                                                  // int
                                                                insertStatement.setString(4, date);
                                                                insertStatement.setString(5, gender);
                                                                insertStatement.setString(6, occupation);
                                                                insertStatement.setString(7, maritalStatus);
                                                                insertStatement.setString(8, contactNo);
                                                                insertStatement.setString(9, address);
                                                                // insertStatement.setString(11, doctorName);
                                                                insertStatement.setString(10, issue);
                                                                insertStatement.setString(11, otherIssue);
                                                                insertStatement.setString(12, tabletName);
                                                                insertStatement.setString(13, regNo);

                                                                // Execute the insert statement
                                                                insertStatement.executeUpdate();

                                                                // Close the insert statement and connection
                                                                insertStatement.close();
                                                                connection.close();

                                                                // Inform the user that data has been inserted
                                                                JOptionPane.showMessageDialog(null,
                                                                        "Data inserted successfully!");
                                                                detailFrame.dispose();

                                                            } catch (Exception e) {
                                                                e.printStackTrace();
                                                            }
                                                        }
                                                    });

                                                    detailFrame.setBounds(220, 260, 1320, 600);
                                                    detailFrame.getContentPane().setBackground(Color.decode("#f8faf9"));
                                                    detailFrame.setLayout(null);
                                                    detailFrame.setVisible(true);

                                                } catch (Exception ex) {
                                                    ex.printStackTrace();
                                                }
                                            }
                                        }
                                    });

                                    JScrollPane scrollPane = new JScrollPane(table);
                                    pdframe.add(scrollPane);
                                    pdframe.getContentPane().setBackground(Color.decode("#29bf86"));
                                    pdframe.setBounds(220, 260, 1320, 600);
                                    pdframe.setVisible(true);
                                }

                            });
                            btnn6.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee26) {
                                    // Create a new JFrame for displaying patient details
                                    JFrame detailFrame = new JFrame("Patient Details");
                                    detailFrame.setBounds(100, 220, 1320, 790);
                                    detailFrame.getContentPane().setBackground(Color.decode("#b9c2c2"));
                                    detailFrame.setLayout(null);

                                    // Create input components
                                    JLabel lblId = new JLabel("Enter Your IdNo.:");
                                    JTextField txtId = new JTextField();
                                    JButton btnFetch = new JButton("OK");

                                    lblId.setBounds(250, 5, 250, 30);
                                    txtId.setBounds(550, 5, 160, 30);
                                    lblId.setForeground(Color.WHITE);
                                    txtId.setForeground(Color.BLUE);
                                    btnFetch.setForeground(Color.RED);

                                    btnFetch.setBounds(800, 5, 100, 30);
                                    // btnframe.getContentPane().setBackground(Color.decode("#29bf86"));

                                    // Define labels for displaying patient details
                                    JLabel notelbl1=new JLabel("Note 1: You must be meet after one week.");
                                    JLabel notelbl2=new JLabel("Note 2: All the best, get well soon..");
                                    
                                    JLabel lblPatientId = new JLabel("Patient ID:");
                                    JLabel lblPatientName = new JLabel("Patient Name:");
                                    JLabel lblFmName = new JLabel("Father/Mother Name:");
                                    JLabel lblAge = new JLabel("Age:");
                                    JLabel lbldate = new JLabel("Date:");
                                    JLabel lblgender = new JLabel("Gender:");
                                    JLabel Occupation = new JLabel("Occupation");
                                    JLabel Status = new JLabel("Satus:");
                                    JLabel contactNo = new JLabel("Contact No");
                                    JLabel Address = new JLabel("Address:");
                                    JLabel Issue = new JLabel("Issue");
                                    JLabel OIssue = new JLabel("Other issue");
                                    JLabel Medicine = new JLabel("Medicine Name :");
                                    JLabel RegNo = new JLabel("Reg. No:");
                                    // String dname = resultSet.getString("name");
                                    JLabel dnlbl1 = new JLabel("Nurse Name: ");

                                    // Add more labels for other details...

                                    // Set bounds for the detail labels
                                    notelbl1.setBounds(20,400,1000,20);
                                    notelbl2.setBounds(20,450,1000,20);
                                    
                                    RegNo.setBounds(20, 20, 120, 30);
                                    lblPatientId.setBounds(20, 70, 300, 30);
                                    lblPatientName.setBounds(20, 120, 300, 30);
                                    lblFmName.setBounds(20, 170, 300, 30);
                                    lblAge.setBounds(20, 220, 300, 30);
                                    lbldate.setBounds(20, 270, 300, 30);
                                    lbldate.setBounds(20, 320, 300, 30);
                                    lblgender.setBounds(550, 70, 300, 30);
                                    Occupation.setBounds(550, 120, 300, 30);
                                    Status.setBounds(550, 170, 300, 30);
                                    contactNo.setBounds(550, 220, 300, 30);
                                    Address.setBounds(550, 270, 300, 30);
                                    Issue.setBounds(550, 320, 300, 30);
                                    OIssue.setBounds(20, 370, 300, 20);
                                    Medicine.setBounds(550, 370, 300, 30);
                                    dnlbl1.setBounds(800, 70, 250, 30);
                                    // RegNo.setBounds(20,);

                                    // Set bounds for other detail labels...

                                    // Add detail labels to the detailFrame
                                    detailFrame.add(lblPatientId);
                                    detailFrame.add(lblPatientName);
                                    detailFrame.add(lblFmName);
                                    detailFrame.add(lblAge);
                                    detailFrame.add(lbldate);
                                    detailFrame.add(lblgender);
                                    detailFrame.add(Occupation);
                                    detailFrame.add(Status);
                                    detailFrame.add(contactNo);
                                    detailFrame.add(Address);
                                    detailFrame.add(Issue);
                                    detailFrame.add(OIssue);
                                    detailFrame.add(Medicine);
                                    detailFrame.add(RegNo);
                                    // detailFrame.add(lbldate);
                                    // detailFrame.add(lbldate);

                                    // Add other detail labels...
                                    Font jumbleFont = new Font("Jumble", Font.BOLD, 18);

                                    lblPatientId.setFont(jumbleFont);
                                    lblPatientName.setFont(jumbleFont);
                                    lblFmName.setFont(jumbleFont);
                                    lblAge.setFont(jumbleFont);
                                    lbldate.setFont(jumbleFont);
                                    lblgender.setFont(jumbleFont);
                                    Occupation.setFont(jumbleFont);
                                    Status.setFont(jumbleFont);
                                    contactNo.setFont(jumbleFont);
                                    Address.setFont(jumbleFont);
                                    Issue.setFont(jumbleFont);
                                    OIssue.setFont(jumbleFont);
                                    Medicine.setFont(jumbleFont);
                                    RegNo.setFont(jumbleFont);
                                    lblId.setFont(jumbleFont);
                                    txtId.setFont(jumbleFont);
                                    btnFetch.setFont(jumbleFont);

                                    // Set visibility of detail labels to false initially
                                    lblPatientId.setVisible(false);
                                    lblPatientName.setVisible(false);
                                    lblFmName.setVisible(false);
                                    lblAge.setVisible(false);
                                    lblgender.setVisible(false);
                                    Occupation.setVisible(false);
                                    Issue.setVisible(false);
                                    OIssue.setVisible(false);
                                    Status.setVisible(false);
                                    contactNo.setVisible(false);
                                    Address.setVisible(false);
                                    Medicine.setVisible(false);
                                    lbldate.setVisible(false);
                                    RegNo.setVisible(false);
                                    dnlbl1.setVisible(false);
                                    notelbl1.setVisible(false);
                                    notelbl2.setVisible(false);

                                    // Set visibility for other detail labels...

                                    // Add components to the detailFrame
                                    detailFrame.add(lblId);
                                    detailFrame.add(txtId);
                                    detailFrame.add(btnFetch);
                                    // detailFrame.add(dnlbl1);
                                        try {
                                                        Connection connection = DriverManager.getConnection(
                                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                                "Ankit@817raj#");

                                                        String fetchQuery = "SELECT name  FROM nursedata where username=?";

                                                        PreparedStatement fetchStatement = connection
                                                                .prepareStatement(fetchQuery);
                                                        fetchStatement.setString(1, username);
                                                        // ResultSet resultSet = fetchStatement.executeQuery();
                                                        ResultSet resultSet = fetchStatement.executeQuery();
                                                        if (resultSet.next()) {
                                                            String dname = resultSet.getString("name");
                                                            // JLabel dnlbl1 = new JLabel("Doctor Name: ");
                                                            JTextField dntxt1 = new JTextField(dname);
                                                            
                                                            dntxt1.setBounds(1100, 70, 200, 30);
                                                            detailFrame.add(dnlbl1);
                                                            detailFrame.add(dntxt1);
                                                            dntxt1.setEditable(false);
                                                            Font f3 = new Font("Jumble", Font.BOLD, 25);
                                                            dntxt1.setFont(f3);
                                                            dnlbl1.setFont(f3);
                                                            // txtdl1.setForeground(Color.BLUE);
                                                            dnlbl1.setForeground(Color.BLUE);
                                                            // detailFrame.add(txtdl1);
                                                            dnlbl1.setVisible(true);

                                                            

                                                        }

                                                    } catch (Exception ee28) {
                                                        ee28.printStackTrace();
                                                    }

                                    // Action listener for the Fetch Data button
                                    btnFetch.addActionListener(new ActionListener() {
                                        public void actionPerformed(ActionEvent ee28) {
                                            try {
                                                Connection connection = DriverManager.getConnection(
                                                        "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                                String pid = txtId.getText();
                                                String updateQuery = "SELECT * FROM patient_detail WHERE reg_no = ?";
                                                PreparedStatement updateStatement = connection
                                                        .prepareStatement(updateQuery);
                                                updateStatement.setString(1, pid);

                                                ResultSet resultSet = updateStatement.executeQuery();

                                                if (resultSet.next()) {
                                                    // Fetch patient details from the result set
                                                    int patient_id = resultSet.getInt("patient_id");
                                                    String patient_name = resultSet.getString("patient_name");
                                                    String fm_name = resultSet.getString("f_m_name");
                                                    int age = resultSet.getInt("age");
                                                    Date date = resultSet.getDate("date");
                                                    String Gender = resultSet.getString("gender");
                                                    String occupation = resultSet.getString("occupation");
                                                    String Staus = resultSet.getString("marital_status");
                                                    String ContactNo = resultSet.getString("contact_no");
                                                    String address = resultSet.getString("address");
                                                    String issue = resultSet.getString("issue");
                                                    String Other = resultSet.getString("other_issue");
                                                    String medicine = resultSet.getString("tablet_name");
                                                    String reg_no = resultSet.getString("reg_no");

                                                    // Set the text of detail labels with the fetched data
                                                    lblPatientId.setText("Patient ID : " + patient_id);
                                                    lblPatientName.setText("Patient Name : " + patient_name);
                                                    lblFmName.setText("Father/Mother Name : " + fm_name);
                                                    lblAge.setText("Age : " + age);
                                                    lblgender.setText("Gender : " + Gender);
                                                    Occupation.setText("Occupation : " + occupation);
                                                    lbldate.setText("Date: " + date.toString());
                                                    Status.setText("Material Status :" + Staus);
                                                    contactNo.setText("Phone No : " + ContactNo);
                                                    Address.setText("Address : " + address);
                                                    Issue.setText("Issue: " + issue);
                                                    OIssue.setText("Other Issue : " + Other);
                                                    Medicine.setText("Mediiene : " + medicine);
                                                    RegNo.setText("Reg. No : " + reg_no);
                                                    

                                                    // Set the visibility of detail labels to true
                                                    lblId.setVisible(false);
                                                    btnFetch.setVisible(false);
                                                    txtId.setVisible(false);

                                                    lblPatientId.setVisible(true);
                                                    lblPatientName.setVisible(true);
                                                    lblFmName.setVisible(true);
                                                    lblAge.setVisible(true);
                                                    lblgender.setVisible(true);
                                                    Occupation.setVisible(true);
                                                    lbldate.setVisible(true);
                                                    Status.setVisible(true);
                                                    RegNo.setVisible(true);
                                                    contactNo.setVisible(true);
                                                    Address.setVisible(true);
                                                    Issue.setVisible(true);
                                                    OIssue.setVisible(true);
                                                    Medicine.setVisible(true);
                                                    RegNo.setVisible(true);
                                                    notelbl1.setVisible(true);
                                                    notelbl2.setVisible(true);
                                                    // Issue.setVisible(false);

                                                } else {
                                                    JOptionPane.showMessageDialog(null,
                                                            "No record found for the provided ID.");
                                                }

                                                updateStatement.close();
                                                connection.close();

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    });

                                    // Make the detailFrame visible
                                    detailFrame.setVisible(true);
                                }
                            });
                            btnn8.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee34){
                                    nframe.dispose();

                                }
                                
                            });
                             btnn5.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent ee34){
                                    nframe.dispose();
                                    Admin_page1();

                                }
                                
                            });



                            nframe.getContentPane().setBackground(Color.RED);
                            nframe.setBounds(0, 130, 1540, 900);
                            nframe.setLayout(null);
                            nframe.setVisible(true);
                            nlframe.dispose();

                        } else {
                            JOptionPane.showMessageDialog(btnnl1, "Invalid username or password");
                        }
                    } catch (Exception ee) {
                        ee.printStackTrace();
                    }
                }

            }

        });

        nlframe.getContentPane().setBackground(Color.decode("#fae607"));
        nlframe.setBounds(300, 250, 450, 300);
        nlframe.setLayout(null);
        nlframe.setVisible(true);

    }

    

    public void patient_page() {
        JFrame pframe = new JFrame("Patient Page");
        JButton btnp15 = new JButton("");
        JButton btnp1 = new JButton("MENU");
        JButton btnp2 = new JButton("DOCTOR");
        JButton btnp3 = new JButton("NURSE");
        JButton btnp4 = new JButton("APPOINTMENT");
        JButton btnp5 = new JButton("REPORTS");
        JButton btnp6 = new JButton("MEDICAL SHOP");
        JButton btnp7 = new JButton("BILL PAYMENT");
        JButton btnp8 = new JButton("EXIT");

        Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
        Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
        Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
        Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
        Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

        btnp1.setBounds(20, 20, 120, 40);

        btnp2.setBounds(200, 20, 110, 40);
        btnp3.setBounds(340, 20, 100, 40);
        btnp4.setBounds(480, 20, 200, 40);
        btnp5.setBounds(720, 20, 200, 40);
        btnp6.setBounds(960, 20, 220, 40);
        btnp7.setBounds(1220, 20, 160, 40);
        btnp8.setBounds(1400, 20, 100, 40);
        btnp15.setBounds(0, 80, 1540, 5);
        btnp1.setFont(plainFont1);
        btnp2.setFont(plainFont1);
        btnp3.setFont(plainFont1);
        btnp4.setFont(plainFont1);
        btnp5.setFont(plainFont1);
        btnp6.setFont(plainFont1);
        btnp7.setFont(plainFont1);
        btnp8.setFont(plainFont1);

        btnp1.setBackground(Color.GREEN);
        btnp15.setBackground(Color.WHITE);
        // btn16.setBackground(Color.WHITE);
        btnp1.setBorder(border3);
        btnp1.setFont(plainFont2);

        pframe.add(btnp1);
        pframe.add(btnp2);
        pframe.add(btnp3);
        pframe.add(btnp4);
        pframe.add(btnp5);
        pframe.add(btnp6);
        pframe.add(btnp7);
        pframe.add(btnp8);
        pframe.add(btnp1);

        pframe.add(btnp15);
        btnp5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee34){
                Report();

            }
        });
        btnp8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee33){
                JOptionPane.showConfirmDialog(null, "Do you want to Logout!!","Logout", JOptionPane.YES_NO_CANCEL_OPTION);
                pframe.dispose();

            }
        });

        btnp2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee21) {
                JFrame pdframe = new JFrame("Doctor Data");
                JTable table = new JTable();
                DefaultTableModel model = new DefaultTableModel() {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false;
                    }
                };

                // DefaultTableModel model = new DefaultTableModel();
                model.addColumn("ID");
                model.addColumn("Name");
                model.addColumn("Degree");
                model.addColumn("Fees");
                model.addColumn("Specialization");
                model.addColumn("Phone No");

                try {
                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                            "Ankit@817raj#");
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement
                            .executeQuery("SELECT id, name, degree, fees, specilizations, phoneno FROM doctordata");

                    while (resultSet.next()) {
                        model.addRow(new Object[] {
                                resultSet.getInt("id"),
                                resultSet.getString("name"),
                                resultSet.getString("degree"),
                                resultSet.getString("fees"),
                                resultSet.getString("specilizations"),
                                resultSet.getString("phoneno")
                        });
                    }
                    connection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                table.setModel(model);

                // Customize the heading font and color
                JTableHeader header = table.getTableHeader();
                header.setFont(new Font("Jumble", Font.BOLD, 18)); // Set font
                header.setForeground(Color.RED); // Set color

                // Customize the data font and color
                TableCellRenderer renderer = table.getDefaultRenderer(Object.class);
                table.setDefaultRenderer(Object.class,
                        (JTable table1, Object value, boolean isSelected, boolean hasFocus, int row, int column) -> {
                            Component component = renderer.getTableCellRendererComponent(table1, value, isSelected,
                                    hasFocus, row, column);
                            component.setFont(new Font("Jumble", Font.BOLD, 14));
                            component.setForeground(Color.BLUE); // Set data color
                            return component;
                        });

                JScrollPane scrollPane = new JScrollPane(table);
                pdframe.add(scrollPane);
                pdframe.getContentPane().setBackground(Color.decode("#29bf86"));
                pdframe.setBounds(220, 260, 1320, 600);
                pdframe.setVisible(true);

            }
        });
        btnp3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee21) {
                JFrame pdframe = new JFrame("Nurse Data");
                JTable table = new JTable();
                DefaultTableModel model = new DefaultTableModel() {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false;
                    }
                };

                // DefaultTableModel model = new DefaultTableModel();
                model.addColumn("ID");
                model.addColumn("Name");
                model.addColumn("Degree");
                model.addColumn("Fees");
                model.addColumn("Specialization");
                model.addColumn("Phone No");

                try {
                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                            "Ankit@817raj#");
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement
                            .executeQuery("SELECT id, name, degree, fees, specilizations, phoneno FROM nursedata");

                    while (resultSet.next()) {
                        model.addRow(new Object[] {
                                resultSet.getInt("id"),
                                resultSet.getString("name"),
                                resultSet.getString("degree"),
                                resultSet.getString("fees"),
                                resultSet.getString("specilizations"),
                                resultSet.getString("phoneno")
                        });
                    }
                    connection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                table.setModel(model);

                // Customize the heading font and color
                JTableHeader header = table.getTableHeader();
                header.setFont(new Font("Jumble", Font.BOLD, 18)); // Set font
                header.setForeground(Color.RED); // Set color

                // Customize the data font and color
                TableCellRenderer renderer = table.getDefaultRenderer(Object.class);
                table.setDefaultRenderer(Object.class,
                        (JTable table1, Object value, boolean isSelected, boolean hasFocus, int row, int column) -> {
                            Component component = renderer.getTableCellRendererComponent(table1, value, isSelected,
                                    hasFocus, row, column);
                            component.setFont(new Font("Jumble", Font.BOLD, 14));
                            component.setForeground(Color.BLUE); // Set data color
                            return component;
                        });

                JScrollPane scrollPane = new JScrollPane(table);
                pdframe.add(scrollPane);
                pdframe.getContentPane().setBackground(Color.decode("#29bf86"));
                pdframe.setBounds(220, 260, 1320, 600);
                pdframe.setVisible(true);

            }
        });

        btnp4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee22) {
                JFrame paframe = new JFrame("Appointment form...");
                JButton abtn = new JButton("PATIENT INFORMATION");
                JLabel albl1 = new JLabel("Name           : ");
                JLabel albl2 = new JLabel("F/M-Name       : ");
                JLabel albl3 = new JLabel("Age            : ");
                JLabel albl4 = new JLabel("Date           : ");
                JLabel albl5 = new JLabel("Gender         : ");
                JLabel albl6 = new JLabel("Occupation     :");
                JLabel albl7 = new JLabel("Material Staus :");
                JLabel albl8 = new JLabel("Contact No.    :");
                JLabel albl9 = new JLabel("Address        : ");
                JLabel albl10 = new JLabel("");
                JLabel albl11 = new JLabel();
                JLabel albl12 = new JLabel();
                JTextField atxt1 = new JTextField(30);
                JTextField atxt2 = new JTextField(30);
                JTextField atxt3 = new JTextField(10);
                // JTextField atxt4=new JTextField();
                JDateChooser atxt4 = new JDateChooser();

                // JTextField atxt5=new JTextField();
                JRadioButton rbtn1 = new JRadioButton("Male");
                JRadioButton rbtn2 = new JRadioButton("Female");
                JRadioButton rbtn3 = new JRadioButton("Transgender");
                ButtonGroup bg = new ButtonGroup();

                // JTextField atxt6=new JTextField();
                String[] items = { "Strdent", "Employee", "Business", "Unemployment" };
                JComboBox<String> atxt6 = new JComboBox<>(items);
                // JTextField atxt7=new JTextField();
                String[] items1 = { "Single", "Married", "Devorced", "Separation" };
                JComboBox<String> atxt7 = new JComboBox<>(items1);

                JTextField atxt8 = new JTextField(10);
                JTextField atxt9 = new JTextField(20);

                JButton abtn1 = new JButton("Submit");
                JButton abtn2 = new JButton("Reset");
                JButton abtn3 = new JButton("Back");
                JButton abtn4 = new JButton("");

                abtn.setBounds(0, 0, 1320, 50);
                // abtn.setBounds(0, 0, 1320, 50);
                abtn4.setBounds(0, 52, 1320, 5);
                albl1.setBounds(20, 70, 200, 35);
                atxt1.setBounds(300, 70, 200, 35);
                albl2.setBounds(20, 130, 200, 35);
                atxt2.setBounds(300, 130, 200, 35);
                albl4.setBounds(600, 130, 200, 35);
                atxt3.setBounds(840, 70, 200, 35);
                albl3.setBounds(600, 70, 200, 35);
                atxt4.setBounds(840, 130, 200, 35);
                albl5.setBounds(20, 190, 200, 35);
                // atxt5.setBounds(300, 190, 200, 35);
                rbtn1.setBounds(300, 190, 80, 35);
                rbtn2.setBounds(380, 190, 80, 35);
                rbtn3.setBounds(470, 190, 110, 35);
                albl6.setBounds(20, 250, 200, 35);
                atxt6.setBounds(300, 250, 200, 35);
                albl7.setBounds(20, 320, 200, 35);
                atxt7.setBounds(300, 320, 200, 35);
                albl8.setBounds(600, 190, 200, 35);
                atxt8.setBounds(840, 190, 200, 35);
                albl9.setBounds(600, 250, 200, 35);
                atxt9.setBounds(840, 250, 200, 35);
                abtn1.setBounds(250, 450, 100, 40);
                abtn2.setBounds(500, 450, 100, 40);
                abtn3.setBounds(750, 450, 100, 40);

                Font f1 = new Font("Jumble", Font.BOLD, 30);
                Font f2 = new Font("Jumble", Font.BOLD, 25);
                abtn.setFont(f1);
                albl1.setFont(f2);
                albl2.setFont(f2);
                albl3.setFont(f2);

                albl4.setFont(f2);
                // rbtn1.setFont(f1);
                // rbtn2.setFont(f1);
                // rbtn3.setFont(f1);

                albl5.setFont(f2);
                albl6.setFont(f2);
                albl7.setFont(f2);
                albl8.setFont(f2);
                albl9.setFont(f2);
                albl10.setFont(f2);

                abtn.setBackground(Color.decode("#114fed"));
                albl1.setBackground(Color.decode("#bdbfc1"));
                abtn.setForeground(Color.WHITE);
                paframe.add(albl1);
                paframe.add(albl2);
                paframe.add(albl3);
                paframe.add(albl4);
                paframe.add(albl5);
                paframe.add(albl6);
                paframe.add(albl7);
                paframe.add(albl8);
                paframe.add(albl9);
                paframe.add(albl10);
                paframe.add(albl11);
                paframe.add(albl12);
                paframe.add(abtn);
                paframe.add(abtn1);
                paframe.add(abtn2);
                paframe.add(atxt1);
                paframe.add(atxt2);
                paframe.add(atxt3);
                paframe.add(atxt4);
                bg.add(rbtn1);
                bg.add(rbtn2);
                bg.add(rbtn3);

                // paframe.add(atxt5);
                // paframe.add(bg);
                paframe.add(rbtn1);
                paframe.add(rbtn2);
                paframe.add(rbtn3);

                paframe.add(atxt6);
                paframe.add(atxt7);
                paframe.add(atxt8);
                paframe.add(atxt9);
                paframe.add(abtn1);
                paframe.add(abtn2);
                paframe.add(abtn3);

                abtn1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee24) {
                        atxt4.setDate(new Date());
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        String formattedDob = dateFormat.format(atxt4.getDate());
                        String name = atxt1.getText();
                        String fname = atxt2.getText();
                        String age = atxt3.getText();
                        String mobno = atxt8.getText();
                        String address = atxt9.getText();
                        String occupation = (String) atxt6.getSelectedItem();
                        String mstatus = (String) atxt7.getSelectedItem();
                        String selectedGender = null;
                        if (rbtn1.isSelected()) {
                            selectedGender = rbtn1.getText();
                        } else if (rbtn2.isSelected()) {
                            selectedGender = rbtn2.getText();
                        } else if (rbtn3.isSelected()) {
                            selectedGender = rbtn3.getText();
                        }
                        int len = name.length();
                        int len1 = fname.length();
                        int len2 = age.length();
                        int len3 = mobno.length();
                        int len4 = address.length();
                        int len5 = occupation.length();
                        int len6 = mstatus.length();
                        int len8 = selectedGender.length();
                        // int len7=selectedGender.length();
                        if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0 || len4 == 0 || len5 == 0 || len6 == 0
                                || len8 == 0) {
                            JOptionPane.showMessageDialog(null, "Every fields are required", "Empty field",
                                    JOptionPane.INFORMATION_MESSAGE);

                        } else if (formattedDob == null) {
                            JOptionPane.showMessageDialog(null, "Every fields are required", "Empty field",
                                    JOptionPane.INFORMATION_MESSAGE);

                        } else {
                            try {
                                // Load the SQLite JDBC driver
                                // Class.forName("");

                                // Connect to the database (you may need to adjust the URL)
                                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS",
                                        "root",
                                        "Ankit@817raj#");

                                // Create a statement
                                // Statement statement = connection.createStatement();

                                // Create the table if it doesn't exist
                                DatabaseMetaData metaData = connection.getMetaData();
                                ResultSet tables = metaData.getTables(null, null, "patient_info", null);
                                boolean tableExists = tables.next();
                                if (!tableExists) {
                                    Statement statement = connection.createStatement();
                                    statement.executeUpdate(
                                            "CREATE TABLE patient_info(id INTEGER PRIMARY KEY AUTO_INCREMENT,name VARCHAR(35),fname VARCHAR(35),age VARCHAR(5),dob DATE,gender VARCHAR(20),occupation VARCHAR(35),marital_status VARCHAR(30),contact_no VARCHAR(10),address VARCHAR(30)");

                                }

                                // Insert the data into the table
                                // PreparedStatement preparedStatement = connection.prepareStatement(
                                String query1 = "INSERT INTO patient_info (name, fname, age, dob, gender, occupation, marital_status, contact_no, address)values('"
                                        + name + "','" + fname + "','" + age + "','" + formattedDob + "','"
                                        + selectedGender + "','" + occupation + "','" + mstatus + "','" + mobno + "','"
                                        + address + "')";

                                Statement sta = connection.createStatement();
                                int x = sta.executeUpdate(query1);
                                if (x == 0) {
                                    JOptionPane.showMessageDialog(null, "This is alredy exist");

                                } else {
                                    JOptionPane.showMessageDialog(null, "Data inserted successfully!", "Success",
                                            JOptionPane.INFORMATION_MESSAGE);

                                }
                                // JOptionPane.showMessageDialog(null, "Data inserted successfully!", "Success",
                                // JOptionPane.INFORMATION_MESSAGE);
                            } catch (Exception ee25) {
                                ee25.printStackTrace();
                            }
                        }
                    }
                });
                abtn3.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee22) {
                        paframe.dispose();
                    }
                });
                abtn2.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee23) {
                        atxt1.setText(null);
                        atxt2.setText(null);
                        atxt3.setText(null);
                        atxt4.setDate(null);
                        // rbtn1.setSelected(false);
                        // rbtn2.setSelected(false);
                        // rbtn3.setSelected(false);
                        atxt6.setSelectedItem(null);
                        atxt7.setSelectedItem(null);
                        atxt8.setText(null);
                        atxt9.setText(null);
                        // atxt1.setText(null);

                    }
                });

                paframe.getContentPane().setBackground(Color.decode("#ffffff"));
                paframe.setBounds(220, 260, 1320, 600);
                paframe.setLayout(null);
                paframe.setVisible(true);

            }
        });

        pframe.getContentPane().setBackground(Color.RED);
        pframe.setBounds(0, 130, 1540, 900);
        pframe.setLayout(null);
        pframe.setVisible(true);

    }

    public void Admin_page_signin() {
        frame3 = new JFrame("Admin Login page");
        JLabel lbl1 = new JLabel("Login Page");
        JLabel lbl2 = new JLabel("Username : ");
        JLabel lbl3 = new JLabel("Password : ");
        JTextField txt1 = new JTextField(35);
        JPasswordField txt2 = new JPasswordField(20);
        JButton btn1 = new JButton("Login");
        JButton btn2 = new JButton("Forgot password");
        JButton btn3 = new JButton("SignUp");
        lbl1.setBounds(140, 5, 150, 30);
        lbl2.setBounds(10, 70, 150, 30);
        lbl3.setBounds(10, 120, 150, 30);
        txt1.setBounds(150, 70, 200, 30);
        txt2.setBounds(150, 120, 200, 30);
        btn1.setBounds(120, 180, 150, 30);
        btn3.setBounds(300, 220, 80, 30);
        btn2.setBounds(200, 153, 150, 30);

        Font plainFont = new Font("Jumble", Font.BOLD, 25);
        Font plainFont1 = new Font("Jumble", Font.BOLD, 20);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 13);
        // Font plainFont3 = new Font("Jumble", Font.BOLD, 16);
        lbl1.setFont(plainFont);

        lbl2.setFont(plainFont1);
        lbl3.setFont(plainFont1);
        txt2.setFont(plainFont1);
        txt1.setFont(plainFont1);
        btn1.setFont(plainFont);
        btn2.setFont(plainFont2);
        btn3.setFont(plainFont2);

        frame3.add(lbl1);
        frame3.add(lbl2);
        frame3.add(lbl3);
        frame3.add(txt1);
        frame3.add(txt2);
        frame3.add(btn1);
        frame3.add(btn2);
        frame3.add(btn3);
        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
                String username = txt1.getText();
                String password = new String(txt2.getPassword());
                Integer len = username.length();
                Integer len1 = username.length();
                if (len == 0 || len1 == 0) {
                    JOptionPane.showMessageDialog(btn1, "Every Field is required!!!");
                } else {
                    // JOptionPane.showMessageDialog(btn1,"Every Field is required!!!");

                    try {
                        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                                "Ankit@817raj#");

                        PreparedStatement statement = connection
                                .prepareStatement("Select * from Admin_login_data where username=? and password=?");
                        statement.setString(1, username);
                        statement.setString(2, password);
                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(btn1, "Login successful!");
                            txt1.setText("");
                            txt2.setText("");
                            Admin_manage();
                            frame3.dispose();

                        } else {
                            JOptionPane.showMessageDialog(btn1, "Invalid username or password");
                        }
                    } catch (Exception ee) {
                        ee.printStackTrace();
                    }
                }

            }

        });

        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee5) {
                Admin_registraion_page();
                frame3.dispose();
            }
        });
        btn2.setBackground(Color.decode("#65889e"));

        frame3.getContentPane().setBackground(Color.decode("#65889e"));
        frame3.setBounds(480, 300, 400, 300);
        frame3.setLayout(null);
        frame3.setVisible(true);

    }

    public void Admin_registraion_page() {
        frame4 = new JFrame();
        JLabel lbl = new JLabel("Registraion");
        JLabel lbl1 = new JLabel("Email-Id      : ");
        JLabel lbl2 = new JLabel("Name          : ");
        JLabel lbl3 = new JLabel("Username  :");
        JLabel lbl4 = new JLabel("Password  : ");
        JLabel lbl5 = new JLabel("Phone No. : ");
        JButton btn1 = new JButton("Registration");
        JButton btn2 = new JButton("Login Here");
        JTextField txt1 = new JTextField(35);
        JTextField txt2 = new JTextField(35);
        JTextField txt3 = new JTextField(35);
        JTextField txt5 = new JTextField(35);
        // JTextField txt5=new JTextField(35);
        JPasswordField txt4 = new JPasswordField(20);

        // Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
        // Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

        lbl.setBounds(160, 5, 300, 40);
        lbl1.setBounds(20, 70, 150, 30);
        lbl2.setBounds(20, 120, 150, 30);
        lbl3.setBounds(20, 170, 150, 30);
        lbl4.setBounds(20, 220, 150, 30);
        lbl5.setBounds(20, 270, 150, 30);
        txt1.setBounds(220, 70, 150, 30);
        txt2.setBounds(220, 120, 150, 30);
        txt3.setBounds(220, 170, 150, 30);
        txt4.setBounds(220, 220, 150, 30);
        txt5.setBounds(220, 270, 150, 30);
        btn1.setBounds(130, 350, 170, 30);
        btn2.setBounds(280, 420, 150, 30);

        lbl.setFont(plainFont2);
        lbl1.setFont(plainFont2);
        lbl2.setFont(plainFont2);
        lbl3.setFont(plainFont2);
        lbl4.setFont(plainFont2);
        lbl5.setFont(plainFont2);
        txt1.setFont(plainFont2);
        txt2.setFont(plainFont2);
        txt3.setFont(plainFont2);
        txt4.setFont(plainFont2);
        txt5.setFont(plainFont2);
        btn1.setFont(plainFont2);
        btn2.setFont(plainFont2);

        frame4.add(lbl);
        frame4.add(lbl1);
        frame4.add(lbl2);
        frame4.add(lbl3);
        frame4.add(lbl4);
        frame4.add(lbl5);
        frame4.add(txt1);
        frame4.add(txt2);
        frame4.add(txt3);
        frame4.add(txt4);
        frame4.add(txt5);

        frame4.add(btn1);
        frame4.add(btn2);
        // frame1.add(lbl);

        btn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee2) {
                String emial = txt1.getText();
                String name = txt2.getText();
                String username = txt3.getText();
                String password = new String(txt4.getPassword());
                String phone = txt5.getText();
                Integer len = emial.length();
                Integer len1 = name.length();
                Integer len2 = username.length();
                Integer len3 = password.length();
                Integer len4 = phone.length();
                String msg = "" + name;
                if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0 || len4 == 0) {
                    JOptionPane.showMessageDialog(btn2, "Every fields are required!!");
                } else if (len4 < 10) {
                    JOptionPane.showMessageDialog(btn1, "Phone No should be 10 digits!!!");

                } else {
                    try {
                        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                                "Ankit@817raj#");

                        DatabaseMetaData metaData = connection.getMetaData();
                        ResultSet tables = metaData.getTables(null, null, "Admin_login_data", null);
                        boolean tableExists = tables.next();
                        if (!tableExists) {
                            Statement statement = connection.createStatement();
                            statement.executeUpdate(
                                    "Create table Admin_login_data(id INT AUTO_INCREMENT PRIMARY KEY,email varchar(25) not null,name varchar(25) not null,username varchar(50) not null,password varchar(30) not null,phone int(20) not null)");
                        }
                        String query1 = "INSERT INTO Admin_login_data(email,name,username,password,phone) values('"
                                + emial + "','" + name + "','"
                                + username + "','" + password + "','" + phone + "')";

                        Statement sta = connection.createStatement();
                        int x = sta.executeUpdate(query1);

                        if (x == 0) {
                            JOptionPane.showMessageDialog(btn1, "This is alredy exist");
                        } else {
                            JOptionPane.showMessageDialog(btn1,
                                    "Congratulations " + msg + "Your Registraions sucessfully....");
                            txt1.setText("");
                            txt2.setText("");
                            txt3.setText("");
                            txt4.setText("");
                            txt5.setText("");
                            Admin_page_signin();
                            // t6.setText("");
                            // t7.setText("");

                        }

                    } catch (Exception ee3) {
                        ee3.printStackTrace();
                    }
                }

            }

        });
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee6) {
                Admin_page_signin();
            }
        });

        frame4.getContentPane().setBackground(Color.decode("#fae607"));
        frame4.setBounds(300, 250, 450, 500);
        frame4.setLayout(null);
        frame4.setVisible(true);

    }

    public void Admin_manage() {
        frame2 = new JFrame("Admin Page");
        JButton btn15 = new JButton("");
        JButton btn1 = new JButton("MENU");
        JButton btn2 = new JButton("DOCTOR");
        JButton btn3 = new JButton("NURSE");
        JButton btn4 = new JButton("PATIENT HISTORY");
        JButton btn5 = new JButton("MEDICAL");
        JButton btn6 = new JButton("BILL PAYMENT");
        JButton btn7 = new JButton("EXIT");
        JButton btn8 = new JButton("LOGOUT");

        Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
        Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
        Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
        Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
        Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
        Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

        btn1.setBounds(20, 20, 120, 40);

        btn2.setBounds(250, 20, 120, 40);
        btn3.setBounds(400, 20, 120, 40);
        btn4.setBounds(550, 20, 200, 40);
        btn5.setBounds(800, 20, 120, 40);
        btn6.setBounds(950, 20, 200, 40);
        btn7.setBounds(1220, 20, 100, 40);
        btn8.setBounds(1370, 20, 100, 40);

        // btn11.setBounds(10, 120, 200, 40);
        // btn12.setBounds(10, 180, 200, 40);
        // btn13.setBounds(10, 240, 200, 40);
        // btn14.setBounds(10, 300, 200, 40);
        btn15.setBounds(0, 80, 1540, 5);
        // btn16.setBounds(200, 85, 5, 900);

        btn1.setFont(plainFont1);
        btn2.setFont(plainFont1);
        btn3.setFont(plainFont1);
        btn4.setFont(plainFont1);
        btn5.setFont(plainFont1);
        btn6.setFont(plainFont1);
        btn7.setFont(plainFont1);
        btn8.setFont(plainFont1);

        btn1.setBackground(Color.GREEN);
        btn15.setBackground(Color.WHITE);
        // btn16.setBackground(Color.WHITE);
        btn1.setBorder(border3);
        btn1.setFont(plainFont2);
        // btn11.setFont(plainFont2);
        // btn12.setFont(plainFont2);
        // btn13.setFont(plainFont2);
        // btn14.setFont(plainFont2);
        btn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee6) {
                frame2.dispose();
                frame4 = new JFrame("Manage Doctor data");
                JLabel lbl1 = new JLabel("Manage Doctor Data");
                JButton btn11 = new JButton("ADD NEW");
                JButton btn12 = new JButton("UPDATE");
                JButton btn13 = new JButton("DELETE");
                JButton btn15 = new JButton("");
                JButton btn16 = new JButton("");
                JButton btn14 = new JButton("SEARCH");
                JButton btn17 = new JButton("SHOW");
                JButton btn18 = new JButton("BACK");

                lbl1.setBounds(0, 0, 1540, 100);
                btn11.setBounds(10, 110, 200, 40);
                btn12.setBounds(10, 180, 200, 40);
                btn13.setBounds(10, 260, 200, 40);
                btn14.setBounds(10, 340, 200, 40);
                btn15.setBounds(0, 100, 1540, 5);
                btn16.setBounds(220, 105, 5, 900);
                btn17.setBounds(10, 420, 200, 40);
                btn18.setBounds(10, 500, 200, 40);
                Font plainFont4 = new Font("Jumble", Font.BOLD, 45);
                Border border2 = BorderFactory.createLineBorder(Color.RED, 10);

                lbl1.setBorder(border2);
                lbl1.setHorizontalAlignment(JLabel.CENTER);
                btn11.setFont(plainFont2);
                btn12.setFont(plainFont2);
                btn13.setFont(plainFont2);
                btn14.setFont(plainFont2);
                btn17.setFont(plainFont2);
                btn18.setFont(plainFont2);
                lbl1.setFont(plainFont4);
                btn16.setBackground(Color.WHITE);
                lbl1.setBackground(Color.PINK);
                frame4.add(lbl1);
                frame4.add(btn11);
                frame4.add(btn12);
                frame4.add(btn13);
                frame4.add(btn14);
                frame4.add(btn15);
                frame4.add(btn16);
                frame4.add(btn17);
                frame4.add(btn18);
                btn11.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee8) {
                        JFrame frame5 = new JFrame("Add doctor data");

                        JLabel lbld1 = new JLabel("Email-ID :  ");
                        JLabel lbld2 = new JLabel("Username : ");
                        JLabel lbld3 = new JLabel("Name : ");
                        JLabel lbld4 = new JLabel("Password: ");
                        JLabel lbld5 = new JLabel("Phone N0 : ");
                        JLabel lbld6 = new JLabel("Address : ");
                        JLabel lbld7 = new JLabel("DOB : ");
                        JLabel lbld8 = new JLabel("Doctor Degree : ");
                        JLabel lbld9 = new JLabel("Specializations : ");
                        JLabel lbld10 = new JLabel("Fees : ");
                        JLabel lbld11 = new JLabel("Joined Date : ");
                        JLabel lbld12 = new JLabel("Id No : ");
                        JTextField txtd1 = new JTextField();
                        JPasswordField txtd4 = new JPasswordField();
                        JTextField txtd3 = new JTextField();
                        JTextField txtd2 = new JTextField();
                        JTextField txtd5 = new JTextField();
                        String[] items = { "Bihar", "Delhi", "Mumbai", "Punjab", "Up" };
                        JComboBox<String> txtd6 = new JComboBox<>(items);
                        // JTextField txtd7 = new JTextField();
                        JDateChooser txtd7 = new JDateChooser();
                        String[] items1 = { "MBBS", "BDS", "BAMS", "BHMS", "BYNS", "BUMS" };
                        JComboBox<String> txtd8 = new JComboBox<>(items1);
                        String[] items2 = { "Family medicine", "Internal medicine", "Dermatology", "Medical genetics",
                                "Emergency Medicine" };
                        JComboBox<String> txtd9 = new JComboBox<>(items2);
                        JTextField txtd10 = new JTextField();
                        JDateChooser txtd11 = new JDateChooser();
                        JTextField txtd12 = new JTextField();
                        // JButton txtd12 = new JButton("Select Image");
                        JButton btnd1 = new JButton("Submit");

                        lbld1.setBounds(20, 10, 200, 35);
                        lbld2.setBounds(440, 10, 200, 35);
                        lbld3.setBounds(20, 60, 200, 35);
                        lbld4.setBounds(440, 60, 200, 35);
                        lbld5.setBounds(20, 110, 200, 35);
                        lbld6.setBounds(440, 110, 200, 35);
                        lbld7.setBounds(20, 160, 200, 35);
                        lbld8.setBounds(440, 160, 200, 35);
                        lbld9.setBounds(20, 210, 200, 35);
                        lbld10.setBounds(440, 210, 200, 35);
                        lbld11.setBounds(20, 260, 200, 35);
                        lbld12.setBounds(440, 260, 200, 35);
                        txtd1.setBounds(200, 10, 200, 35);
                        txtd2.setBounds(680, 10, 200, 35);
                        txtd3.setBounds(200, 60, 200, 35);
                        txtd4.setBounds(680, 60, 200, 35);
                        txtd5.setBounds(200, 110, 200, 35);
                        txtd6.setBounds(680, 110, 200, 35);
                        txtd7.setBounds(200, 160, 200, 35);
                        txtd8.setBounds(680, 160, 200, 35);
                        txtd9.setBounds(200, 210, 200, 35);
                        txtd10.setBounds(680, 210, 200, 35);
                        txtd11.setBounds(200, 260, 200, 35);
                        txtd12.setBounds(680, 260, 120, 35);
                        btnd1.setBounds(300, 350, 150, 50);
                        txtd11.setDateFormatString("yyyy-MM-dd");

                        lbld1.setFont(plainFont2);
                        lbld2.setFont(plainFont2);
                        lbld3.setFont(plainFont2);
                        lbld4.setFont(plainFont2);
                        lbld5.setFont(plainFont2);
                        lbld6.setFont(plainFont2);
                        lbld7.setFont(plainFont2);
                        lbld8.setFont(plainFont2);
                        lbld9.setFont(plainFont2);
                        lbld10.setFont(plainFont2);
                        lbld11.setFont(plainFont2);
                        lbld12.setFont(plainFont2);
                        btnd1.setFont(plainFont2);

                        frame5.add(lbld1);
                        frame5.add(lbld2);
                        frame5.add(lbld3);
                        frame5.add(lbld4);
                        frame5.add(lbld5);
                        frame5.add(lbld6);
                        frame5.add(lbld7);
                        frame5.add(lbld8);
                        frame5.add(lbld9);
                        frame5.add(lbld10);
                        frame5.add(lbld11);
                        frame5.add(lbld12);

                        frame5.add(txtd1);
                        frame5.add(txtd2);
                        frame5.add(txtd3);
                        frame5.add(txtd4);
                        frame5.add(txtd5);
                        frame5.add(txtd6);
                        frame5.add(txtd7);
                        frame5.add(txtd8);
                        frame5.add(txtd9);
                        frame5.add(txtd10);
                        frame5.add(txtd11);
                        frame5.add(txtd12);

                        frame5.add(btnd1);

                        btnd1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee9) {

                                Date dob = txtd11.getDate();
                                Date dob1 = txtd7.getDate();
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                String formattedDob = dateFormat.format(dob);
                                String formattedDob1 = dateFormat.format(dob1);

                                String email_id = txtd1.getText();
                                String username = txtd2.getText();
                                String msg = "" + username;
                                String name = txtd3.getText();
                                String phoneno = txtd5.getText();
                                String password = new String(txtd4.getPassword());
                                String adress = (String) txtd6.getSelectedItem();
                                String degree = (String) txtd8.getSelectedItem();
                                String specializations = (String) txtd9.getSelectedItem();
                                String fees = txtd10.getText();
                                String Idno = txtd12.getText();

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();
                                int len3 = fees.length();
                                int len4 = username.length();
                                int len5 = phoneno.length();
                                int len6 = Idno.length();

                                if (dob == null) {
                                    JOptionPane.showMessageDialog(null, "Please Choose Your joined date",
                                            "Empty fileds", JOptionPane.ERROR_MESSAGE);
                                } else if (dob1 == null) {
                                    JOptionPane.showMessageDialog(null, "Please choose your Dob.", "Empty Fields",
                                            JOptionPane.ERROR_MESSAGE);
                                }

                                else if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0 || len4 == 0 || len6 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else if (len5 != 10) {
                                    JOptionPane.showMessageDialog(null, "Please enter the valid mobile no",
                                            "less than 10", JOptionPane.ERROR_MESSAGE);

                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                "Ankit@817raj#");

                                        DatabaseMetaData metaData = connection.getMetaData();
                                        ResultSet tables = metaData.getTables(null, null, "doctordata", null);
                                        boolean tableExists = tables.next();
                                        if (!tableExists) {
                                            Statement statement = connection.createStatement();
                                            statement.executeUpdate(
                                                    "CREATE TABLE doctordata(id INT AUTO_INCREMENT PRIMARY KEY,email VARCHAR(25) NOT NULL,username VARCHAR(25) NOT NULL, name VARCHAR(50) NOT NULL,password VARCHAR(30) NOT NULL,phoneno VARCHAR(30) NOT NULL,address VARCHAR(50) NOT NULL,dob DATE,degree VARCHAR(50) NOT NULL,specilizations VARCHAR(50) NOT NULL,fees VARCHAR(50) NOT NULL,jdate DATE,idno VARCHAR(10))");
                                        }
                                        String checkQuery = "SELECT * FROM doctordata WHERE username = ?";
                                        PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
                                        checkStatement.setString(1, username);
                                        ResultSet resultSet = checkStatement.executeQuery();

                                        if (resultSet.next()) {
                                            JOptionPane.showMessageDialog(null,
                                                    "Username already exists. Please choose a different username.",
                                                    "Username Exists", JOptionPane.ERROR_MESSAGE);
                                        } else {

                                            String query1 = "INSERT INTO doctordata (email, username, name, password, phoneno, address, dob, degree, specilizations, fees, jdate, idno) VALUES ('"
                                                    + email_id + "','" + username + "','" + name + "','" + password
                                                    + "','"
                                                    + phoneno + "','" + adress + "','"
                                                    + formattedDob + "','" + degree + "','" + specializations + "','"
                                                    + fees
                                                    + "','" + formattedDob1 + "','"
                                                    + Idno + "')";

                                            Statement sta = connection.createStatement();
                                            int x = sta.executeUpdate(query1);

                                            if (x == 0) {
                                                JOptionPane.showMessageDialog(btn1, "This is alredy exist");
                                            } else {
                                                JOptionPane.showMessageDialog(btn1,
                                                        "Congratulations " + msg + "Your Registraions sucessfully....");
                                                txtd1.setText("");
                                                txtd2.setText("");
                                                txtd3.setText("");
                                                txtd4.setText("");
                                                txtd5.setText("");
                                                txtd10.setText("");
                                                txtd12.setText("");
                                                txtd11.setDate(null);

                                            }
                                        }

                                    } catch (Exception ee3) {
                                        ee3.printStackTrace();
                                    }

                                }

                            }
                        });

                        frame5.getContentPane().setBackground(Color.CYAN);
                        frame5.setBounds(225, 265, 1330, 600);
                        frame5.setLayout(null);
                        frame5.setVisible(true);

                    }
                });
                btn12.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee8) {
                        JFrame frame6 = new JFrame("Update Doctor data");

                        JLabel lbldu1 = new JLabel("Email-ID :  ");
                        JLabel lbldu2 = new JLabel("Username : ");
                        JLabel lbldu3 = new JLabel("Name : ");
                        JLabel lbldu4 = new JLabel("Password: ");

                        JTextField txtdu1 = new JTextField(40);
                        JPasswordField txtdu4 = new JPasswordField(25);
                        JTextField txtdu3 = new JTextField(35);
                        JTextField txtdu2 = new JTextField(25);

                        JButton btndu1 = new JButton("Submit");

                        lbldu1.setBounds(20, 10, 200, 35);
                        lbldu2.setBounds(20, 60, 200, 35);
                        lbldu3.setBounds(20, 110, 200, 35);
                        lbldu4.setBounds(20, 160, 200, 35);

                        txtdu1.setBounds(220, 10, 200, 35);
                        txtdu2.setBounds(220, 60, 200, 35);
                        txtdu3.setBounds(220, 110, 200, 35);
                        txtdu4.setBounds(220, 160, 200, 35);
                        btndu1.setBounds(220, 350, 120, 40);

                        lbldu1.setFont(plainFont2);
                        lbldu2.setFont(plainFont2);
                        lbldu3.setFont(plainFont2);
                        lbldu4.setFont(plainFont2);

                        btndu1.setFont(plainFont2);

                        frame6.add(lbldu1);
                        frame6.add(lbldu2);
                        frame6.add(lbldu3);
                        frame6.add(lbldu4);

                        frame6.add(txtdu1);
                        frame6.add(txtdu2);
                        frame6.add(txtdu3);
                        frame6.add(txtdu4);

                        frame6.add(btndu1);

                        btndu1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee9) {

                                String email_id = txtdu1.getText();
                                String username = txtdu2.getText();
                                String msg = "" + username;
                                String name = txtdu3.getText();

                                String password = new String(txtdu4.getPassword());

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();

                                int len4 = username.length();
                                if (len == 0 || len1 == 0 || len2 == 0 || len4 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM doctordata WHERE email = ? AND name = ? AND username = ? AND password = ?";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        fetchStatement.setString(1, email_id);
                                        fetchStatement.setString(2, name);
                                        fetchStatement.setString(3, username);
                                        fetchStatement.setString(4, password);

                                        ResultSet resultSet = fetchStatement.executeQuery();

                                        if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame frame7 = new JFrame("Update Doctor data");

                                            JLabel lbldu1 = new JLabel("Email-ID :  ");
                                            JLabel lbldu2 = new JLabel("Username : ");
                                            JLabel lbldu3 = new JLabel("Name : ");
                                            JLabel lbldu4 = new JLabel("Password: ");
                                            JLabel lbldu5 = new JLabel("Phone N0 : ");
                                            JLabel lbldu6 = new JLabel("Address : ");
                                            JLabel lbldu7 = new JLabel("DOB : ");
                                            JLabel lbldu8 = new JLabel("Doctor Degree : ");
                                            JLabel lbldu9 = new JLabel("Specializations : ");
                                            JLabel lbldu10 = new JLabel("Fees : ");
                                            JLabel lbldu11 = new JLabel("Joined Date : ");
                                            // JLabel lbldu12 = new JLabel("Id No : ");
                                            JTextField txtdu1 = new JTextField(email);
                                            JPasswordField txtdu4 = new JPasswordField(dpassword);
                                            JTextField txtdu3 = new JTextField(dname);
                                            JTextField txtdu2 = new JTextField(user_name);
                                            JTextField txtdu5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtdu6 = new JComboBox<>(adressarray);

                                            // JTextField txtd7 = new JTextField();
                                            JDateChooser txtdu7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtdu8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtdu9 = new JComboBox<>(dspecialzationarray);

                                            JTextField txtdu10 = new JTextField(dfees);
                                            JDateChooser txtdu11 = new JDateChooser(djoin_date);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btndu1 = new JButton("Submit");

                                            lbldu1.setBounds(20, 10, 200, 35);
                                            lbldu2.setBounds(440, 10, 200, 35);
                                            lbldu3.setBounds(20, 60, 200, 35);
                                            lbldu4.setBounds(440, 60, 200, 35);
                                            lbldu5.setBounds(20, 110, 200, 35);
                                            lbldu6.setBounds(440, 110, 200, 35);
                                            lbldu7.setBounds(20, 160, 200, 35);
                                            lbldu8.setBounds(440, 160, 200, 35);
                                            lbldu9.setBounds(20, 210, 200, 35);
                                            lbldu10.setBounds(440, 210, 200, 35);
                                            lbldu11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtdu1.setBounds(200, 10, 200, 35);
                                            txtdu2.setBounds(680, 10, 200, 35);
                                            txtdu3.setBounds(200, 60, 200, 35);
                                            txtdu4.setBounds(680, 60, 200, 35);
                                            txtdu5.setBounds(200, 110, 200, 35);
                                            txtdu6.setBounds(680, 110, 200, 35);
                                            txtdu7.setBounds(200, 160, 200, 35);
                                            txtdu8.setBounds(680, 160, 200, 35);
                                            txtdu9.setBounds(200, 210, 200, 35);
                                            txtdu10.setBounds(680, 210, 200, 35);
                                            txtdu11.setBounds(200, 260, 200, 35);
                                            // txtdu12.setBounds(680, 260, 120, 35);
                                            btndu1.setBounds(300, 350, 150, 50);
                                            txtdu11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lbldu1.setFont(plainFont2);
                                            lbldu2.setFont(plainFont2);
                                            lbldu3.setFont(plainFont2);
                                            lbldu4.setFont(plainFont2);
                                            lbldu5.setFont(plainFont2);
                                            lbldu6.setFont(plainFont2);
                                            lbldu7.setFont(plainFont2);
                                            lbldu8.setFont(plainFont2);
                                            lbldu9.setFont(plainFont2);
                                            lbldu10.setFont(plainFont2);
                                            lbldu11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btndu1.setFont(plainFont2);

                                            frame7.add(lbldu1);
                                            frame7.add(lbldu2);
                                            frame7.add(lbldu3);
                                            frame7.add(lbldu4);
                                            frame7.add(lbldu5);
                                            frame7.add(lbldu6);
                                            frame7.add(lbldu7);
                                            frame7.add(lbldu8);
                                            frame7.add(lbldu9);
                                            frame7.add(lbldu10);
                                            frame7.add(lbldu11);
                                            // frame6.add(lbldu12);
                                            frame7.add(txtdu1);
                                            frame7.add(txtdu2);
                                            frame7.add(txtdu3);
                                            frame7.add(txtdu4);
                                            frame7.add(txtdu5);
                                            frame7.add(txtdu6);
                                            frame7.add(txtdu7);
                                            frame7.add(txtdu8);
                                            frame7.add(txtdu9);
                                            frame7.add(txtdu10);
                                            frame7.add(txtdu11);
                                            // frame6.add(txtdu12);

                                            frame7.add(btndu1);
                                            btndu1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee13) {
                                                    Date newdob = txtdu11.getDate();
                                                    String newDobDate = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob);
                                                    Date newdob1 = txtdu7.getDate();
                                                    String newDob1Date = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob1);

                                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                                    String formattedDob = dateFormat.format(newdob);
                                                    String formattedDob1 = dateFormat.format(newdob1);

                                                    String newemail_id = txtdu1.getText();
                                                    String newusername = txtdu2.getText();
                                                    String msg = "" + username;
                                                    String newname = txtdu3.getText();
                                                    String newphoneno = txtdu5.getText();
                                                    String newpassword = new String(txtdu4.getPassword());
                                                    String newaddress = (String) txtdu6.getSelectedItem();
                                                    String newdegree = (String) txtdu8.getSelectedItem();
                                                    String newspecializations = (String) txtdu9.getSelectedItem();
                                                    String newfees = txtdu10.getText();
                                                    // String Idno = txtdu12.getText();

                                                    String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                                    int len = newemail_id.length();
                                                    int len1 = newname.length();
                                                    int len2 = newpassword.length();
                                                    int len3 = newfees.length();
                                                    int len4 = newusername.length();
                                                    int len5 = newphoneno.length();
                                                    // int len6 = Idno.length();
                                                    if (newdob == null) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please Choose Your joined date",
                                                                "Empty fileds", JOptionPane.ERROR_MESSAGE);
                                                    } else if (newdob1 == null) {
                                                        JOptionPane.showMessageDialog(null, "Please choose your Dob.",
                                                                "Empty Fields",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    }

                                                    else if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0
                                                            || len4 == 0) {
                                                        JOptionPane.showMessageDialog(null, "Every Filed is required",
                                                                "Empty fileds",
                                                                JOptionPane.ERROR_MESSAGE);

                                                    } else if (!Pattern.matches(emailPattern, newemail_id)) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Invalid email address. Please enter a valid email.",
                                                                "Validation Result",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    } else if (len5 != 10) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please enter the valid mobile no",
                                                                "less than 10", JOptionPane.ERROR_MESSAGE);

                                                    } else {
                                                        try {
                                                            Connection connection = DriverManager.getConnection(
                                                                    "jdbc:mysql://localhost:3306/CMS", "root",
                                                                    "Ankit@817raj#");

                                                            String updateQuery = "UPDATE doctordata SET email = ?, username = ?, name = ?, password = ?, phoneno = ?, address = ?, dob = ?, degree = ?, specilizations = ?, fees = ?, jdate = ? WHERE username = ?";

                                                            PreparedStatement updateStatement = connection
                                                                    .prepareStatement(updateQuery);
                                                            // updateStatement.setString(1, username);
                                                            updateStatement.setString(1, newemail_id);
                                                            updateStatement.setString(2, newusername);
                                                            updateStatement.setString(3, newname);
                                                            updateStatement.setString(4, newpassword);
                                                            updateStatement.setString(5, newphoneno);
                                                            updateStatement.setString(6, newaddress);
                                                            updateStatement.setString(7, newDobDate);
                                                            updateStatement.setString(8, newdegree);
                                                            updateStatement.setString(9, newspecializations);
                                                            updateStatement.setString(10, newfees);
                                                            updateStatement.setString(11, newDob1Date);
                                                            // updateStatement.setString(12, newIdNo);
                                                            updateStatement.setString(12, username);

                                                            int rowsAffected = updateStatement.executeUpdate();

                                                            if (rowsAffected > 0) {
                                                                JOptionPane.showMessageDialog(null,
                                                                        "Update successfully",
                                                                        "Update data", JOptionPane.ERROR_MESSAGE);
                                                            } else {

                                                            }

                                                        } catch (Exception ee3) {
                                                            ee3.printStackTrace();
                                                        }

                                                    }

                                                }
                                            });

                                            frame7.getContentPane().setBackground(Color.CYAN);

                                            frame7.setBounds(225, 265, 1330, 600);
                                            frame7.setLayout(null);
                                            frame7.setVisible(true);

                                        } else {
                                            // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            }
                        });

                        frame6.getContentPane().setBackground(Color.CYAN);
                        frame6.setBounds(225, 265, 1330, 600);
                        frame6.setLayout(null);
                        frame6.setVisible(true);

                    }
                });
                btn13.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee13) {
                        JFrame frame8 = new JFrame("delete Doctor data");

                        JLabel lbldd1 = new JLabel("Email-ID :  ");
                        JLabel lbldd2 = new JLabel("Username : ");
                        JLabel lbldd3 = new JLabel("Name : ");
                        JLabel lbldd4 = new JLabel("Password: ");

                        JTextField txtdd1 = new JTextField(40);
                        JPasswordField txtdd4 = new JPasswordField(25);
                        JTextField txtdd3 = new JTextField(35);
                        JTextField txtdd2 = new JTextField(25);

                        JButton btndd1 = new JButton("Submit");

                        lbldd1.setBounds(20, 10, 200, 35);
                        lbldd2.setBounds(20, 60, 200, 35);
                        lbldd3.setBounds(20, 110, 200, 35);
                        lbldd4.setBounds(20, 160, 200, 35);

                        txtdd1.setBounds(220, 10, 200, 35);
                        txtdd2.setBounds(220, 60, 200, 35);
                        txtdd3.setBounds(220, 110, 200, 35);
                        txtdd4.setBounds(220, 160, 200, 35);
                        btndd1.setBounds(220, 350, 120, 40);

                        lbldd1.setFont(plainFont2);
                        lbldd2.setFont(plainFont2);
                        lbldd3.setFont(plainFont2);
                        lbldd4.setFont(plainFont2);

                        btndd1.setFont(plainFont2);

                        frame8.add(lbldd1);
                        frame8.add(lbldd2);
                        frame8.add(lbldd3);
                        frame8.add(lbldd4);

                        frame8.add(txtdd1);
                        frame8.add(txtdd2);
                        frame8.add(txtdd3);
                        frame8.add(txtdd4);

                        frame8.add(btndd1);
                        btndd1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee13) {
                                String email_id = txtdd1.getText();
                                String username = txtdd2.getText();
                                String msg = "" + username;
                                String name = txtdd3.getText();

                                String password = new String(txtdd4.getPassword());

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();

                                int len4 = username.length();
                                if (len == 0 || len1 == 0 || len2 == 0 || len4 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        // The username you want to delete
                                        String fetchQuery = "SELECT * FROM doctordata WHERE email = ? AND name = ? AND username = ? AND password = ?";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        fetchStatement.setString(1, email_id);
                                        fetchStatement.setString(2, name);
                                        fetchStatement.setString(3, username);
                                        fetchStatement.setString(4, password);

                                        int rowsAffected = fetchStatement.executeUpdate();
                                        if (rowsAffected > 0) {

                                            String deleteQuery = "DELETE FROM doctordata WHERE username = ?";
                                            PreparedStatement deleteStatement = connection
                                                    .prepareStatement(deleteQuery);
                                            deleteStatement.setString(1, username);

                                            int rowsAffected1 = deleteStatement.executeUpdate();

                                            if (rowsAffected1 > 0) {
                                                JOptionPane.showMessageDialog(null, "Record deleted successfully.",
                                                        "Success", JOptionPane.INFORMATION_MESSAGE);
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Invalid .", "Invalid",
                                                        JOptionPane.ERROR_MESSAGE);
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Invalid username.", "Invalid",
                                                    JOptionPane.ERROR_MESSAGE);

                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            }

                        });
                        frame8.getContentPane().setBackground(Color.CYAN);
                        frame8.setBounds(225, 265, 1330, 600);
                        frame8.setLayout(null);
                        frame8.setVisible(true);

                    }
                });
                btn14.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee15) {
                        JFrame frame9 = new JFrame("Update Doctor data");

                        JLabel lblds1 = new JLabel("Email-ID :  ");
                        JLabel lblds2 = new JLabel("Username : ");
                        JLabel lblds3 = new JLabel("Name : ");
                        JLabel lblds4 = new JLabel("Password: ");

                        JTextField txtds1 = new JTextField(40);
                        JPasswordField txtds4 = new JPasswordField(25);
                        JTextField txtds3 = new JTextField(35);
                        JTextField txtds2 = new JTextField(25);

                        JButton btnds1 = new JButton("Submit");

                        lblds1.setBounds(20, 10, 200, 35);
                        lblds2.setBounds(20, 60, 200, 35);
                        lblds3.setBounds(20, 110, 200, 35);
                        lblds4.setBounds(20, 160, 200, 35);

                        txtds1.setBounds(220, 10, 200, 35);
                        txtds2.setBounds(220, 60, 200, 35);
                        txtds3.setBounds(220, 110, 200, 35);
                        txtds4.setBounds(220, 160, 200, 35);
                        btnds1.setBounds(220, 350, 120, 40);

                        lblds1.setFont(plainFont2);
                        lblds2.setFont(plainFont2);
                        lblds3.setFont(plainFont2);
                        lblds4.setFont(plainFont2);

                        btnds1.setFont(plainFont2);

                        frame9.add(lblds1);
                        frame9.add(lblds2);
                        frame9.add(lblds3);
                        frame9.add(lblds4);

                        frame9.add(txtds1);
                        frame9.add(txtds2);
                        frame9.add(txtds3);
                        frame9.add(txtds4);

                        frame9.add(btnds1);

                        btnds1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee9) {

                                String email_id = txtds1.getText();
                                String username = txtds2.getText();
                                String msg = "" + username;
                                String name = txtds3.getText();

                                String password = new String(txtds4.getPassword());

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();

                                int len4 = username.length();
                                if (len == 0 || len1 == 0 || len2 == 0 || len4 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM doctordata WHERE email = ? AND name = ? AND username = ? AND password = ?";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        fetchStatement.setString(1, email_id);
                                        fetchStatement.setString(2, name);
                                        fetchStatement.setString(3, username);
                                        fetchStatement.setString(4, password);

                                        ResultSet resultSet = fetchStatement.executeQuery();

                                        if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame frame10 = new JFrame("Update Doctor data");

                                            JLabel lbldss1 = new JLabel("Email-ID :  ");
                                            JLabel lbldss2 = new JLabel("Username : ");
                                            JLabel lbldss3 = new JLabel("Name : ");
                                            JLabel lbldss4 = new JLabel("Password: ");
                                            JLabel lbldss5 = new JLabel("Phone N0 : ");
                                            JLabel lbldss6 = new JLabel("Address : ");
                                            JLabel lbldss7 = new JLabel("DOB : ");
                                            JLabel lbldss8 = new JLabel("Doctor Degree : ");
                                            JLabel lbldss9 = new JLabel("Specializations : ");
                                            JLabel lbldss10 = new JLabel("Fees : ");
                                            JLabel lbldss11 = new JLabel("Joined Date : ");
                                            // JLabel lbldu12 = new JLabel("Id No : ");
                                            JTextField txtdss1 = new JTextField(email);
                                            JPasswordField txtdss4 = new JPasswordField(dpassword);
                                            JTextField txtdss3 = new JTextField(dname);
                                            JTextField txtdss2 = new JTextField(user_name);
                                            JTextField txtdss5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtdss6 = new JComboBox<>(adressarray);

                                            // JTextField txtd7 = new JTextField();
                                            JDateChooser txtdss7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtdss8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtdss9 = new JComboBox<>(dspecialzationarray);

                                            JTextField txtdss10 = new JTextField(dfees);
                                            JDateChooser txtdss11 = new JDateChooser(djoin_date);
                                            txtdss1.setEditable(false);
                                            txtdss2.setEditable(false);
                                            txtdss3.setEditable(false);
                                            txtdss4.setEditable(false);
                                            txtdss5.setEditable(false);
                                            txtdss6.setEditable(false);
                                            // txtdss7.setEnable(false);
                                            txtdss8.setEditable(false);
                                            txtdss9.setEditable(false);
                                            txtdss10.setEditable(false);
                                            // txtdss11.setEnable(false);
                                            // txtdss12.setEditable(false);
                                            // txtdss1.setEditable(false);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btnds1 = new JButton("BACK");

                                            lbldss1.setBounds(20, 10, 200, 35);
                                            lbldss2.setBounds(440, 10, 200, 35);
                                            lbldss3.setBounds(20, 60, 200, 35);
                                            lbldss4.setBounds(440, 60, 200, 35);
                                            lbldss5.setBounds(20, 110, 200, 35);
                                            lbldss6.setBounds(440, 110, 200, 35);
                                            lbldss7.setBounds(20, 160, 200, 35);
                                            lbldss8.setBounds(440, 160, 200, 35);
                                            lbldss9.setBounds(20, 210, 200, 35);
                                            lbldss10.setBounds(440, 210, 200, 35);
                                            lbldss11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtdss1.setBounds(200, 10, 200, 35);
                                            txtdss2.setBounds(680, 10, 200, 35);
                                            txtdss3.setBounds(200, 60, 200, 35);
                                            txtdss4.setBounds(680, 60, 200, 35);
                                            txtdss5.setBounds(200, 110, 200, 35);
                                            txtdss6.setBounds(680, 110, 200, 35);
                                            txtdss7.setBounds(200, 160, 200, 35);
                                            txtdss8.setBounds(680, 160, 200, 35);
                                            txtdss9.setBounds(200, 210, 200, 35);
                                            txtdss10.setBounds(680, 210, 200, 35);
                                            txtdss11.setBounds(200, 260, 200, 35);
                                            // txtdu12.setBounds(680, 260, 120, 35);
                                            btnds1.setBounds(300, 350, 150, 50);
                                            txtdss11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lbldss1.setFont(plainFont2);
                                            lbldss2.setFont(plainFont2);
                                            lbldss3.setFont(plainFont2);
                                            lbldss4.setFont(plainFont2);
                                            lbldss5.setFont(plainFont2);
                                            lbldss6.setFont(plainFont2);
                                            lbldss7.setFont(plainFont2);
                                            lbldss8.setFont(plainFont2);
                                            lbldss9.setFont(plainFont2);
                                            lbldss10.setFont(plainFont2);
                                            lbldss11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btnds1.setFont(plainFont2);

                                            frame10.add(lbldss1);
                                            frame10.add(lbldss2);
                                            frame10.add(lbldss3);
                                            frame10.add(lbldss4);
                                            frame10.add(lbldss5);
                                            frame10.add(lbldss6);
                                            frame10.add(lbldss7);
                                            frame10.add(lbldss8);
                                            frame10.add(lbldss9);
                                            frame10.add(lbldss10);
                                            frame10.add(lbldss11);
                                            // frame6.add(lbldu12);
                                            frame10.add(txtdss1);
                                            frame10.add(txtdss2);
                                            frame10.add(txtdss3);
                                            frame10.add(txtdss4);
                                            frame10.add(txtdss5);
                                            frame10.add(txtdss6);
                                            frame10.add(txtdss7);
                                            frame10.add(txtdss8);
                                            frame10.add(txtdss9);
                                            frame10.add(txtdss10);
                                            frame10.add(txtdss11);
                                            // frame6.add(txtsdu12);

                                            frame10.add(btnds1);
                                            btnds1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee16) {
                                                    frame10.dispose();
                                                }
                                            });

                                            frame10.getContentPane().setBackground(Color.CYAN);

                                            frame10.setBounds(225, 265, 1330, 600);
                                            frame10.setLayout(null);
                                            frame10.setVisible(true);

                                        } else {
                                            // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            }
                        });

                        frame9.getContentPane().setBackground(Color.CYAN);
                        frame9.setBounds(225, 265, 1330, 600);
                        frame9.setLayout(null);
                        frame9.setVisible(true);

                    }
                });
                btn17.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee17) {
                        JFrame frame11 = new JFrame("Doctor Information");

                        try {
                            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS",
                                    "root", "Ankit@817raj#");

                            String query = "SELECT id, name, phoneno, address, degree, specilizations, fees FROM doctordata";
                            Statement statement = connection.createStatement();
                            ResultSet resultSet = statement.executeQuery(query);

                            JPanel panel = new JPanel(new GridLayout(0, 7)); // Adjust the number of columns if needed

                            panel.add(new JLabel("ID"));
                            panel.add(new JLabel("Name"));
                            panel.add(new JLabel("Phone No"));
                            panel.add(new JLabel("Address"));
                            panel.add(new JLabel("Degree"));
                            panel.add(new JLabel("Specializations"));
                            panel.add(new JLabel("Fees"));

                            while (resultSet.next()) {
                                int id = resultSet.getInt("id");
                                String name = resultSet.getString("name");
                                String phoneno = resultSet.getString("phoneno");
                                String address = resultSet.getString("address");
                                String degree = resultSet.getString("degree");
                                String specialization = resultSet.getString("specilizations");
                                String fees = resultSet.getString("fees");

                                panel.add(new JLabel(String.valueOf(id)));
                                panel.add(new JLabel(name));
                                panel.add(new JLabel(phoneno));
                                panel.add(new JLabel(address));
                                panel.add(new JLabel(degree));
                                panel.add(new JLabel(specialization));
                                panel.add(new JLabel(fees));
                            }

                            frame11.add(panel);
                            frame11.getContentPane().setBackground(Color.CYAN);
                            frame11.setSize(1330, 600);
                            frame11.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                            frame11.setVisible(true);

                            connection.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                btn18.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee19) {
                        Admin_manage();
                        frame4.dispose();
                    }
                });
                frame4.setBounds(0, 130, 1540, 900);
                frame4.getContentPane().setBackground(Color.RED);
                frame4.setLayout(null);
                frame4.setVisible(true);

            }
        });

        btn3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee6) {
                frame2.dispose();
                JFrame frame18 = new JFrame("Manage Nurse data");
                JLabel lbl1 = new JLabel("Manage Nurse Data");
                JButton btnn11 = new JButton("ADD NEW");
                JButton btnn12 = new JButton("UPDATE");
                JButton btnn13 = new JButton("DELETE");
                JButton btnn15 = new JButton("");
                JButton btnn16 = new JButton("");
                JButton btnn14 = new JButton("SEARCH");
                JButton btnn17 = new JButton("SHOW");
                JButton btnn18 = new JButton("BACK");

                lbl1.setBounds(0, 0, 1540, 100);
                btnn11.setBounds(10, 110, 200, 40);
                btnn12.setBounds(10, 180, 200, 40);
                btnn13.setBounds(10, 260, 200, 40);
                btnn14.setBounds(10, 340, 200, 40);
                btnn15.setBounds(0, 100, 1540, 5);
                btnn16.setBounds(220, 105, 5, 900);
                btnn17.setBounds(10, 420, 200, 40);
                btnn18.setBounds(10, 500, 200, 40);
                Font plainFont4 = new Font("Jumble", Font.BOLD, 45);
                Border border2 = BorderFactory.createLineBorder(Color.RED, 10);

                lbl1.setBorder(border2);
                lbl1.setHorizontalAlignment(JLabel.CENTER);
                btnn11.setFont(plainFont2);
                btnn12.setFont(plainFont2);
                btnn13.setFont(plainFont2);
                btnn14.setFont(plainFont2);
                btnn17.setFont(plainFont2);
                btnn18.setFont(plainFont2);
                lbl1.setFont(plainFont4);
                btnn16.setBackground(Color.WHITE);
                lbl1.setBackground(Color.PINK);
                frame18.add(lbl1);
                frame18.add(btnn11);
                frame18.add(btnn12);
                frame18.add(btnn13);
                frame18.add(btnn14);
                frame18.add(btnn15);
                frame18.add(btnn16);
                frame18.add(btnn17);
                frame18.add(btnn18);
                btnn11.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee8) {
                        JFrame frame19 = new JFrame("Add doctor data");

                        JLabel lbld1 = new JLabel("Email-ID :  ");
                        JLabel lbld2 = new JLabel("Username : ");
                        JLabel lbld3 = new JLabel("Name : ");
                        JLabel lbld4 = new JLabel("Password: ");
                        JLabel lbld5 = new JLabel("Phone N0 : ");
                        JLabel lbld6 = new JLabel("Address : ");
                        JLabel lbld7 = new JLabel("DOB : ");
                        JLabel lbld8 = new JLabel("Doctor Degree : ");
                        JLabel lbld9 = new JLabel("Specializations : ");
                        JLabel lbld10 = new JLabel("Fees : ");
                        JLabel lbld11 = new JLabel("Joined Date : ");
                        JLabel lbld12 = new JLabel("Id No : ");
                        JTextField txtd1 = new JTextField();
                        JPasswordField txtd4 = new JPasswordField();
                        JTextField txtd3 = new JTextField();
                        JTextField txtd2 = new JTextField();
                        JTextField txtd5 = new JTextField();
                        String[] items = { "Bihar", "Delhi", "Mumbai", "Punjab", "Up" };
                        JComboBox<String> txtd6 = new JComboBox<>(items);
                        // JTextField txtd7 = new JTextField();
                        JDateChooser txtd7 = new JDateChooser();
                        String[] items1 = { "MBBS", "BDS", "BAMS", "BHMS", "BYNS", "BUMS" };
                        JComboBox<String> txtd8 = new JComboBox<>(items1);
                        String[] items2 = { "Family medicine", "Internal medicine", "Dermatology", "Medical genetics",
                                "Emergency Medicine" };
                        JComboBox<String> txtd9 = new JComboBox<>(items2);
                        JTextField txtd10 = new JTextField();
                        JDateChooser txtd11 = new JDateChooser();
                        JTextField txtd12 = new JTextField();
                        // JButton txtd12 = new JButton("Select Image");
                        JButton btnd1 = new JButton("Submit");

                        lbld1.setBounds(20, 10, 200, 35);
                        lbld2.setBounds(440, 10, 200, 35);
                        lbld3.setBounds(20, 60, 200, 35);
                        lbld4.setBounds(440, 60, 200, 35);
                        lbld5.setBounds(20, 110, 200, 35);
                        lbld6.setBounds(440, 110, 200, 35);
                        lbld7.setBounds(20, 160, 200, 35);
                        lbld8.setBounds(440, 160, 200, 35);
                        lbld9.setBounds(20, 210, 200, 35);
                        lbld10.setBounds(440, 210, 200, 35);
                        lbld11.setBounds(20, 260, 200, 35);
                        lbld12.setBounds(440, 260, 200, 35);
                        txtd1.setBounds(200, 10, 200, 35);
                        txtd2.setBounds(680, 10, 200, 35);
                        txtd3.setBounds(200, 60, 200, 35);
                        txtd4.setBounds(680, 60, 200, 35);
                        txtd5.setBounds(200, 110, 200, 35);
                        txtd6.setBounds(680, 110, 200, 35);
                        txtd7.setBounds(200, 160, 200, 35);
                        txtd8.setBounds(680, 160, 200, 35);
                        txtd9.setBounds(200, 210, 200, 35);
                        txtd10.setBounds(680, 210, 200, 35);
                        txtd11.setBounds(200, 260, 200, 35);
                        txtd12.setBounds(680, 260, 120, 35);
                        btnd1.setBounds(300, 350, 150, 50);
                        txtd11.setDateFormatString("yyyy-MM-dd");

                        lbld1.setFont(plainFont2);
                        lbld2.setFont(plainFont2);
                        lbld3.setFont(plainFont2);
                        lbld4.setFont(plainFont2);
                        lbld5.setFont(plainFont2);
                        lbld6.setFont(plainFont2);
                        lbld7.setFont(plainFont2);
                        lbld8.setFont(plainFont2);
                        lbld9.setFont(plainFont2);
                        lbld10.setFont(plainFont2);
                        lbld11.setFont(plainFont2);
                        lbld12.setFont(plainFont2);
                        btnd1.setFont(plainFont2);

                        frame19.add(lbld1);
                        frame19.add(lbld2);
                        frame19.add(lbld3);
                        frame19.add(lbld4);
                        frame19.add(lbld5);
                        frame19.add(lbld6);
                        frame19.add(lbld7);
                        frame19.add(lbld8);
                        frame19.add(lbld9);
                        frame19.add(lbld10);
                        frame19.add(lbld11);
                        frame19.add(lbld12);

                        frame19.add(txtd1);
                        frame19.add(txtd2);
                        frame19.add(txtd3);
                        frame19.add(txtd4);
                        frame19.add(txtd5);
                        frame19.add(txtd6);
                        frame19.add(txtd7);
                        frame19.add(txtd8);
                        frame19.add(txtd9);
                        frame19.add(txtd10);
                        frame19.add(txtd11);
                        frame19.add(txtd12);

                        frame19.add(btnd1);

                        btnd1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee9) {

                                Date dob = txtd11.getDate();
                                Date dob1 = txtd7.getDate();
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                String formattedDob = dateFormat.format(dob);
                                String formattedDob1 = dateFormat.format(dob1);

                                String email_id = txtd1.getText();
                                String username = txtd2.getText();
                                String msg = "" + username;
                                String name = txtd3.getText();
                                String phoneno = txtd5.getText();
                                String password = new String(txtd4.getPassword());
                                String adress = (String) txtd6.getSelectedItem();
                                String degree = (String) txtd8.getSelectedItem();
                                String specializations = (String) txtd9.getSelectedItem();
                                String fees = txtd10.getText();
                                String Idno = txtd12.getText();

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();
                                int len3 = fees.length();
                                int len4 = username.length();
                                int len5 = phoneno.length();
                                int len6 = Idno.length();

                                if (dob == null) {
                                    JOptionPane.showMessageDialog(null, "Please Choose Your joined date",
                                            "Empty fileds", JOptionPane.ERROR_MESSAGE);
                                } else if (dob1 == null) {
                                    JOptionPane.showMessageDialog(null, "Please choose your Dob.", "Empty Fields",
                                            JOptionPane.ERROR_MESSAGE);
                                }

                                else if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0 || len4 == 0 || len6 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else if (len5 != 10) {
                                    JOptionPane.showMessageDialog(null, "Please enter the valid mobile no",
                                            "less than 10", JOptionPane.ERROR_MESSAGE);

                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root",
                                                "Ankit@817raj#");

                                        DatabaseMetaData metaData = connection.getMetaData();
                                        ResultSet tables = metaData.getTables(null, null, "nursedata", null);
                                        boolean tableExists = tables.next();
                                        if (!tableExists) {
                                            Statement statement = connection.createStatement();
                                            statement.executeUpdate(
                                                    "CREATE TABLE Nursedata(id INT AUTO_INCREMENT PRIMARY KEY,email VARCHAR(25) NOT NULL,username VARCHAR(25) NOT NULL, name VARCHAR(50) NOT NULL,password VARCHAR(30) NOT NULL,phoneno VARCHAR(30) NOT NULL,address VARCHAR(50) NOT NULL,dob DATE,degree VARCHAR(50) NOT NULL,specilizations VARCHAR(50) NOT NULL,fees VARCHAR(50) NOT NULL,jdate DATE,idno VARCHAR(10))");
                                        }
                                        String query1 = "INSERT INTO nursedata (email, username, name, password, phoneno, address, dob, degree, specilizations, fees, jdate, idno) VALUES ('"
                                                + email_id + "','" + username + "','" + name + "','" + password + "','"
                                                + phoneno + "','" + adress + "','"
                                                + formattedDob + "','" + degree + "','" + specializations + "','" + fees
                                                + "','" + formattedDob1 + "','"
                                                + Idno + "')";

                                        Statement sta = connection.createStatement();
                                        int x = sta.executeUpdate(query1);

                                        if (x == 0) {
                                            JOptionPane.showMessageDialog(btn1, "This is alredy exist");
                                        } else {
                                            JOptionPane.showMessageDialog(btn1,
                                                    "Congratulations " + msg + "Your Registraions sucessfully....");
                                            txtd1.setText("");
                                            txtd2.setText("");
                                            txtd3.setText("");
                                            txtd4.setText("");
                                            txtd5.setText("");
                                            txtd10.setText("");
                                            txtd12.setText("");
                                            txtd11.setDate(null);

                                        }

                                    } catch (Exception ee3) {
                                        ee3.printStackTrace();
                                    }

                                }

                            }
                        });

                        frame19.getContentPane().setBackground(Color.CYAN);
                        frame19.setBounds(225, 265, 1330, 600);
                        frame19.setLayout(null);
                        frame19.setVisible(true);

                    }
                });
                btnn12.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee8) {
                        JFrame frame11 = new JFrame("Update Doctor data");

                        JLabel lblnu1 = new JLabel("Email-ID :  ");
                        JLabel lblnu2 = new JLabel("Username : ");
                        JLabel lblnu3 = new JLabel("Name : ");
                        JLabel lblnu4 = new JLabel("Password: ");

                        JTextField txtnu1 = new JTextField(40);
                        JPasswordField txtnu4 = new JPasswordField(25);
                        JTextField txtnu3 = new JTextField(35);
                        JTextField txtnu2 = new JTextField(25);

                        JButton btnnu1 = new JButton("Submit");

                        lblnu1.setBounds(20, 10, 200, 35);
                        lblnu2.setBounds(20, 60, 200, 35);
                        lblnu3.setBounds(20, 110, 200, 35);
                        lblnu4.setBounds(20, 160, 200, 35);

                        txtnu1.setBounds(220, 10, 200, 35);
                        txtnu2.setBounds(220, 60, 200, 35);
                        txtnu3.setBounds(220, 110, 200, 35);
                        txtnu4.setBounds(220, 160, 200, 35);
                        btnnu1.setBounds(220, 350, 120, 40);

                        lblnu1.setFont(plainFont2);
                        lblnu2.setFont(plainFont2);
                        lblnu3.setFont(plainFont2);
                        lblnu4.setFont(plainFont2);
                        btnnu1.setFont(plainFont2);

                        frame11.add(lblnu1);
                        frame11.add(lblnu2);
                        frame11.add(lblnu3);
                        frame11.add(lblnu4);

                        frame11.add(txtnu1);
                        frame11.add(txtnu2);
                        frame11.add(txtnu3);
                        frame11.add(txtnu4);

                        frame11.add(btnnu1);

                        btnnu1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee9) {

                                String email_id = txtnu1.getText();
                                String username = txtnu2.getText();
                                String msg = "" + username;
                                String name = txtnu3.getText();

                                String password = new String(txtnu4.getPassword());

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();

                                int len4 = username.length();
                                if (len == 0 || len1 == 0 || len2 == 0 || len4 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM nursedata WHERE email = ? AND name = ? AND username = ? AND password = ?";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        fetchStatement.setString(1, email_id);
                                        fetchStatement.setString(2, name);
                                        fetchStatement.setString(3, username);
                                        fetchStatement.setString(4, password);

                                        ResultSet resultSet = fetchStatement.executeQuery();

                                        if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame frame12 = new JFrame("Update Doctor data");

                                            JLabel lblnu1 = new JLabel("Email-ID :  ");
                                            JLabel lblnu2 = new JLabel("Username : ");
                                            JLabel lblnu3 = new JLabel("Name : ");
                                            JLabel lblnu4 = new JLabel("Password: ");
                                            JLabel lblnu5 = new JLabel("Phone N0 : ");
                                            JLabel lblnu6 = new JLabel("Address : ");
                                            JLabel lblnu7 = new JLabel("DOB : ");
                                            JLabel lblnu8 = new JLabel("Doctor Degree : ");
                                            JLabel lblnu9 = new JLabel("Specializations : ");
                                            JLabel lblnu10 = new JLabel("Fees : ");
                                            JLabel lblnu11 = new JLabel("Joined Date : ");
                                            // JLabel lbldu12 = new JLabel("Id No : ");
                                            JTextField txtnu1 = new JTextField(email);
                                            JPasswordField txtnu4 = new JPasswordField(dpassword);
                                            JTextField txtnu3 = new JTextField(dname);
                                            JTextField txtnu2 = new JTextField(user_name);
                                            JTextField txtnu5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtnu6 = new JComboBox<>(adressarray);

                                            // JTextField txtd7 = new JTextField();
                                            JDateChooser txtnu7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtnu8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtnu9 = new JComboBox<>(dspecialzationarray);

                                            JTextField txtnu10 = new JTextField(dfees);
                                            JDateChooser txtnu11 = new JDateChooser(djoin_date);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btnnu1 = new JButton("Submit");

                                            lblnu1.setBounds(20, 10, 200, 35);
                                            lblnu2.setBounds(440, 10, 200, 35);
                                            lblnu3.setBounds(20, 60, 200, 35);
                                            lblnu4.setBounds(440, 60, 200, 35);
                                            lblnu5.setBounds(20, 110, 200, 35);
                                            lblnu6.setBounds(440, 110, 200, 35);
                                            lblnu7.setBounds(20, 160, 200, 35);
                                            lblnu8.setBounds(440, 160, 200, 35);
                                            lblnu9.setBounds(20, 210, 200, 35);
                                            lblnu10.setBounds(440, 210, 200, 35);
                                            lblnu11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtnu1.setBounds(200, 10, 200, 35);
                                            txtnu2.setBounds(680, 10, 200, 35);
                                            txtnu3.setBounds(200, 60, 200, 35);
                                            txtnu4.setBounds(680, 60, 200, 35);
                                            txtnu5.setBounds(200, 110, 200, 35);
                                            txtnu6.setBounds(680, 110, 200, 35);
                                            txtnu7.setBounds(200, 160, 200, 35);
                                            txtnu8.setBounds(680, 160, 200, 35);
                                            txtnu9.setBounds(200, 210, 200, 35);
                                            txtnu10.setBounds(680, 210, 200, 35);
                                            txtnu11.setBounds(200, 260, 200, 35);
                                            // txtdu12.setBounds(680, 260, 120, 35);
                                            btnnu1.setBounds(300, 350, 150, 50);
                                            txtnu11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lblnu1.setFont(plainFont2);
                                            lblnu2.setFont(plainFont2);
                                            lblnu3.setFont(plainFont2);
                                            lblnu4.setFont(plainFont2);
                                            lblnu5.setFont(plainFont2);
                                            lblnu6.setFont(plainFont2);
                                            lblnu7.setFont(plainFont2);
                                            lblnu8.setFont(plainFont2);
                                            lblnu9.setFont(plainFont2);
                                            lblnu10.setFont(plainFont2);
                                            lblnu11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btnnu1.setFont(plainFont2);

                                            frame12.add(lblnu1);
                                            frame12.add(lblnu2);
                                            frame12.add(lblnu3);
                                            frame12.add(lblnu4);
                                            frame12.add(lblnu5);
                                            frame12.add(lblnu6);
                                            frame12.add(lblnu7);
                                            frame12.add(lblnu8);
                                            frame12.add(lblnu9);
                                            frame12.add(lblnu10);
                                            frame12.add(lblnu11);
                                            // frame6.add(nbldu12);
                                            frame12.add(txtnu1);
                                            frame12.add(txtnu2);
                                            frame12.add(txtnu3);
                                            frame12.add(txtnu4);
                                            frame12.add(txtnu5);
                                            frame12.add(txtnu6);
                                            frame12.add(txtnu7);
                                            frame12.add(txtnu8);
                                            frame12.add(txtnu9);
                                            frame12.add(txtnu10);
                                            frame12.add(txtnu11);
                                            // frame6.add(txtdu12);

                                            frame12.add(btnnu1);
                                            btnnu1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee13) {
                                                    Date newdob = txtnu11.getDate();
                                                    String newDobDate = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob);
                                                    Date newdob1 = txtnu7.getDate();
                                                    String newDob1Date = new SimpleDateFormat("yyyy-MM-dd")
                                                            .format(newdob1);

                                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                                                    String formattedDob = dateFormat.format(newdob);
                                                    String formattedDob1 = dateFormat.format(newdob1);

                                                    String newemail_id = txtnu1.getText();
                                                    String newusername = txtnu2.getText();
                                                    String msg = "" + username;
                                                    String newname = txtnu3.getText();
                                                    String newphoneno = txtnu5.getText();
                                                    String newpassword = new String(txtnu4.getPassword());
                                                    String newaddress = (String) txtnu6.getSelectedItem();
                                                    String newdegree = (String) txtnu8.getSelectedItem();
                                                    String newspecializations = (String) txtnu9.getSelectedItem();
                                                    String newfees = txtnu10.getText();
                                                    // String Idno = txtdu12.getText();

                                                    String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                                    int len = newemail_id.length();
                                                    int len1 = newname.length();
                                                    int len2 = newpassword.length();
                                                    int len3 = newfees.length();
                                                    int len4 = newusername.length();
                                                    int len5 = newphoneno.length();
                                                    // int len6 = Idno.length();
                                                    if (newdob == null) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please Choose Your joined date",
                                                                "Empty fileds", JOptionPane.ERROR_MESSAGE);
                                                    } else if (newdob1 == null) {
                                                        JOptionPane.showMessageDialog(null, "Please choose your Dob.",
                                                                "Empty Fields",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    }

                                                    else if (len == 0 || len1 == 0 || len2 == 0 || len3 == 0
                                                            || len4 == 0) {
                                                        JOptionPane.showMessageDialog(null, "Every Filed is required",
                                                                "Empty fileds",
                                                                JOptionPane.ERROR_MESSAGE);

                                                    } else if (!Pattern.matches(emailPattern, newemail_id)) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Invalid email address. Please enter a valid email.",
                                                                "Validation Result",
                                                                JOptionPane.ERROR_MESSAGE);
                                                    } else if (len5 != 10) {
                                                        JOptionPane.showMessageDialog(null,
                                                                "Please enter the valid mobile no",
                                                                "less than 10", JOptionPane.ERROR_MESSAGE);

                                                    } else {
                                                        try {
                                                            Connection connection = DriverManager.getConnection(
                                                                    "jdbc:mysql://localhost:3306/CMS", "root",
                                                                    "Ankit@817raj#");

                                                            String updateQuery = "UPDATE nursedata SET email = ?, username = ?, name = ?, password = ?, phoneno = ?, address = ?, dob = ?, degree = ?, specilizations = ?, fees = ?, jdate = ? WHERE username = ?";

                                                            PreparedStatement updateStatement = connection
                                                                    .prepareStatement(updateQuery);
                                                            // updateStatement.setString(1, username);
                                                            updateStatement.setString(1, newemail_id);
                                                            updateStatement.setString(2, newusername);
                                                            updateStatement.setString(3, newname);
                                                            updateStatement.setString(4, newpassword);
                                                            updateStatement.setString(5, newphoneno);
                                                            updateStatement.setString(6, newaddress);
                                                            updateStatement.setString(7, newDobDate);
                                                            updateStatement.setString(8, newdegree);
                                                            updateStatement.setString(9, newspecializations);
                                                            updateStatement.setString(10, newfees);
                                                            updateStatement.setString(11, newDob1Date);
                                                            // updateStatement.setString(12, newIdNo);
                                                            updateStatement.setString(12, username);

                                                            int rowsAffected = updateStatement.executeUpdate();

                                                            if (rowsAffected > 0) {
                                                                JOptionPane.showMessageDialog(null,
                                                                        "Update successfully",
                                                                        "Update data", JOptionPane.ERROR_MESSAGE);
                                                                frame11.dispose();
                                                            } else {

                                                            }

                                                        } catch (Exception ee3) {
                                                            ee3.printStackTrace();
                                                        }

                                                    }

                                                }
                                            });

                                            frame12.getContentPane().setBackground(Color.CYAN);

                                            frame12.setBounds(225, 265, 1330, 600);
                                            frame12.setLayout(null);
                                            frame12.setVisible(true);

                                        } else {
                                            // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            }
                        });

                        frame11.getContentPane().setBackground(Color.CYAN);
                        frame11.setBounds(225, 265, 1330, 600);
                        frame11.setLayout(null);
                        frame11.setVisible(true);

                    }
                });
                btnn13.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee13) {
                        JFrame frame13 = new JFrame("delete Doctor data");

                        JLabel lblnd1 = new JLabel("Email-ID :  ");
                        JLabel lblnd2 = new JLabel("Username : ");
                        JLabel lblnd3 = new JLabel("Name : ");
                        JLabel lblnd4 = new JLabel("Password: ");

                        JTextField txtnd1 = new JTextField(40);
                        JPasswordField txtnd4 = new JPasswordField(25);
                        JTextField txtnd3 = new JTextField(35);
                        JTextField txtnd2 = new JTextField(25);

                        JButton btnnd1 = new JButton("Submit");

                        lblnd1.setBounds(20, 10, 200, 35);
                        lblnd2.setBounds(20, 60, 200, 35);
                        lblnd3.setBounds(20, 110, 200, 35);
                        lblnd4.setBounds(20, 160, 200, 35);

                        txtnd1.setBounds(220, 10, 200, 35);
                        txtnd2.setBounds(220, 60, 200, 35);
                        txtnd3.setBounds(220, 110, 200, 35);
                        txtnd4.setBounds(220, 160, 200, 35);
                        btnnd1.setBounds(220, 350, 120, 40);

                        lblnd1.setFont(plainFont2);
                        lblnd2.setFont(plainFont2);
                        lblnd3.setFont(plainFont2);
                        lblnd4.setFont(plainFont2);

                        btnnd1.setFont(plainFont2);

                        frame13.add(lblnd1);
                        frame13.add(lblnd2);
                        frame13.add(lblnd3);
                        frame13.add(lblnd4);

                        frame13.add(txtnd1);
                        frame13.add(txtnd2);
                        frame13.add(txtnd3);
                        frame13.add(txtnd4);

                        frame13.add(btnnd1);
                        btnnd1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee13) {
                                String email_id = txtnd1.getText();
                                String username = txtnd2.getText();
                                String msg = "" + username;
                                String name = txtnd3.getText();

                                String password = new String(txtnd4.getPassword());

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();

                                int len4 = username.length();
                                if (len == 0 || len1 == 0 || len2 == 0 || len4 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        // The username you want to delete
                                        String fetchQuery = "SELECT * FROM nursedata WHERE email = ? AND name = ? AND username = ? AND password = ?";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        fetchStatement.setString(1, email_id);
                                        fetchStatement.setString(2, name);
                                        fetchStatement.setString(3, username);
                                        fetchStatement.setString(4, password);

                                        int rowsAffected = fetchStatement.executeUpdate();
                                        if (rowsAffected > 0) {

                                            String deleteQuery = "DELETE FROM nursedata WHERE username = ?";
                                            PreparedStatement deleteStatement = connection
                                                    .prepareStatement(deleteQuery);
                                            deleteStatement.setString(1, username);

                                            int rowsAffected1 = deleteStatement.executeUpdate();

                                            if (rowsAffected1 > 0) {
                                                JOptionPane.showMessageDialog(null, "Record deleted successfully.",
                                                        "Success", JOptionPane.INFORMATION_MESSAGE);
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Invalid .", "Invalid",
                                                        JOptionPane.ERROR_MESSAGE);
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Invalid username.", "Invalid",
                                                    JOptionPane.ERROR_MESSAGE);

                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            }

                        });
                        frame13.getContentPane().setBackground(Color.CYAN);
                        frame13.setBounds(225, 265, 1330, 600);
                        frame13.setLayout(null);
                        frame13.setVisible(true);

                    }
                });

                btnn14.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee15) {
                        JFrame frame14 = new JFrame("Search nurse data");

                        JLabel lblns1 = new JLabel("Email-ID :  ");
                        JLabel lblns2 = new JLabel("Username : ");
                        JLabel lblns3 = new JLabel("Name : ");
                        JLabel lblns4 = new JLabel("Password: ");

                        JTextField txtns1 = new JTextField(40);
                        JPasswordField txtns4 = new JPasswordField(25);
                        JTextField txtns3 = new JTextField(35);
                        JTextField txtns2 = new JTextField(25);

                        JButton btnns1 = new JButton("Submit");

                        lblns1.setBounds(20, 10, 200, 35);
                        lblns2.setBounds(20, 60, 200, 35);
                        lblns3.setBounds(20, 110, 200, 35);
                        lblns4.setBounds(20, 160, 200, 35);

                        txtns1.setBounds(220, 10, 200, 35);
                        txtns2.setBounds(220, 60, 200, 35);
                        txtns3.setBounds(220, 110, 200, 35);
                        txtns4.setBounds(220, 160, 200, 35);
                        btnns1.setBounds(220, 350, 120, 40);

                        lblns1.setFont(plainFont2);
                        lblns2.setFont(plainFont2);
                        lblns3.setFont(plainFont2);
                        lblns4.setFont(plainFont2);

                        btnns1.setFont(plainFont2);

                        frame14.add(lblns1);
                        frame14.add(lblns2);
                        frame14.add(lblns3);
                        frame14.add(lblns4);

                        frame14.add(txtns1);
                        frame14.add(txtns2);
                        frame14.add(txtns3);
                        frame14.add(txtns4);

                        frame14.add(btnns1);

                        btnns1.addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent ee9) {

                                String email_id = txtns1.getText();
                                String username = txtns2.getText();
                                String msg = "" + username;
                                String name = txtns3.getText();

                                String password = new String(txtns4.getPassword());

                                String emailPattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                                int len = email_id.length();
                                int len1 = name.length();
                                int len2 = password.length();

                                int len4 = username.length();
                                if (len == 0 || len1 == 0 || len2 == 0 || len4 == 0) {
                                    JOptionPane.showMessageDialog(null, "Every Filed is required", "Empty fileds",
                                            JOptionPane.ERROR_MESSAGE);

                                } else if (!Pattern.matches(emailPattern, email_id)) {
                                    JOptionPane.showMessageDialog(null,
                                            "Invalid email address. Please enter a valid email.", "Validation Result",
                                            JOptionPane.ERROR_MESSAGE);
                                } else {
                                    try {
                                        Connection connection = DriverManager.getConnection(
                                                "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");

                                        String fetchQuery = "SELECT * FROM nursedata WHERE email = ? AND name = ? AND username = ? AND password = ?";
                                        PreparedStatement fetchStatement = connection.prepareStatement(fetchQuery);
                                        fetchStatement.setString(1, email_id);
                                        fetchStatement.setString(2, name);
                                        fetchStatement.setString(3, username);
                                        fetchStatement.setString(4, password);

                                        ResultSet resultSet = fetchStatement.executeQuery();                                      if (resultSet.next()) {
                                            List<String> addressList = new ArrayList<>();
                                            List<String> ddegreeList = new ArrayList<>();
                                            List<String> dspecializationsList = new ArrayList<>();
                                            String email = resultSet.getString("email");
                                            String user_name = resultSet.getString("username");
                                            String dname = resultSet.getString("name");
                                            String dpassword = resultSet.getString("password");
                                            String phone_no = resultSet.getString("phoneno");

                                            String daddress = resultSet.getString("address");
                                            addressList.add(daddress);
                                            Date d_o_b = resultSet.getDate("dob");
                                            String ddegree = resultSet.getString("degree");
                                            ddegreeList.add(ddegree);
                                            String specialization = resultSet.getString("specilizations");
                                            dspecializationsList.add(specialization);
                                            String dfees = resultSet.getString("fees");
                                            Date djoin_date = resultSet.getDate("jDate");

                                            JFrame frame15 = new JFrame("Search nurse data");

                                            JLabel lblnss1 = new JLabel("Email-ID :  ");
                                            JLabel lblnss2 = new JLabel("Username : ");
                                            JLabel lblnss3 = new JLabel("Name : ");
                                            JLabel lblnss4 = new JLabel("Password: ");
                                            JLabel lblnss5 = new JLabel("Phone N0 : ");
                                            JLabel lblnss6 = new JLabel("Address : ");
                                            JLabel lblnss7 = new JLabel("DOB : ");
                                            JLabel lblnss8 = new JLabel("Doctor Degree : ");
                                            JLabel lblnss9 = new JLabel("Specializations : ");
                                            JLabel lblnss10 = new JLabel("Fees : ");
                                            JLabel lblnss11 = new JLabel("Joined Date : ");
                                            // JLabel lbldu12 = new JLabel("Id No : ");
                                            JTextField txtnss1 = new JTextField(email);
                                            JPasswordField txtnss4 = new JPasswordField(dpassword);
                                            JTextField txtnss3 = new JTextField(dname);
                                            JTextField txtnss2 = new JTextField(user_name);
                                            JTextField txtnss5 = new JTextField(phone_no);
                                            String[] adressarray = addressList.toArray(new String[0]);
                                            JComboBox<String> txtnss6 = new JComboBox<>(adressarray);

                                            // JTextField txtd7 = new JTextField();
                                            JDateChooser txtnss7 = new JDateChooser(d_o_b);
                                            String[] degreearray = ddegreeList.toArray(new String[0]);
                                            JComboBox<String> txtnss8 = new JComboBox<>(degreearray);
                                            String[] dspecialzationarray = dspecializationsList.toArray(new String[0]);
                                            JComboBox<String> txtnss9 = new JComboBox<>(dspecialzationarray);

                                            JTextField txtnss10 = new JTextField(dfees);
                                            JDateChooser txtnss11 = new JDateChooser(djoin_date);
                                            txtnss1.setEditable(false);
                                            txtnss2.setEditable(false);
                                            txtnss3.setEditable(false);
                                            txtnss4.setEditable(false);
                                            txtnss5.setEditable(false);
                                            txtnss6.setEditable(false);
                                            // txtdss7.setEnable(false);
                                            txtnss8.setEditable(false);
                                            txtnss9.setEditable(false);
                                            txtnss10.setEditable(false);
                                            // txtdss11.setEnable(false);
                                            // txtdss12.setEditable(false);
                                            // txtdss1.setEditable(false);
                                            // JTextField txtdu12 = new JTextField();
                                            JButton btnds1 = new JButton("BACK");

                                            lblnss1.setBounds(20, 10, 200, 35);
                                            lblnss2.setBounds(440, 10, 200, 35);
                                            lblnss3.setBounds(20, 60, 200, 35);
                                            lblnss4.setBounds(440, 60, 200, 35);
                                            lblnss5.setBounds(20, 110, 200, 35);
                                            lblnss6.setBounds(440, 110, 200, 35);
                                            lblnss7.setBounds(20, 160, 200, 35);
                                            lblnss8.setBounds(440, 160, 200, 35);
                                            lblnss9.setBounds(20, 210, 200, 35);
                                            lblnss10.setBounds(440, 210, 200, 35);
                                            lblnss11.setBounds(20, 260, 200, 35);
                                            // lbldu12.setBounds(440, 260, 200, 35);
                                            txtnss1.setBounds(200, 10, 200, 35);
                                            txtnss2.setBounds(680, 10, 200, 35);
                                            txtnss3.setBounds(200, 60, 200, 35);
                                            txtnss4.setBounds(680, 60, 200, 35);
                                            txtnss5.setBounds(200, 110, 200, 35);
                                            txtnss6.setBounds(680, 110, 200, 35);
                                            txtnss7.setBounds(200, 160, 200, 35);
                                            txtnss8.setBounds(680, 160, 200, 35);
                                            txtnss9.setBounds(200, 210, 200, 35);
                                            txtnss10.setBounds(680, 210, 200, 35);
                                            txtnss11.setBounds(200, 260, 200, 35);
                                            // txtdu12.setBounds(680, 260, 120, 35);
                                            btnns1.setBounds(300, 350, 150, 50);
                                            txtnss11.setDateFormatString("yyyy-MM-dd");
                                            Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
                                            Border border2 = BorderFactory.createLineBorder(Color.RED, 6);
                                            Border border3 = BorderFactory.createLineBorder(Color.GREEN, 0);
                                            Font plainFont1 = new Font("Jumble", Font.BOLD, 15);
                                            Font plainFont2 = new Font("Jumble", Font.BOLD, 20);
                                            Font plainFont3 = new Font("Jumble", Font.BOLD, 30);

                                            lblnss1.setFont(plainFont2);
                                            lblnss2.setFont(plainFont2);
                                            lblnss3.setFont(plainFont2);
                                            lblnss4.setFont(plainFont2);
                                            lblnss5.setFont(plainFont2);
                                            lblnss6.setFont(plainFont2);
                                            lblnss7.setFont(plainFont2);
                                            lblnss8.setFont(plainFont2);
                                            lblnss9.setFont(plainFont2);
                                            lblnss10.setFont(plainFont2);
                                            lblnss11.setFont(plainFont2);
                                            // lbldu12.setFont(plainFont2);
                                            btnns1.setFont(plainFont2);

                                            frame15.add(lblnss1);
                                            frame15.add(lblnss2);
                                            frame15.add(lblnss3);
                                            frame15.add(lblnss4);
                                            frame15.add(lblnss5);
                                            frame15.add(lblnss6);
                                            frame15.add(lblnss7);
                                            frame15.add(lblnss8);
                                            frame15.add(lblnss9);
                                            frame15.add(lblnss10);
                                            frame15.add(lblnss11);
                                            // frame6.add(lbldu12);
                                            frame15.add(txtnss1);
                                            frame15.add(txtnss2);
                                            frame15.add(txtnss3);
                                            frame15.add(txtnss4);
                                            frame15.add(txtnss5);
                                            frame15.add(txtnss6);
                                            frame15.add(txtnss7);
                                            frame15.add(txtnss8);
                                            frame15.add(txtnss9);
                                            frame15.add(txtnss10);
                                            frame15.add(txtnss11);
                                            // frame6.add(txtsdu12);

                                            frame15.add(btnds1);
                                            btnds1.addActionListener(new ActionListener() {
                                                public void actionPerformed(ActionEvent ee16) {
                                                    frame15.dispose();
                                                }
                                            });

                                            frame15.getContentPane().setBackground(Color.CYAN);

                                            frame15.setBounds(225, 265, 1330, 600);
                                            frame15.setLayout(null);
                                            frame15.setVisible(true);

                                        } else {
                                            // User does not exist, proceed with registration
                                            JOptionPane.showMessageDialog(null,
                                                    "Invalid email,username,password,name exist..", "invalid user",
                                                    JOptionPane.ERROR_MESSAGE);
                                        }

                                        connection.close();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                }

                            }
                        });

                        frame14.getContentPane().setBackground(Color.CYAN);
                        frame14.setBounds(225, 265, 1330, 600);
                        frame14.setLayout(null);
                        frame14.setVisible(true);

                    }
                });

                btnn17.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee17) {
                        JFrame frame17 = new JFrame("Nurse Information");

                        try {
                            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS",
                                    "root", "Ankit@817raj#");

                            String query = "SELECT id, name, phoneno, address, degree, specilizations, fees FROM nursedata";
                            Statement statement = connection.createStatement();
                            ResultSet resultSet = statement.executeQuery(query);

                            JPanel panel = new JPanel(new GridLayout(0, 7)); // Adjust the number of columns if needed

                            panel.add(new JLabel("ID"));
                            panel.add(new JLabel("Name"));
                            panel.add(new JLabel("Phone No"));
                            panel.add(new JLabel("Address"));
                            panel.add(new JLabel("Degree"));
                            panel.add(new JLabel("Specializations"));
                            panel.add(new JLabel("Fees"));

                            while (resultSet.next()) {
                                int id = resultSet.getInt("id");
                                String name = resultSet.getString("name");
                                String phoneno = resultSet.getString("phoneno");
                                String address = resultSet.getString("address");
                                String degree = resultSet.getString("degree");
                                String specialization = resultSet.getString("specilizations");
                                String fees = resultSet.getString("fees");

                                panel.add(new JLabel(String.valueOf(id)));
                                panel.add(new JLabel(name));
                                panel.add(new JLabel(phoneno));
                                panel.add(new JLabel(address));
                                panel.add(new JLabel(degree));
                                panel.add(new JLabel(specialization));
                                panel.add(new JLabel(fees));
                            }

                            frame17.add(panel);
                            frame17.getContentPane().setBackground(Color.CYAN);
                            frame17.setBounds(225, 265, 1330, 600);
                            frame17.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                            frame17.setVisible(true);

                            connection.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

                btnn18.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ee19) {
                        frame18.dispose();
                    }
                });

                frame18.setBounds(0, 130, 1540, 900);
                frame18.getContentPane().setBackground(Color.RED);
                frame18.setLayout(null);
                frame18.setVisible(true);

            }
        });
        btn4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee21) {
                JFrame pdframe = new JFrame("Patient Data");
                JTable table = new JTable();
                DefaultTableModel model = new DefaultTableModel() {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false;
                    }
                };
        
                model.addColumn("ID");
                model.addColumn("Name");
                model.addColumn("Father/Mother Name");
                model.addColumn("Age");
                model.addColumn("Date");
                model.addColumn("Gender");
                model.addColumn("Occupation");
                model.addColumn("Marital Status");
                model.addColumn("Contact No");
                model.addColumn("Address");
        
                try {
                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CMS", "root",
                            "Ankit@817raj#");
                    Statement statement = connection.createStatement();
        
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    String todayDate = dateFormat.format(new Date());
        
                    ResultSet resultSet = statement.executeQuery("SELECT * FROM patient_info WHERE DATE_FORMAT(dob, '%Y-%m-%d') = '" + todayDate + "'");
        
                    while (resultSet.next()) {
                        model.addRow(new Object[] {
                                resultSet.getInt("id"),
                                resultSet.getString("name"),
                                resultSet.getString("fname"),
                                resultSet.getString("age"),
                                resultSet.getString("dob"),
                                resultSet.getString("gender"),
                                resultSet.getString("occupation"),
                                resultSet.getString("marital_status"),
                                resultSet.getString("contact_no"),
                                resultSet.getString("address")
                        });
                    }
                    connection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
        
                table.setModel(model);
        
                JTableHeader header = table.getTableHeader();
                header.setFont(new Font("Jumble", Font.BOLD, 18));
                header.setForeground(Color.RED);
        
                TableCellRenderer renderer = table.getDefaultRenderer(Object.class);
                table.setDefaultRenderer(Object.class,
                        (JTable table1, Object value, boolean isSelected, boolean hasFocus, int row, int column) -> {
                            Component component = renderer.getTableCellRendererComponent(table1, value, isSelected,
                                    hasFocus, row, column);
                            component.setFont(new Font("Jumble", Font.BOLD, 14));
                            component.setForeground(Color.BLUE);
                            return component;
                        });
        
                JScrollPane scrollPane = new JScrollPane(table);
                pdframe.add(scrollPane);
                pdframe.getContentPane().setBackground(Color.decode("#29bf86"));
                pdframe.setBounds(220, 250, 1310, 590);
                pdframe.setVisible(true);
            }
        });
        btn7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee33){
                JOptionPane.showConfirmDialog(null, "Do you want to exit!!","Confirm", JOptionPane.YES_NO_CANCEL_OPTION);
                frame2.dispose();

            }
        });
        btn8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ee33){
                JOptionPane.showConfirmDialog(null, "Do you want to Logout!!","Logout", JOptionPane.YES_NO_CANCEL_OPTION);
                frame2.dispose();

            }
        });
        

        frame2.add(btn1);
        frame2.add(btn2);
        frame2.add(btn3);
        frame2.add(btn4);
        frame2.add(btn5);
        frame2.add(btn6);
        frame2.add(btn7);
        frame2.add(btn8);
        frame2.add(btn1);

        frame2.add(btn15);

        frame2.getContentPane().setBackground(Color.RED);
        frame2.setBounds(0, 130, 1540, 900);
        frame2.setLayout(null);
        frame2.setVisible(true);

    }
    public void Report(){
        JFrame detailFrame = new JFrame("Patient Details");
                                        detailFrame.setBounds(100, 220, 1320, 790);
                                        detailFrame.getContentPane().setBackground(Color.decode("#ffffff"));
                                        detailFrame.setLayout(null);
    
                                        // Create input components
                                        JLabel lblId = new JLabel("Enter Your IdNo.:");
                                        JTextField txtId = new JTextField();
                                        JButton btnFetch = new JButton("OK");
    
                                        lblId.setBounds(250, 5, 250, 30);
                                        txtId.setBounds(550, 5, 160, 30);
                                        lblId.setForeground(Color.WHITE);
                                        txtId.setForeground(Color.BLUE);
                                        btnFetch.setForeground(Color.RED);
    
                                        btnFetch.setBounds(800, 5, 100, 30);
                                        // btnframe.getContentPane().setBackground(Color.decode("#29bf86"));
    
                                        // Define labels for displaying patient details
                                        JLabel notelbl1=new JLabel("Note 1: You must be meet after one week.");
                                        JLabel notelbl2=new JLabel("Note 2: All the best, get well soon..");
                                        
                                        JLabel lblPatientId = new JLabel("Patient ID:");
                                        JLabel lblPatientName = new JLabel("Patient Name:");
                                        JLabel lblFmName = new JLabel("Father/Mother Name:");
                                        JLabel lblAge = new JLabel("Age:");
                                        JLabel lbldate = new JLabel("Date:");
                                        JLabel lblgender = new JLabel("Gender:");
                                        JLabel Occupation = new JLabel("Occupation");
                                        JLabel Status = new JLabel("Satus:");
                                        JLabel contactNo = new JLabel("Contact No");
                                        JLabel Address = new JLabel("Address:");
                                        JLabel Issue = new JLabel("Issue");
                                        JLabel OIssue = new JLabel("Other issue");
                                        JLabel Medicine = new JLabel("Medicine Name :");
                                        JLabel RegNo = new JLabel("Reg. No:");
                                        // String dname = resultSet.getString("name");
                                        JLabel dnlbl1 = new JLabel("Doctor Name: ");
    
                                        // Add more labels for other details...
    
                                        // Set bounds for the detail labels
                                        notelbl1.setBounds(20,440,1000,20);
                                        notelbl2.setBounds(20,480,1000,20);
                                        
                                        RegNo.setBounds(20, 20, 120, 30);
                                        lblPatientId.setBounds(20, 70, 300, 30);
                                        lblPatientName.setBounds(20, 120, 300, 30);
                                        lblFmName.setBounds(20, 170, 300, 30);
                                        lblAge.setBounds(20, 220, 300, 30);
                                        lbldate.setBounds(20, 270, 300, 30);
                                        lbldate.setBounds(20, 320, 300, 30);
                                        lblgender.setBounds(550, 70, 300, 30);
                                        Occupation.setBounds(550, 120, 300, 30);
                                        Status.setBounds(550, 170, 300, 30);
                                        contactNo.setBounds(550, 220, 300, 30);
                                        Address.setBounds(550, 270, 300, 30);
                                        Issue.setBounds(550, 320, 300, 30);
                                        OIssue.setBounds(20, 370, 300, 20);
                                        Medicine.setBounds(550, 370, 300, 30);
                                        dnlbl1.setBounds(800, 70, 250, 30);
                                        
                                        // RegNo.setBounds(20,);
    
                                        // Set bounds for other detail labels...
    
                                        // Add detail labels to the detailFrame
                                        detailFrame.add(lblPatientId);
                                        detailFrame.add(lblPatientName);
                                        detailFrame.add(lblFmName);
                                        detailFrame.add(lblAge);
                                        detailFrame.add(lbldate);
                                        detailFrame.add(lblgender);
                                        detailFrame.add(Occupation);
                                        detailFrame.add(Status);
                                        detailFrame.add(contactNo);
                                        detailFrame.add(Address);
                                        detailFrame.add(Issue);
                                        detailFrame.add(OIssue);
                                        detailFrame.add(Medicine);
                                        detailFrame.add(RegNo);
                                        detailFrame.add(notelbl1);
                                        detailFrame.add(notelbl2);
                                        // detailFrame.add(lbldate);
                                        // detailFrame.add(lbldate);
    
                                        // Add other detail labels...
                                        Font jumbleFont = new Font("Jumble", Font.BOLD, 18);
    
                                        lblPatientId.setFont(jumbleFont);
                                        lblPatientName.setFont(jumbleFont);
                                        lblFmName.setFont(jumbleFont);
                                        lblAge.setFont(jumbleFont);
                                        lbldate.setFont(jumbleFont);
                                        lblgender.setFont(jumbleFont);
                                        Occupation.setFont(jumbleFont);
                                        Status.setFont(jumbleFont);
                                        contactNo.setFont(jumbleFont);
                                        Address.setFont(jumbleFont);
                                        Issue.setFont(jumbleFont);
                                        OIssue.setFont(jumbleFont);
                                        Medicine.setFont(jumbleFont);
                                        RegNo.setFont(jumbleFont);
                                        lblId.setFont(jumbleFont);
                                        txtId.setFont(jumbleFont);
                                        btnFetch.setFont(jumbleFont);
                                        notelbl1.setFont(jumbleFont);
                                         notelbl2.setFont(jumbleFont);
    
                                        // Set visibility of detail labels to false initially
                                        lblPatientId.setVisible(false);
                                        lblPatientName.setVisible(false);
                                        lblFmName.setVisible(false);
                                        lblAge.setVisible(false);
                                        lblgender.setVisible(false);
                                        Occupation.setVisible(false);
                                        Issue.setVisible(false);
                                        OIssue.setVisible(false);
                                        Status.setVisible(false);
                                        contactNo.setVisible(false);
                                        Address.setVisible(false);
                                        Medicine.setVisible(false);
                                        lbldate.setVisible(false);
                                        RegNo.setVisible(false);
                                        dnlbl1.setVisible(false);
                                        notelbl1.setVisible(false);
                                        notelbl2.setVisible(false);
                                       
    
                                        // Set visibility for other detail labels...
    
                                        // Add components to the detailFrame
                                        detailFrame.add(lblId);
                                        detailFrame.add(txtId);
                                        detailFrame.add(btnFetch);
                                  
                                        btnFetch.addActionListener(new ActionListener() {
                                            public void actionPerformed(ActionEvent ee28) {
                                                try {
                                                    Connection connection = DriverManager.getConnection(
                                                            "jdbc:mysql://localhost:3306/CMS", "root", "Ankit@817raj#");
    
                                                    String pid = txtId.getText();
                                                    String updateQuery = "SELECT * FROM patient_detail WHERE patient_id = ?";
                                                    PreparedStatement updateStatement = connection
                                                            .prepareStatement(updateQuery);
                                                    updateStatement.setString(1, pid);
    
                                                    ResultSet resultSet = updateStatement.executeQuery();
    
                                                    if (resultSet.next()) {
                                                        // Fetch patient details from the result set
                                                        int patient_id = resultSet.getInt("patient_id");
                                                        String patient_name = resultSet.getString("patient_name");
                                                        String fm_name = resultSet.getString("f_m_name");
                                                        int age = resultSet.getInt("age");
                                                        Date date = resultSet.getDate("date");
                                                        String Gender = resultSet.getString("gender");
                                                        String occupation = resultSet.getString("occupation");
                                                        String Staus = resultSet.getString("marital_status");
                                                        String ContactNo = resultSet.getString("contact_no");
                                                        String address = resultSet.getString("address");
                                                        String issue = resultSet.getString("issue");
                                                        String Other = resultSet.getString("other_issue");
                                                        String medicine = resultSet.getString("tablet_name");
                                                        String reg_no = resultSet.getString("reg_no");
    
                                                        // Set the text of detail labels with the fetched data
                                                        lblPatientId.setText("Patient ID : " + patient_id);
                                                        lblPatientName.setText("Patient Name : " + patient_name);
                                                        lblFmName.setText("Father/Mother Name : " + fm_name);
                                                        lblAge.setText("Age : " + age);
                                                        lblgender.setText("Gender : " + Gender);
                                                        Occupation.setText("Occupation : " + occupation);
                                                        lbldate.setText("Date: " + date.toString());
                                                        Status.setText("Material Status :" + Staus);
                                                        contactNo.setText("Phone No : " + ContactNo);
                                                        Address.setText("Address : " + address);
                                                        Issue.setText("Issue: " + issue);
                                                        OIssue.setText("Other Issue : " + Other);
                                                        Medicine.setText("Mediiene : " + medicine);
                                                        RegNo.setText("Reg. No : " + reg_no);
                                                        
    
                                                        // Set the visibility of detail labels to true
                                                        lblId.setVisible(false);
                                                        btnFetch.setVisible(false);
                                                        txtId.setVisible(false);
    
                                                        lblPatientId.setVisible(true);
                                                        lblPatientName.setVisible(true);
                                                        lblFmName.setVisible(true);
                                                        lblAge.setVisible(true);
                                                        lblgender.setVisible(true);
                                                        Occupation.setVisible(true);
                                                        lbldate.setVisible(true);
                                                        Status.setVisible(true);
                                                        RegNo.setVisible(true);
                                                        contactNo.setVisible(true);
                                                        Address.setVisible(true);
                                                        Issue.setVisible(true);
                                                        OIssue.setVisible(true);
                                                        Medicine.setVisible(true);
                                                        RegNo.setVisible(true);
                                                        notelbl1.setVisible(true);
                                                        notelbl2.setVisible(true);
                                                        // Issue.setVisible(false);
    
                                                    } else {
                                                        JOptionPane.showMessageDialog(null,
                                                                "No record found for the provided ID.");
                                                    }
    
                                                    updateStatement.close();
                                                    connection.close();
    
                                                } catch (Exception e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        });
    
    // Make the detailFrame visible
    detailFrame.setVisible(true);
                                    
    }

    public static void main(String[] args) {
        Clinic_management_system ob = new Clinic_management_system();
        JFrame F = new JFrame();
        ImageIcon icon = new ImageIcon("main_pic.jpg");
        JLabel label1 = new JLabel(icon);
        F.add(label1);
        F.pack();
        F.setSize(1540, 1000);
        F.setVisible(true);
        F.setLayout(null);
        // ob.Admin_page1();
        ob.Welcome();

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Unimplemented method 'actionPerformed'");
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class MyFrame extends JFrame {

    private JTextArea textArea;

    public MyFrame() {
        super("Data Display");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Create labels for headings (same as before)...

        // Create a JTextArea to display data
        textArea = new JTextArea();
        textArea.setBounds(20, 90, 760, 400);
        textArea.setEditable(false); // Make it non-editable
        add(textArea);

        // Create a button
        JButton myButton = new JButton("Click Me");
        myButton.setBounds(20, 50, 100, 30);
        add(myButton);

        myButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","c##anand","814"); 
                    Statement statement = connection.createStatement();
                    ResultSet resultSet = statement.executeQuery("SELECT id, name, phoneno, address, degree, specilizations, fees FROM doctordata");

                    // Process the ResultSet and display the data in the text area
                    StringBuilder data = new StringBuilder();
                    while (resultSet.next()) {
                        data.append("ID: ").append(resultSet.getInt("id")).append("\n");
                        data.append("Name: ").append(resultSet.getString("name")).append("\n");
                        data.append("Phone No: ").append(resultSet.getString("phoneno")).append("\n");
                        data.append("Address: ").append(resultSet.getString("address")).append("\n");
                        data.append("Degree: ").append(resultSet.getString("degree")).append("\n");
                        data.append("Specialization: ").append(resultSet.getString("specilizations")).append("\n");
                        data.append("Fees: ").append(resultSet.getString("fees")).append("\n\n");
                    }
                    textArea.setText(data.toString());

                    resultSet.close();
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MyFrame frame = new MyFrame();
            frame.setVisible(true);
        });
    }
}

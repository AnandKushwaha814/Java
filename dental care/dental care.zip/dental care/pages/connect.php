<?php
$connect = mysqli_connect('localhost','root','','contact_db') or die('connection failed');

?>
<?php
include 'partials/header.php';
?>


<section class="empty__page">
    <div class="about-text">
        <h1>About Us</h1>
        <h5>Developer & Designer</h5>
        <p>A front-end developer is a skilled professional responsible for designing and implementing the visual<br>
            and interactive elements of a website or application.They work closely with designers, back-end developers,<br>
            and other team members to create websites and applications that are not only visually appealing but also<br>
            functional and user-friendly.The primary responsibility of a front-end developer is to write code that <br>
            enables users to interact with websites and applications. This includes creating HTML, CSS, and JavaScript<br>
            code that defines the layout and functionality of the user interface. They also work with design files created <br>
            by graphic designers, using tools such as Adobe Photoshop and Sketch, to turn designs into functional web pages.
        </p>
        <button type="button">Let's Talk</button>
    </div>
</section>


<?php
include 'partials/footer.php';
?>
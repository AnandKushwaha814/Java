<footer>
    <div class="footer__socials">
        <a href="https://www.youtube.com/@AGCAmritsar" target="_blank"><i class="uil uil-youtube"></i></a>
        <a href="https://www.facebook.com/AGC.AMRITSAR.PUNJAB" target="_blank"><i class="uil uil-facebook"></i></a>
        <a href="https://www.linkedin.com/company/agc-amritsar-group-of-colleges/" target="_blank"><i class="uil uil-linkedin"></i></a>
        <a href="https://twitter.com/AGCAmritsar" target="_blank"><i class="uil uil-twitter"></i></a>
        <a href="https://www.instagram.com/agcamritsar/" target="_blank"><i class="uil uil-instagram-alt"></i></a>
    </div>
    <div class="container footer__container">
        <article>
            <h4>Category</h4>
            <ul>
                <li><a href="">Art</a></li>
                <li><a href="">Wild Life</a></li>
                <li><a href="">Travel</a></li>
                <li><a href="">Science & Technology</a></li>
                <li><a href="">Food</a></li>
                <li><a href="">Music</a></li>
            </ul>
        </article>
        <article>
            <h4>Support</h4>
            <ul>
                <li><a href="">Online Support</a></li>
                <li><a href="">Call Number</a></li>
                <li><a href="">Emails</a></li>
                <li><a href="">Locations</a></li>
                <li><a href="https://agcamritsar.in/contact.php">Socials Support</a></li>
            </ul>
        </article>
        <article>
            <h4>Blog</h4>
            <ul>
                <li><a href="">Saftey</a></li>
                <li><a href="">Repair</a></li>
                <li><a href="">Recent</a></li>
                <li><a href="">Papular</a></li>
                <li><a href="">Categories</a></li>
                <li><a href="">Music</a></li>
            </ul>
        </article>
        <article>
            <h4>Parmalinks</h4>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="about.php">Aboutt</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </article>
    </div>
    <div class="footer__copyright">
        <small>Copyright &copy 2023 iconscout & Google Font</small>
    </div>
</footer>

<script src="<?= ROOT_URL ?>js/main.js"></script>
</body>
</html>
<?php
include 'partials/header.php';
?>

<section class="empty__page">
<div class="contact-form">
    <h1>Contact <span>Us</span></h1>
    <form action="">
    <input type="text" placeholder="Your Name" required>
    <input type="email" name="email" id="" placeholder="E-mail" required>
    <input type="" placeholder="Write a Subject" required>
    <textarea name="" id="" cols="25" rows="8" placeholder="Your Message" required></textarea>
    <input type="submit" name="" value="Submit" class="btn">
    </form>
</div>

</section>


<?php
include 'partials/footer.php';
?>
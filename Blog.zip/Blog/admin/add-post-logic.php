<?php

require 'config/database.php';

// get form data if signup button was clicked

if (isset($_POST['submit'])) {
    $author_id = $_SESSION['user-id'];
    $title = filter_var($_POST['title'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $body = filter_var($_POST['body'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $category_id = filter_var($_POST['category'], FILTER_SANITIZE_NUMBER_INT);
    $is__featured = filter_var($_POST['is__featured'], FILTER_SANITIZE_NUMBER_INT);
    $thumbnail= $_FILES['thumbnail'];


    // validate input values

    if (!$title) {
        $_SESSION['add-post'] = "Please Enter Post Title";
    } elseif (!$category_id) {
        $_SESSION['add-post'] = "Select post category";
    } elseif (!$body) {
        $_SESSION['add-post'] = "Please Enter Post body";
    } elseif (!$thumbnail['name']) {
        $_SESSION['add-post'] = "Please chose post thumbnail";
        // WORK ON AVATAR
        // rename avatar
        $time = time(); //make each image name upload unique using current timestamp
            $thumbnail_name = $time . $thumbnail['name'];
            $thumbnail_tmp_name = $thumbnail['tmp_name'];
            $thumbnail_destination_path = '../images/' . $thumbnail_name;

            // make sure file is an image
            $allowed_files = ['png', 'jpg', 'jpge'];
            $extension = explode('.', $thumbnail_name);
            $extension = end($extension);
            if (in_array($extension, $allowed_files)) {
                // make sure file size not to larg(5mb+)
                if ($thumbnail['size'] < 5000000) {
                    // upload avatar
                    move_uploaded_file($thumbnail_tmp_name, $thumbnail_destination_path);
            } else {
                $_SESSION['add-post'] = "file size to large, should be less then 5mb";
            }
        } else {
            $_SESSION['add-post'] = "file should be png, jpg, jpge";
        }
    }

    // redirect back (with form data) to add-post page if there any problem
    if (isset($_SESSION['add-post'])) {
        // pass form data back to signup page
        $_SESSION['add-post-data'] = $_POST;
        header('location: ' . ROOT_URL . 'admin/add-post.php');
        die();
    } else {
        if ($is__featured == 1) {
            $featured_query = "UPDATE posts SET is__featured=0";
            $featured_result = mysqli_query($connection, $featured_query);
        }
        //$query = "INSERT INTO posts (title, body, thumbnail, category_id, author_id, is__featured) VALUES ('$title', '$body', '$thumbnail_name', $category_id, $author_id, $is__featured)";
        $query = "INSERT INTO posts SET title='$title', body='$body',thumbnail='$thumbnail', category_id='$category_id', author_id='$author_id', is__featured='$is__featured'";

        $result = mysqli_query($connection, $query);

        if (!mysqli_errno($connection)) {
            // redirect to login page with success message
            $_SESSION['add-post-success'] = "New post added successfully😍";
            header('location: ' . ROOT_URL . 'admin/');
            die();
        }
    }
}
// if button wasn't clicked bounce back to signup button
header('location: ' . ROOT_URL . 'admin/add-post.php');
die();

<?php
include 'partials/header.php';
?>

<section class="empty__page">
    <h1>OUR SERVICES</h1>
    <p>A blog page is an essential part of a website that provides<br>
    a platform for individuals or organizations to share their thoughts<br>
    ideas, and expertise with a wider audience. Below are some of the services<br>
    that a blog page typically offers:</p>
   <p>Content creation<p>
   <h3>Add Post<p>
   <p>Add Users<p>
   <p> Manage Users<p>
   <p> Manage Post<p>
    <p>Read Articles</p>
</section>





<?php
include 'partials/footer.php';
?>